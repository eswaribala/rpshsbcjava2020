com.hsbc.ecommerce.models- All the entity classes are defined here like product, food,electronics ,apparel
com.hsbc.ecommerce.Dao- All the operations which are tobe done are keptin this package
com.hsbc.ecommerce.exceptions- User defined exceptions are defined here
com.hsbc.ecommerce.bl- rethrowing of exception and validatons are done here
