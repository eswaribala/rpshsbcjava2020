package com.hsbc.banking.exceptions;

public class QuestionRetrievalException extends Exception {

	public QuestionRetrievalException(String message)
	{
		super(message);
	}
}
