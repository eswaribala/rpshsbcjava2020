package com.goodproductltd.sales.views;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import com.goodproductltd.sales.bl.ProductBLImpl;
import com.goodproductltd.sales.bl.ProductBl;
import com.goodproductltd.sales.exceptions.FileCreationException;
import com.goodproductltd.sales.exceptions.ProductCreationException;
import com.goodproductltd.sales.models.Electronics;
import com.goodproductltd.sales.models.Product;
import com.hsbc.insurance.models.Vehicle;

public class SalesApp {
	static Scanner scanner=new Scanner(System.in);
	private static ProductBl productBl;
	static
	{
		try {
			//			System.out.println("Enter File name");
			//			String file=scanner.nextLine();
			productBl=new ProductBLImpl();
		} catch (FileCreationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static void addProductList() {
		// TODO Auto-generated method stub
		//adding Electronics Product into list.
		ArrayList<Product> productsList=new ArrayList<>();
		Product product=null;
		for (int i = 0; i < 10; i++) {
			if(i<3)
			{
				//right now taking random values and passing it into constructor.
				//defined getters and setters can be done via that as well (taking inputs from user.)
				product=new Electronics(i,"ElecTronic" + new Random().nextInt(100), 2000+ i,
						new Random().nextInt(1000), new Random().nextInt(5)+ 1);
				productsList.add(product);
			}
		}
		try {
			System.out.println(productBl.addProduct(productsList));
		} catch ( ProductCreationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private static void getProductByCategory() throws ClassNotFoundException, IOException {
		// TODO Auto-generated method stub

		List<Product> productList;
		productList = productBl.getProductByCategory();
		for(Product product: productList)
			System.out.println(product);
	}
	
	public static void main(String[] args) throws ClassNotFoundException, IOException 
	{
		//addProductList();
		getProductByCategory();


	}


}
