package com.goodproductltd.sales.exceptions;

public class ProductCreationException extends Exception{
	
	public ProductCreationException(String message)
	{
		super(message);
	}

}
