package com.goodproductltd.sales.exceptions;

public class ProductRetrievalError {

}
