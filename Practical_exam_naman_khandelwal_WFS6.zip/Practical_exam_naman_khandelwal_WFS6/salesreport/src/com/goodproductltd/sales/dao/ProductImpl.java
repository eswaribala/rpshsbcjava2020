package com.goodproductltd.sales.dao;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.goodproductltd.sales.models.Apparel;
import com.goodproductltd.sales.models.Electronics;
import com.goodproductltd.sales.models.FoodItems;
import com.goodproductltd.sales.models.Product;
import com.hsbc.insurance.models.Vehicle;


public class ProductImpl implements ProductDao{


	private File file;
	private FileOutputStream fileOutputStream;
	private FileInputStream fileInputStream;
	private ObjectOutputStream objectOutputStream;
	private ObjectInputStream objectInputStream;
	
	public ProductImpl() throws IOException
	{
		file=FileHelper.createFile();
	}
	
	@Override
	public boolean addProduct(List<Product> productList) throws IOException {
		// TODO Auto-generated method stub
		boolean flag=false;
		fileOutputStream=new FileOutputStream(file,true);
		objectOutputStream=new ObjectOutputStream(fileOutputStream);
		for(Product product : productList)
		{
			objectOutputStream.writeObject(product);
		}
		flag=true;
		objectOutputStream.close();
		fileOutputStream.close();
		return flag;
	}

	@Override
	public List<Product> getProductByCategory() throws IOException, ClassNotFoundException {
		// TODO Auto-generated method stub
		fileInputStream=new FileInputStream(file);
		objectInputStream=new ObjectInputStream(fileInputStream);
		List<Product> productList=new ArrayList<>();
		Product product=null;		
		try
		{
			while((product=(Product) objectInputStream.readObject())!=null)
			 	productList.add(product);			
		}
		catch(EOFException exception)
		{
			
		}
		finally
		{
		objectInputStream.close();
		fileInputStream.close();
		}
		//to sort on the ascending order of quantity.
		Collections.sort(productList, new SortByQuantity());
		//reverse the collection to get descending order.
		Collections.reverse(productList);
		return productList;
	}

	@Override
	public List<Product> getProductByCategory(int choice) throws IOException, ClassNotFoundException {
		// TODO Auto-generated method stub
		//can declare 3 list here and check if the object is an instance of Electronics/
		//Apparel or FoodItem and accordingly based on choice we can sort and return 1 list.
		//we can use instanceof for above purpose.
		
		fileInputStream=new FileInputStream(file);
		objectInputStream=new ObjectInputStream(fileInputStream);
		List<Electronics> electronicsProductList=new ArrayList<>();
		List<Apparel> apparelProductList=new ArrayList<>();
		List<FoodItems> foodItemsProductList=new ArrayList<>();
		
		Product product=null;		
		try
		{
			while((product=(Product) objectInputStream.readObject())!=null)
				
			 	productList.add(product);			
		}
		catch(EOFException exception)
		{
			
		}
		finally
		{
		objectInputStream.close();
		fileInputStream.close();
		}
		//to sort on the ascending order of quantity.
		Collections.sort(productList, new SortByQuantity());
		//reverse the collection to get descending order.
		Collections.reverse(productList);
		return productList;
	}
		
	}

}
