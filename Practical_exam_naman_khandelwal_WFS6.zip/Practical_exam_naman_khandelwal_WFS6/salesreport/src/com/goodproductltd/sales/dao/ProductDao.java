package com.goodproductltd.sales.dao;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import com.goodproductltd.sales.models.Electronics;
import com.goodproductltd.sales.models.Product;

public interface ProductDao {


	boolean addProduct(List<Product> productList) throws FileNotFoundException, IOException;
	List<Product> getProductByCategory() throws IOException, ClassNotFoundException;
	
	//getting subcategory by choice 1-Electronics , 2 -Apparel , 3 - FoodItems
	List<Product> getProductByCategory(int choice) throws IOException, ClassNotFoundException;
	
	
}
