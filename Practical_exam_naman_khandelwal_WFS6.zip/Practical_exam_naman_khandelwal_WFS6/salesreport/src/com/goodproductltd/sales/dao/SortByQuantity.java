package com.goodproductltd.sales.dao;

import java.util.Comparator;

import com.goodproductltd.sales.models.Product;

public class SortByQuantity implements Comparator<Product> {

	@Override
	public int compare(Product o1, Product o2) {
		// TODO Auto-generated method stub
		return Integer.valueOf(o1.getQuantity()).compareTo(Integer.valueOf(o2.getQuantity()));
	}

}
