package com.goodproductltd.sales.dao;


import java.io.File;
import java.io.IOException;
import java.util.ResourceBundle;

public class FileHelper {
	
	private static File file;
	private static ResourceBundle resourceBundle;
	public static File createFile() throws IOException
	{
		//resourceBundle=ResourceBundle.getBundle("com/goodproductltd/sales/resources/sales");

		resourceBundle=ResourceBundle.getBundle("com/goodproductltd/sales/"
				+ "resources/sales");	
		
		file=new File(resourceBundle.getString("filename"));
		if(!file.exists())
			file.createNewFile();
		
		
        return file; 	
		
		
	}

}
