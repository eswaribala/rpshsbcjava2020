package com.goodproductltd.sales.models;

import java.io.Serializable;

public enum FoodPreference implements Serializable{
	VEGETARIAN,NONVEGETARIAN;
}
