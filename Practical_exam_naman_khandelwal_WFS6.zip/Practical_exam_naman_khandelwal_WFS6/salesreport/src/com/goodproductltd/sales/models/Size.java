package com.goodproductltd.sales.models;

import java.io.Serializable;

public enum Size implements Serializable{
SMALL,MEDIUM,LARGE;
}
