package com.goodproductltd.sales.models;

import java.io.Serializable;

public class Apparel extends Product implements Serializable{
	

	private Size size;

	public Size getSize() {
		return size;
	}

	public void setSize(Size size) {
		this.size = size;
	}
	
	public Apparel(int itemCode, String itemName, double unitPrice, int quantity) {
		super(itemCode, itemName, unitPrice, quantity);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String toString() {
		return super.toString() +  "Apparel [size=" + size + "]";
	}



}






