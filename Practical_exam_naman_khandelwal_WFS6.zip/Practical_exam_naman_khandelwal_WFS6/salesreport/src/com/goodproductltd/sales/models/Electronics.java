package com.goodproductltd.sales.models;

import java.io.Serializable;

public class Electronics extends Product implements Serializable{
	
	private int warranty;

	public int getWarranty() {
		return warranty;
	}

	public void setWarranty(int warranty) {
		this.warranty = warranty;
	}


	public Electronics(int itemCode, String itemName, double unitPrice, int quantity, int warranty) {
		super(itemCode, itemName, unitPrice, quantity);
		this.warranty = warranty;
	}

	@Override
	public String toString() {
		return "Electronics [warranty=" + warranty + "]";
	}

	
	

}
