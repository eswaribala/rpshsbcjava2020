package com.goodproductltd.sales.models;

import java.io.Serializable;
import java.time.LocalDate;

public class FoodItems implements Serializable{
	private LocalDate dom;
	private LocalDate doe;
	//taking it as an enum as we've only 2 options veg/non-veg.
	private FoodPreference foodPreference;
	

	
	//genrating getter's and setter's
	public LocalDate getDom() {
		return dom;
	}
	public void setDom(LocalDate dom) {
		this.dom = dom;
	}
	public LocalDate getDoe() {
		return doe;
	}
	public void setDoe(LocalDate doe) {
		this.doe = doe;
	}
	public FoodPreference getFoodPreference() {
		return foodPreference;
	}
	public void setFoodPreference(FoodPreference foodPreference) {
		this.foodPreference = foodPreference;
	}
	@Override
	public String toString() {
		return  super.toString() +  "FoodItems [dom=" + dom + ", doe=" + doe + ", foodPreference=" + foodPreference + "]";
	}
	

}
