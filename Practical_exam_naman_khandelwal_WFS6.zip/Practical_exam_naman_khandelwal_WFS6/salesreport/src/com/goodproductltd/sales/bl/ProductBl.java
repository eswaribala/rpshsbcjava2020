package com.goodproductltd.sales.bl;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import com.goodproductltd.sales.exceptions.ProductCreationException;
import com.goodproductltd.sales.models.Product;

public interface ProductBl {

	boolean addProduct(List<Product> productList) throws ProductCreationException ;
	List<Product> getProductByCategory() throws IOException, ClassNotFoundException;
}
