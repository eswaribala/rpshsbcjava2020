package com.goodproductltd.sales.bl;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import com.goodproductltd.sales.dao.ProductDao;
import com.goodproductltd.sales.dao.ProductImpl;
import com.goodproductltd.sales.exceptions.FileCreationException;
import com.goodproductltd.sales.exceptions.ProductCreationException;
import com.goodproductltd.sales.models.Product;
import com.hsbc.insurance.exceptions.VehicleRetrievalException;
import com.hsbc.insurance.models.Vehicle;

public class ProductBLImpl implements ProductBl{
	private ProductDao productDao;
	
	public ProductBLImpl() throws FileCreationException
	{
		try {
			productDao=new ProductImpl();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			throw new FileCreationException("Unable to create File");
		}
	}
	
	
	@Override
	public boolean addProduct(List<Product> productList) throws ProductCreationException {
		// TODO Auto-generated method stub
		boolean flag=false;
		try {
			flag=productDao.addProduct(productList);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			//re-throwing exception in business layer will catch it in view layer.
			throw new ProductCreationException("Error in creating Product object" + " check file/object");
		}
		return flag;				
	}


	@Override
	public List<Product> getProductByCategory() throws IOException, ClassNotFoundException {
		// TODO Auto-generated method stub
		List<Product> productList=null;
		productList=productDao.getProductByCategory();
		return productList;
		
	}

}
