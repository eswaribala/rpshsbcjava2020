1. Model Layer  -->

Files--> 

Product.java 				 ---> superClass contains basic characteristics.
Apparel.java 				 ---> Subclass contains specific characteristics.
Electronics.java 			 ---> Subclass contains specific characteristics.
FoodItems.java				 ---> Subclass contains specific characteristics.
Size.java 		 		---> Emum of size 3
FoodPreference.java			 ---> Emum of size 2 (Veg/ non-veg).


2. Dao Layer --->

Files-->

FileHelper.java  			 ---> To create File
ProductDao.java 			 ---> An interface defined various functions here.
ProductImpl.java			 ---> Class that implements Above inteface all the program logic is mentined here.
SortByQuantity.java 			 ---> Used For Sorting based on Quantity.

3. BuisnessLAyer(BL)  --->


Files  --->

ProductBL.java 				 ---> An interface which Contains the same methods as mentioned in dao layer.
ProductBlImpl..java 			 ---> Implements above mentioned interface and also capture and re-throw exceptions.

4. Resource Package --->

Files-->

sales.properties.txt  			---> contains key/value pair with filename as a key.

5. Exceptions Layer --->

Files-->

FileCreationException.java		---> Created to throw Custom Exception
ProductCreationException.java		---> Created to throw Custom Exception
ProductRetrievalExceptiom.java		---> Created to throw Custom Exception

6. View Layer --->

Files-->

SalesApp.java   			---> calls all the functions and capture exceptions.