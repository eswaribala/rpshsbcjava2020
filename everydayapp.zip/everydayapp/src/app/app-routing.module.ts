import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {AddFoodItemsComponent} from './fooditems/add/add.component';
import {ViewFoodItemsComponent} from './fooditems/view/view.component';
import {AddElectronicsComponent} from './electronics/add/add.component';
import {ViewElectronicsComponent} from './electronics/view/view.component';
import {AddApparelsComponent} from './apparels/add/add.component';
import {ViewApparelsComponent} from './apparels/view/view.component';
import {ProductComponent} from './product/product.component';
import {FooditemsComponent} from './fooditems/fooditems/fooditems.component';
import {ElectronicsComponent} from './electronics/electronics/electronics.component';
import {ApparelsComponent} from './apparels/apparels/apparels.component';


const routes: Routes = [{
  path:'Products',
  component:ProductComponent,
  children:[{
    path:'FoodItems',
    component:FooditemsComponent,
    children:[{
      path:'Add',
      component:AddFoodItemsComponent
    },
      {
        path:'View',
        component:ViewFoodItemsComponent
      }

    ]
  },
    {
      path:'Electronics',
      component:ElectronicsComponent,
      children:[{
        path:'Add',
        component:AddElectronicsComponent
      },
        {
          path:'View',
          component:ViewElectronicsComponent
        }

      ]
    },
    {
      path:'Apparels',
      component: ApparelsComponent,
      children:[{
        path:'Add',
        component:AddApparelsComponent
      },
        {
          path:'View',
          component:ViewApparelsComponent
        }

      ]
    }


  ]
}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
