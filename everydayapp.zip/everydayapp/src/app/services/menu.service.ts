import { Injectable } from '@angular/core';
import {menuData} from '../models/models.menudata';

@Injectable({
  providedIn: 'root'
})
export class MenuService {

  constructor() { }

  getMenuData():any
  {
    return menuData;
  }

}
