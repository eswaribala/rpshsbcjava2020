import {Items, PanelMenu, SubItems} from './models.panelmenu';


export let menuData:PanelMenu[]=[new PanelMenu('Products','',
  'Products',
  [new Items('FoodItems','','Products/FoodItems',
    [new SubItems('Add','','Products/FoodItems/Add'),
      new SubItems('View','','Products/FoodItems/View')
    ]),
    new Items('Electronics','','Products/Electronics',
      [new SubItems('Add','',
        'Products/Electronics/Add'),
        new SubItems('View','','Products/Electronics/View')
      ]),
    new Items('Apparel','','Products/Apparels',
      [new SubItems('Add','','Products/Apparels/Add'),
        new SubItems('View','','Products/Apparels/View')
      ])

  ]),
  new PanelMenu('Aboutus','','',[]),
  new PanelMenu('Contactus','','',[]),
  new PanelMenu('Expert Thinking','','',[])
];
