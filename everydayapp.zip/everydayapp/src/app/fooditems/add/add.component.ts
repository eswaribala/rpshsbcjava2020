import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {ProductService} from '../../services/product.service';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddFoodItemsComponent implements OnInit {
  private itemCode:FormControl;
  private name:FormControl;
  private qty:FormControl;
  private unitPrice:FormControl;
  private dateOfManufacturing:FormControl;
  private dateOfExpiry:FormControl;
  private vegetarian:FormControl;
  private type:string[]=['YES','NO'];
  private foodItemGroup:FormGroup;
  selectedType: any;
  private vegType:string;
  constructor(private formBuilder:FormBuilder,
              private productService:ProductService) {
    this.itemCode=new FormControl('',[Validators.required
    ,Validators.pattern("[0-9]{1,5}")]);
    this.name=new FormControl('',[Validators.required
      ,Validators.pattern("[a-zA-Z]{5,50}")]);
    this.qty=new FormControl('',[Validators.required
      ,Validators.pattern("[0-9]{1,5}")]);
    this.unitPrice=new FormControl('',[Validators.required
      ,Validators.pattern("[0-9]{1,5}")]);
    this.dateOfManufacturing=new FormControl('',[Validators.required]);
     this.dateOfExpiry= new FormControl('',[Validators.required]);
     this.vegetarian=new FormControl('',[Validators.required]);
     this.foodItemGroup=this.formBuilder.group({
       itemCode:this.itemCode,
       name:this.name,
       qty:this.qty,
       unitPrice:this.unitPrice,
       dateOfManufacturing:this.dateOfManufacturing,
       dateOfExpiry:this.dateOfExpiry,
       vegetarian:this.vegetarian
     })
  }

  ngOnInit() {
  }

  addFoodItem() {

     console.log(this.foodItemGroup.value);
     this.productService.addFoodItem(this.foodItemGroup.value)
       .subscribe(response=>{
         console.log(response);
       },error=>(console.log(error)));

  }

  typeChanged() {
    console.log(this.selectedType)
    this.vegType=this.selectedType;
  }
}
