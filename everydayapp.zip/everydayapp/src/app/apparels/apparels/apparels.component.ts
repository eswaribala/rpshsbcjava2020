import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-apparels',
  templateUrl: './apparels.component.html',
  styleUrls: ['./apparels.component.css']
})
export class ApparelsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
