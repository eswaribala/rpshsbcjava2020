import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  private title: string;
  private logo: string;
  constructor() {
    this.title = 'Every Day Good Products Pvt.Ltd';
    this.logo = '../assets/everyday.jpg';
  }

  ngOnInit() {
  }

}
