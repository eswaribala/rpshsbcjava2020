import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {HeaderComponent} from './header/header.component';
import {FooterComponent} from './footer/footer.component';
import {PanelMenuModule} from 'primeng/panelmenu';
import { MenuComponent } from './menu/menu.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { AddFoodItemsComponent } from './fooditems/add/add.component';
import { ViewFoodItemsComponent } from './fooditems/view/view.component';
import {AddElectronicsComponent} from './electronics/add/add.component';
import {ViewElectronicsComponent} from './electronics/view/view.component';
import {AddApparelsComponent} from './apparels/add/add.component';
import {ViewApparelsComponent} from './apparels/view/view.component';
import { ProductComponent } from './product/product.component';
import { FooditemsComponent } from './fooditems/fooditems/fooditems.component';
import { ElectronicsComponent } from './electronics/electronics/electronics.component';
import { ApparelsComponent } from './apparels/apparels/apparels.component';
import {MatButtonModule, MatFormFieldModule, MatIconModule, MatInputModule, MatSelectModule} from '@angular/material';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    MenuComponent,
    AddFoodItemsComponent,
    ViewFoodItemsComponent,
    AddElectronicsComponent,
    ViewElectronicsComponent,
    AddApparelsComponent,
    ViewApparelsComponent,
    ProductComponent,
    FooditemsComponent,
    ElectronicsComponent,
    ApparelsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    PanelMenuModule,
    BrowserAnimationsModule,
    MatFormFieldModule,
    MatIconModule,
    MatButtonModule,
    MatInputModule,
    ReactiveFormsModule,
    MatSelectModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
