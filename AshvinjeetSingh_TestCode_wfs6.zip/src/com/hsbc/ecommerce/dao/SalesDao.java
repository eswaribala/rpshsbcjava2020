package com.hsbc.ecommerce.dao;

import java.io.IOException;
import java.util.List;

import com.hsbc.ecommerce.models.Apparel;
import com.hsbc.ecommerce.models.Category;
import com.hsbc.ecommerce.models.Electronics;
import com.hsbc.ecommerce.models.FoodItems;
//interface containing addaddnewitems and getallitems
public interface SalesDao {
	
	boolean addcategory(List<Category> categoryList) throws IOException;
	List<Category> getAllCategoriesList() throws IOException, ClassNotFoundException;
	boolean addFoodItems(List<FoodItems> foodList) throws IOException;
	List<FoodItems> getAllCategoriesFoodList() throws IOException, ClassNotFoundException;
	boolean addApparel(List<Apparel> apparelList) throws IOException;
	List<Apparel> getAllApparelList() throws IOException, ClassNotFoundException;
	boolean addElectronics(List<Electronics> electronicsList) throws IOException;
	List<Electronics> getAllElectronicsList() throws IOException, ClassNotFoundException;

}
