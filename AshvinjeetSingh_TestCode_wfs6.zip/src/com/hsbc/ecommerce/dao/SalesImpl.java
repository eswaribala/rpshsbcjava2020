package com.hsbc.ecommerce.dao;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

import com.hsbc.ecommerce.models.Apparel;
import com.hsbc.ecommerce.models.Category;
import com.hsbc.ecommerce.models.Electronics;
import com.hsbc.ecommerce.models.FoodItems;
//impl of all dao files
public class SalesImpl implements SalesDao {

	private File file;
	private FileOutputStream fileOutputStream;
	private FileInputStream fileInputStream;
	private ObjectOutputStream objectOutputStream;
	private ObjectInputStream objectInputStream;
	
	public SalesImpl() throws IOException
	{
		file = FileHelper.createFile();
	}
	@Override
	public boolean addcategory(List<Category> categoryList) throws IOException {
		// TODO Auto-generated method stub
		boolean status=false;
		fileOutputStream = new FileOutputStream(file);
		objectOutputStream =new ObjectOutputStream(fileOutputStream);
		for(Category category:categoryList)
		{
			objectOutputStream.writeObject(category);
			status=true;
		}
		objectOutputStream.close();
		fileOutputStream.close();
		return status;
		
	}

	@Override
	public List<Category> getAllCategoriesList() throws IOException, ClassNotFoundException {
		// TODO Auto-generated method stub
		fileInputStream = new FileInputStream(file);
		objectInputStream = new ObjectInputStream(fileInputStream);
		List<Category> categoryList =new ArrayList<Category>();
		Category category=null;
		try 
		{
			while((category=(Category) objectInputStream.readObject())!=null)
			{
				categoryList.add(category);
			}
		}
		catch(EOFException e)
		{
			
		}
		
		objectInputStream.close();
		fileInputStream.close();
		return categoryList;
	}
	@Override
	public boolean addFoodItems(List<FoodItems> foodList) throws IOException {
		// TODO Auto-generated method stub
		boolean status=false;
		fileOutputStream = new FileOutputStream(file);
		objectOutputStream =new ObjectOutputStream(fileOutputStream);
		for(FoodItems foodItems:foodList)
		{
			objectOutputStream.writeObject(foodItems);
			status=true;
		}
		objectOutputStream.close();
		fileOutputStream.close();
		return status;
	}
	@Override
	public List<FoodItems> getAllCategoriesFoodList() throws IOException, ClassNotFoundException {
		// TODO Auto-generated method stub
		fileInputStream = new FileInputStream(file);
		objectInputStream = new ObjectInputStream(fileInputStream);
		List<FoodItems>  FoodList =new ArrayList<FoodItems> ();
		FoodItems fooditems=null;
		try 
		{
			while((fooditems= (FoodItems) objectInputStream.readObject())!=null)
			{
				FoodList.add(fooditems);
			}
		}
		catch(EOFException e)
		{
			
		}
		
		objectInputStream.close();
		fileInputStream.close();
		return FoodList;
	}
	@Override
	public boolean addApparel(List<Apparel> apparelList) throws IOException {
		// TODO Auto-generated method stub
		boolean status=false;
		fileOutputStream = new FileOutputStream(file);
		objectOutputStream =new ObjectOutputStream(fileOutputStream);
		for(Apparel apparels:apparelList)
		{
			objectOutputStream.writeObject(apparels);
			status=true;
		}
		objectOutputStream.close();
		fileOutputStream.close();
		return status;
	}
	@Override
	public List<Apparel> getAllApparelList() throws IOException, ClassNotFoundException {
		// TODO Auto-generated method stub
		fileInputStream = new FileInputStream(file);
		objectInputStream = new ObjectInputStream(fileInputStream);
		List<Apparel>  apparelList =new ArrayList<Apparel> ();
		Apparel apparel=null;
		try 
		{
			while((apparel=  (Apparel) objectInputStream.readObject())!=null)
			{
				apparelList.add(apparel);
			}
		}
		catch(EOFException e)
		{
			
		}
		
		objectInputStream.close();
		fileInputStream.close();
		return apparelList;
	}
	@Override
	public boolean addElectronics(List<Electronics> electronicsList) throws IOException {
		// TODO Auto-generated method stub
		boolean status=false;
		fileOutputStream = new FileOutputStream(file);
		objectOutputStream =new ObjectOutputStream(fileOutputStream);
		for(Electronics electronics:electronicsList)
		{
			objectOutputStream.writeObject(electronics);
			status=true;
		}
		objectOutputStream.close();
		fileOutputStream.close();
		return status;
	}
	@Override
	public List<Electronics> getAllElectronicsList() throws IOException, ClassNotFoundException {
		// TODO Auto-generated method stub
		fileInputStream = new FileInputStream(file);
		objectInputStream = new ObjectInputStream(fileInputStream);
		List<Electronics>  electronicsList=new ArrayList<Electronics> ();
		Electronics electronics=null;
		try 
		{
			while(( electronics=   (Electronics) objectInputStream.readObject())!=null)
			{
				electronicsList.add(electronics);
			}
		}
		catch(EOFException e)
		{
			
		}
		
		objectInputStream.close();
		fileInputStream.close();
		return electronicsList;
	}

}
