package com.hsbc.ecommerce.dao;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;
//to create new File
public class FileHelper {
	
	private static File file;
	private static ResourceBundle resourceBundle;
	public static File createFile() throws IOException
	{
		
		
		resourceBundle= ResourceBundle.getBundle("com/hsbc/ecommerce/resources/insurance");
		
		file=new File(resourceBundle.getString("FileName"));
		if(!file.exists())
			file.createNewFile();
        return file; 	
		
		
	}

}
