package com.hsbc.ecommerce.bl;

import java.io.IOException;
import java.util.List;

import com.hsbc.ecommerce.dao.SalesDao;
import com.hsbc.ecommerce.dao.SalesImpl;
import com.hsbc.ecommerce.exceptions.FileCreationException;
import com.hsbc.ecommerce.exceptions.Product;
import com.hsbc.ecommerce.models.Apparel;
import com.hsbc.ecommerce.models.Category;
import com.hsbc.ecommerce.models.Electronics;
import com.hsbc.ecommerce.models.FoodItems;
//implementation of all Bussineessayes
public class SalesBLImpl implements SalesBL {
	private SalesDao salesDao;
	
	
	public SalesBLImpl() throws FileCreationException {
		try {
			salesDao =new SalesImpl();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			throw new FileCreationException("File is not ctreated"+"Check location or permission");
		}
	}

	@Override
	public boolean addcategory(List<Category> categoryList) throws FileCreationException {
		// TODO Auto-generated method stub
		boolean status =true;
		try {
			status =salesDao.addcategory(categoryList);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			throw new FileCreationException("File is not ctreated"+"Check location or permission");
		}
		return status;
	}

	@Override
	public List<Category> getAllCategoriesList() throws Product, FileCreationException {
		// TODO Auto-generated method stub
		List<Category> categoryList =null;
		try {
			categoryList =salesDao.getAllCategoriesList();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			throw new FileCreationException("File is not ctreated"+"Check location or permission");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			throw new Product("item nou found please chek file again");
		}
		return null;
	}

	@Override
	public boolean addFoodItems(List<FoodItems> foodList) throws IOException {
		boolean status =true;
		try {
			status =salesDao.addFoodItems(foodList));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			throw new FileCreationException("File is not ctreated"+"Check location or permission");
		}
		return status;
	}

	@Override
	public List<FoodItems> getAllCategoriesFoodList() throws FileCreationException, Product  {
		// TODO Auto-generated method stub
		List<Category> categoryList =null;
		try {
			categoryList =salesDao.getAllCategoriesFoodList()();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			throw new FileCreationException("File is not ctreated"+"Check location or permission");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			throw new Product("item nou found please chek file again");
		}
		return null;
	}

	@Override
	public boolean addApparel(List<Apparel> apparelList) throws IOException {
		// TODO Auto-generated method stub
		boolean status =true;
		try {
			status =salesDao.addApparel(apparelList);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			throw new FileCreationException("File is not ctreated"+"Check location or permission");
		}
		return status;
	}

	@Override
	public List<Apparel> getAllApparelList() throws IOException, ClassNotFoundException {
		List<Category> categoryList =null;
		try {
			categoryList =salesDao.getAllApparelList()();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			throw new FileCreationException("File is not ctreated"+"Check location or permission");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			throw new Product("item nou found please chek file again");
		}
		return null;
	}
	
	}

	@Override
	public boolean addElectronics(List<Electronics> electronicsList) throws IOException, FileCreationException {
		// TODO Auto-generated method stub
		boolean status =true;
		try {
			status =salesDao.addElectronics(electronicsList);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			throw new FileCreationException("File is not ctreated"+"Check location or permission");
		}
		return status;
	}

	@Override
	public List<Electronics> getAllElectronicsList() throws IOException, ClassNotFoundException {
		// TODO Auto-generated method stub
		List<Category> categoryList =null;
		try {
			categoryList =salesDao.getAllElectronicsList();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			throw new FileCreationException("File is not ctreated"+"Check location or permission");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			throw new Product("item nou found please chek file again");
		}
		return null;
	}
	

}
