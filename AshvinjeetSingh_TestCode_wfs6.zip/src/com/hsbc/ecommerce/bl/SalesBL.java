package com.hsbc.ecommerce.bl;

import java.io.IOException;
import java.util.List;

import com.hsbc.ecommerce.exceptions.FileCreationException;
import com.hsbc.ecommerce.exceptions.Product;
import com.hsbc.ecommerce.models.Apparel;
import com.hsbc.ecommerce.models.Category;
import com.hsbc.ecommerce.models.Electronics;
import com.hsbc.ecommerce.models.FoodItems;

public interface SalesBL {
	boolean addcategory(List<Category> categoryList) throws FileCreationException ;
	List<Category> getAllCategoriesList() throws Product, FileCreationException;
	boolean addFoodItems(List<FoodItems> foodList) throws IOException;
	List<FoodItems> getAllCategoriesFoodList() throws IOException, ClassNotFoundException, FileCreationException, Product;
	boolean addApparel(List<Apparel> apparelList) throws IOException;
	List<Apparel> getAllApparelList() throws IOException, ClassNotFoundException;
	boolean addElectronics(List<Electronics> electronicsList) throws IOException, FileCreationException;
	List<Electronics> getAllElectronicsList() throws IOException, ClassNotFoundException;

}
