package com.hsbc.ecommerce.models;

public enum Size {
Small,Medium,Large,ExtraLarge;
}
