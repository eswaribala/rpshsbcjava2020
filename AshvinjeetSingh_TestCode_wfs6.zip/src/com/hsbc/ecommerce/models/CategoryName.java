package com.hsbc.ecommerce.models;

public enum CategoryName {
	
	Food,Electronics,Apparels;

}
