package com.hsbc.ecommerce.models;

import java.io.Serializable;

//category contaiining common method for all the subclasses
public class Category implements Serializable {
	
	
	
	private String categoryType;

	public String getCategoryType() {
		return categoryType;
	}

	public void setCategoryType(String categoryType) {
		this.categoryType = categoryType;
	}

	

	
	
	
	
	

}
