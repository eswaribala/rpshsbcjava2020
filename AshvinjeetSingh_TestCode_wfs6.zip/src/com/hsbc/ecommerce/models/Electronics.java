package com.hsbc.ecommerce.models;

import java.io.Serializable;
//data members specific to Electronics
public class Electronics extends Category implements Serializable{
	private int itemCode;
	private  String itemName;
	private int  unitPrice;
	private int quantity;
public int getItemCode() {
		return itemCode;
	}
	public void setItemCode(int itemCode) {
		this.itemCode = itemCode;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public int getUnitPrice() {
		return unitPrice;
	}
	public void setUnitPrice(int unitPrice) {
		this.unitPrice = unitPrice;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public byte getWarranty() {
		return warranty;
	}
	public void setWarranty(byte warranty) {
		this.warranty = warranty;
	}
	//	byte because in months and assuming max 5 yrs warranty means 60 months
	private byte warranty;

}
