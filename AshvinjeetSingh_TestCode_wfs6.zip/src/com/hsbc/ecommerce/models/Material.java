package com.hsbc.ecommerce.models;

public enum Material {
	cotton,woolen;

}
