package com.hsbc.ecommerce.models;

public enum Vegetarian {
	Yes,No;

}
