package com.hsbc.ecommerce.models;


import java.io.Serializable;
import java.time.LocalDate;
//containing meember specific to food items
public class FoodItems extends Category implements Serializable{
	private int itemCode;
	private  String itemName;
	private int  unitPrice;
	private int quantity;
	public int getItemCode() {
		return itemCode;
	}
	public void setItemCode(int itemCode) {
		this.itemCode = itemCode;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public int getUnitPrice() {
		return unitPrice;
	}
	public void setUnitPrice(int unitPrice) {
		this.unitPrice = unitPrice;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public LocalDate getDateOfManufacture() {
		return dateOfManufacture;
	}
	public void setDateOfManufacture(LocalDate dateOfManufacture) {
		this.dateOfManufacture = dateOfManufacture;
	}
	public LocalDate getDateOfExpiry() {
		return dateOfExpiry;
	}
	public void setDateOfExpiry(LocalDate dateOfExpiry) {
		this.dateOfExpiry = dateOfExpiry;
	}
	public Vegetarian getVegetatrian() {
		return vegetatrian;
	}
	public void setVegetatrian(Vegetarian vegetatrian) {
		this.vegetatrian = vegetatrian;
	}
	private LocalDate dateOfManufacture;
	private LocalDate dateOfExpiry;
	private Vegetarian vegetatrian;
	
	
	
	
	
	
	
	
	
	

}
