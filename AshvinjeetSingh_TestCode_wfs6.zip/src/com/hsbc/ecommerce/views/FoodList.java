package com.hsbc.ecommerce.views;
/*
 * author:Ashvinjeet
 * main food file
 */
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.hsbc.ecommerce.bl.SalesBL;
import com.hsbc.ecommerce.bl.SalesBLImpl;
import com.hsbc.ecommerce.exceptions.FileCreationException;
import com.hsbc.ecommerce.exceptions.Product;
import com.hsbc.ecommerce.models.Category;
//for apparel category not completed
public class FoodList {
	
	private static SalesBL salesBL;
	static Scanner scanner  =new Scanner(System.in);
	static
	{
		try {
			salesBL =new SalesBLImpl();
		} catch (FileCreationException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
	}
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		

	}

}
