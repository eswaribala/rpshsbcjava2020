package com.hsbc.ecommerce.exceptions;

public class Product extends Exception {
	
	public Product(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}

}
