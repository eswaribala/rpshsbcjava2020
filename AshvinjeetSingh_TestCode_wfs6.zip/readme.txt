this file contain information about a product that will return top 3 list items of all categories mainly categories are conatining Electronics,Apparel,Food

View layer: ApparelList
		SalesApp
		FoodList
		ApparelList
Dao layer :SalesDao(interface)
	SalesImpl'
	filehelper
Bl layer:SalesBl(interface)
	SalesImpl

Exception:filecreate
	Product