package com.hsbc.retail.exceptions;

public class DBConnCreationException extends Exception{

	public DBConnCreationException(String message)
	{
		super(message);
	}
}
