package com.hsbc.retail.models;

public enum VegeterianType {
YES,NO
}
