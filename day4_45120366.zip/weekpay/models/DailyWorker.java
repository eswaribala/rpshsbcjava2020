package com.hsbc.weekpay.models;

public final class DailyWorker extends Worker{
	
	private byte days;
	private int hours;

	public int getHours() {
		return hours;
	}

	public void setHours(int hours) {
		this.hours = hours;
	}

	public byte getDays() {
		return days;
	}

	public void setDays(byte days) {
		this.days = days;
	}

	@Override
	public String toString() {
		return super.toString()+"DailyWorker [days=" + days + "]";
	}
	
	

}
