package com.hsbc.weekpay.models;

public final class SalariedWorker extends Worker{
	
	private final int hours=40;

	public int getHours() {
		return hours;
	}

	@Override
	public String toString() {
		return super.toString()+"SalariedWorker [hours=" + hours + "]";
	}

}
