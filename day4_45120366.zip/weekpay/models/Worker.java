package com.hsbc.weekpay.models;

//Calculating the pay of workers Process needs Worker information
public abstract class Worker {
	
	protected String name;
	protected int salaryRate;
	protected int salary;
	
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getSalaryRate() {
		return salaryRate;
	}
	public void setSalaryRate(int salaryRate) {
		this.salaryRate = salaryRate;
	}
	@Override
	public String toString() {
		return "Worker [name=" + name + ", salaryRate=" + salaryRate + "]";
	}

}
