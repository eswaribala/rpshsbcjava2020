package com.hsbc.weekpay.dao;

import com.hsbc.weekpay.models.SalariedWorker;
//Storage
public interface SalariedWorkerDao {	
	//public abstract
		//operations
		//create
	boolean addSalariedWorker(SalariedWorker salariedworker);

}
