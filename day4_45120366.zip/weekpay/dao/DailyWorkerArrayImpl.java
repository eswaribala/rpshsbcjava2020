package com.hsbc.weekpay.dao;

import com.hsbc.weekpay.models.DailyWorker;
//Array Transient Objects
public class DailyWorkerArrayImpl implements DailyWorkerDao{
	
	private DailyWorker[] dailyWorkerList;
	private static int pos;
	
	public DailyWorkerArrayImpl()
	{
		dailyWorkerList=new DailyWorker[5];
	}

	@Override
	public boolean addDailyWorker(DailyWorker dailyWorker) {
		// TODO Auto-generated method stub
		dailyWorkerList[pos]=dailyWorker;
		pos++;
		return true;
	}

}
