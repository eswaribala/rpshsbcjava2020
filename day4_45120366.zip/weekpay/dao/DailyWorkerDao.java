package com.hsbc.weekpay.dao;

import com.hsbc.weekpay.models.DailyWorker;
//Storage
public interface DailyWorkerDao {
	//public abstract
		//operations
		//create
	boolean addDailyWorker(DailyWorker dailyworker);

}
