package com.hsbc.weekpay.dao;

import com.hsbc.weekpay.models.SalariedWorker;
//Array Transient Objects
public class SalariedWorkerArrayImpl implements SalariedWorkerDao{
	
	private SalariedWorker[] salariedWorkerList;
	private static int pos;
	
	public SalariedWorkerArrayImpl()
	{
		salariedWorkerList=new SalariedWorker[5];
	}

	@Override
	public boolean addSalariedWorker(SalariedWorker salariedWorker) {
		// TODO Auto-generated method stub
		salariedWorkerList[pos]=salariedWorker;
		pos++;
		return true;
	}

}
