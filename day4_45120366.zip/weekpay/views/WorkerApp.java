package com.hsbc.weekpay.views;

import java.util.Scanner;

import com.hsbc.weekpay.bl.DailyWorkerBL;
import com.hsbc.weekpay.bl.DailyWorkerBLImpl;
import com.hsbc.weekpay.bl.SalariedWorkerBL;
import com.hsbc.weekpay.bl.SalariedWorkerBLImpl;
import com.hsbc.weekpay.models.DailyWorker;
import com.hsbc.weekpay.models.SalariedWorker;

public class WorkerApp {
	
	private static Scanner scanner=new Scanner(System.in);
	private static DailyWorkerBL dailyWorkerBL=new DailyWorkerBLImpl();
	private static SalariedWorkerBL salariedWorkerBL=new SalariedWorkerBLImpl();

	public static void main(String[] args){
		// TODO Auto-generated method stub
		
		int choice=0;		
		
		do
		{
			
          menu();               
          System.out.println("Do you want to continue(1..98)");
          choice=scanner.nextInt();
          scanner.nextLine();
          choiceImpl(choice);
		}
		while(choice!=99);
		
		scanner.close();
	}
	
	private static void menu()
	{
		 
		System.out.println("Worker Admin Menu");
		System.out.println("-----------------------------------------");
		System.out.println("1.Add Daily Worker");
		System.out.println("2.Add Salaried Worker");
		System.out.println("99.Exit");		
	}
	
	public static void choiceImpl(int option)
	{
		
		switch(option)
		{
		case 1:
			System.out.println("Add Daily Worker...");
			DailyWorker dailyWorker=new DailyWorker();
			System.out.println("Enter Daily Worker Name");
			dailyWorker.setName(scanner.nextLine());
			System.out.println("Enter Salary Rate");
			dailyWorker.setSalaryRate(scanner.nextInt());
			System.out.println("Enter the number of days");
			dailyWorker.setDays(scanner.nextByte());
			System.out.println("Enter hours a day");
			dailyWorker.setHours(scanner.nextInt());			
			if( dailyWorkerBL.addDailyWorker(dailyWorker))
			{
				System.out.println("Record Added....."+"the pay of worker="+dailyWorker.getSalary());
			}
			else
				System.out.println("Error in input..., Record not added");
			break;
		case 2:
			System.out.println("Add Salaried Worker...");
			SalariedWorker salariedWorker=new SalariedWorker();
			System.out.println("Enter Salaried Worker Name");
			salariedWorker.setName(scanner.nextLine());
			System.out.println("Enter Salary Rate");
			salariedWorker.setSalaryRate(scanner.nextInt());			
			if( salariedWorkerBL.addSalariedWorker(salariedWorker))
			{
				System.out.println("Record Added....."+"the pay of worker="+salariedWorker.getSalary());
			}
			else
				System.out.println("Error in input..., Record not added");
			break;
			
		}
		
	}

}
