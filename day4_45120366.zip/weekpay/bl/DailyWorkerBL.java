package com.hsbc.weekpay.bl;

import com.hsbc.weekpay.models.DailyWorker;

public interface DailyWorkerBL {
	//public abstract
			//operations
			//create
	boolean addDailyWorker(DailyWorker dailyworker);
	int Pay(int hours);

}
