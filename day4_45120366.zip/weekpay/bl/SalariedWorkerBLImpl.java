package com.hsbc.weekpay.bl;

import com.hsbc.weekpay.dao.SalariedWorkerArrayImpl;
import com.hsbc.weekpay.dao.SalariedWorkerDao;
import com.hsbc.weekpay.models.DailyWorker;
import com.hsbc.weekpay.models.SalariedWorker;

public class SalariedWorkerBLImpl implements SalariedWorkerBL{
	
private SalariedWorkerDao salariedWorkerDao;
private SalariedWorker salariedWorkerObj;
	
	public SalariedWorkerBLImpl()
	{
		salariedWorkerDao=new SalariedWorkerArrayImpl();
		salariedWorkerObj=new SalariedWorker();
	}
	
	private boolean validateSalaryRate(int salaryRate)
	{
		return (salaryRate<=216);		
		
	}
	//validations
		//Validate Salaried Worker Object
	@Override
	public boolean addSalariedWorker(SalariedWorker salariedWorker) {
		// TODO Auto-generated method stub
		boolean status=false;
		
		 if(validateSalaryRate(salariedWorker.getSalaryRate()))
		 {
		    	salariedWorkerObj.setSalaryRate(salariedWorker.getSalaryRate());
		    	salariedWorker.setSalary(Pay(salariedWorker.getHours()));
		    	//save this in array
		    	salariedWorkerDao.addSalariedWorker(salariedWorker);
		
		    	status=true;
		 }
		
		return status;
	}

	@Override
	public int Pay(int hours) {
		// TODO Auto-generated method stub
		return (hours*salariedWorkerObj.getSalaryRate());
	}

}
