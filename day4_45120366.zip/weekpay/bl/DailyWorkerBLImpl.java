package com.hsbc.weekpay.bl;

import com.hsbc.weekpay.dao.DailyWorkerArrayImpl;
import com.hsbc.weekpay.dao.DailyWorkerDao;
import com.hsbc.weekpay.models.DailyWorker;

public class DailyWorkerBLImpl implements DailyWorkerBL{
	
private DailyWorkerDao dailyWorkerDao;
private DailyWorker dailyWorkerObj;
private static byte days;
	
	public DailyWorkerBLImpl()
	{
		dailyWorkerDao=new DailyWorkerArrayImpl();
		dailyWorkerObj=new DailyWorker();
	}
	
	private boolean validateDays(byte days)
	{
		return (days<=7);		
		
	}
	
	private boolean validateHours(int hours)
	{
		
		return (hours<=10);
	}
	//validations
		//Validate Daily Worker Object
	@Override
	public boolean addDailyWorker(DailyWorker dailyWorker) {
		// TODO Auto-generated method stub
		boolean status=false;
		//validation
				//validate days and hours
		 if(validateDays(dailyWorker.getDays()))
		 {
		    if(validateHours(dailyWorker.getHours()))
		    {
		    	days=dailyWorker.getDays();
		    	dailyWorkerObj.setSalaryRate(dailyWorker.getSalaryRate());
		    	dailyWorker.setSalary(Pay(dailyWorker.getHours()));
		    	//save this in array
		    	dailyWorkerDao.addDailyWorker(dailyWorker);
		
		    	status=true;
		    }
		 }
		
		return status;
	}
	
	public int Pay(int hours)
	{
		return (hours*days*dailyWorkerObj.getSalaryRate());
	}

}
