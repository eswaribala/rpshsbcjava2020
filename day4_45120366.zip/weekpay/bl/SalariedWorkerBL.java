package com.hsbc.weekpay.bl;

import com.hsbc.weekpay.models.SalariedWorker;

public interface SalariedWorkerBL {
	//public abstract
			//operations
			//create
	boolean addSalariedWorker(SalariedWorker salariedWorker);
	int Pay(int hours);

}
