package com.hsbc.ecommerce.views;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.hsbc.ecommerce.bl.CategoryBL;
import com.hsbc.ecommerce.bl.CategoryBLImpl;
import com.hsbc.ecommerce.exceptions.FileCreateException;
import com.hsbc.ecommerce.exceptions.QuantityException;
import com.hsbc.ecommerce.exceptions.UnitPriceException;
import com.hsbc.ecommerce.models.Apparel;
import com.hsbc.ecommerce.models.Electronics;
import com.hsbc.ecommerce.models.FoodItems;


public class CategoryApp {
	
	private static final List<Electronics> ElectronicsList = null;
	private static final List<Apparel> ApparelList = null;
	//connecting business layer to view layer
	private static CategoryBL categoryBl;
	//capture custom exception
	static
	{
		try {
			categoryBl=new CategoryBLImpl("Category.txt",1);
		} catch (FileCreateException e) {
			
			System.out.println(e.getMessage());
		}
	}
	private static void addCategories() throws IOException, QuantityException, UnitPriceException
	{

		ArrayList<FoodItems> foodItemList=new ArrayList<FoodItems>();
		foodItemList.ensureCapacity(3);
		
		ArrayList<Apparel> apparelList=new ArrayList<Apparel>();
		apparelList.ensureCapacity(3);
		
		ArrayList<Electronics> eList=new ArrayList<Electronics>();
	eList.ensureCapacity(3);
		
	
	System.out.println(categoryBl.addFoodCategory(foodItemList));
	System.out.println(categoryBl.addApparelCategory(apparelList));
	System.out.println(categoryBl.addElectronicsCategory(eList));
	}
	public static void main(String[] args) throws IOException, QuantityException, UnitPriceException {
		// TODO Auto-generated method stub
     addCategories();
   
	}

}
