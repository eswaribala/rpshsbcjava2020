package com.hsbc.ecommerce.models;

import java.io.Serializable;
import java.time.LocalDate;

public class FoodItems extends Category implements Serializable{
	
	private byte itemCode;
	private String itemName;
	private int unitPrice;
	private LocalDate dateOfMfg;
	private LocalDate dateOfExpiry;
	private Vegetarian vegetarian;
	private int quantity;
	public byte getItemCode() {
		return itemCode;
	}
	public void setItemCode(byte itemCode) {
		this.itemCode = itemCode;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public int getUnitPrice() {
		return unitPrice;
	}
	public void setUnitPrice(int unitPrice) {
		this.unitPrice = unitPrice;
	}
	public LocalDate getDateOfMfg() {
		return dateOfMfg;
	}
	public void setDateOfMfg(LocalDate dateOfMfg) {
		this.dateOfMfg = dateOfMfg;
	}
	public LocalDate getDateOfExpiry() {
		return dateOfExpiry;
	}
	public void setDateOfExpiry(LocalDate dateOfExpiry) {
		this.dateOfExpiry = dateOfExpiry;
	}
	public Vegetarian getVegetarian() {
		return vegetarian;
	}
	public void setVegetarian(Vegetarian vegetarian) {
		this.vegetarian = vegetarian;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		return "FoodItems [itemCode=" + itemCode + ", itemName=" + itemName + ", unitPrice=" + unitPrice
				+ ", dateOfMfg=" + dateOfMfg + ", dateOfExpiry=" + dateOfExpiry + ", vegetarian=" + vegetarian
				+ ", quantity=" + quantity + "]";
	}
	
	
}
