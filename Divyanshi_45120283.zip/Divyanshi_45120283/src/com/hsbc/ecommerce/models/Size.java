package com.hsbc.ecommerce.models;

public enum Size {
LARGE,MEDIUM,SMALL;
}
