package com.hsbc.ecommerce.models;

import java.io.Serializable;

public class Apparel extends Category implements Serializable{

	private byte apparelItemCode;
	private String apparelItemName;
	private int apparelUnitPrice;
	private Size size;
	private Material material;
	private int quantityApparel;
	public byte getApparelItemCode() {
		return apparelItemCode;
	}
	public void setApparelItemCode(byte apparelItemCode) {
		this.apparelItemCode = apparelItemCode;
	}
	public String getApparelItemName() {
		return apparelItemName;
	}
	public void setApparelItemName(String apparelItemName) {
		this.apparelItemName = apparelItemName;
	}
	public int getApparelUnitPrice() {
		return apparelUnitPrice;
	}
	public void setApparelUnitPrice(int apparelUnitPrice) {
		this.apparelUnitPrice = apparelUnitPrice;
	}
	public Size getSize() {
		return size;
	}
	public void setSize(Size size) {
		this.size = size;
	}
	public Material getMaterial() {
		return material;
	}
	public void setMaterial(Material material) {
		this.material = material;
	}
	public int getQuantityApparel() {
		return quantityApparel;
	}
	public void setQuantityApparel(int quantityApparel) {
		this.quantityApparel = quantityApparel;
	}
	@Override
	public String toString() {
		return "Apparel [apparelItemCode=" + apparelItemCode + ", apparelItemName=" + apparelItemName
				+ ", apparelUnitPrice=" + apparelUnitPrice + ", size=" + size + ", material=" + material
				+ ", quantityApparel=" + quantityApparel + "]";
	}
	
	
}
