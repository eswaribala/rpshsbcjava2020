package com.hsbc.ecommerce.models;

public enum Vegetarian {
YES,NO;
}
