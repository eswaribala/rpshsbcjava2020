package com.hsbc.ecommerce.dao;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import com.hsbc.ecommerce.models.Apparel;
import com.hsbc.ecommerce.models.Category;
import com.hsbc.ecommerce.models.Electronics;
import com.hsbc.ecommerce.models.FoodItems;


//Category Dao Interface
public interface CategoryDao {
	boolean addCategory(List<Category> categoryList) throws FileNotFoundException, IOException;
	List<Category> getCategory() throws FileNotFoundException, IOException, ClassNotFoundException;
	
	boolean addFoodCategory(List<FoodItems> categoryList) throws IOException;
	List<FoodItems> getFoodCategory() throws IOException, ClassNotFoundException;
	
	boolean addApparelCategory(List<Apparel> categoryList) throws FileNotFoundException, IOException;
	List<Apparel> getApparelCategory() throws IOException, ClassNotFoundException;
	
	boolean addElectronicsCategory(List<Electronics> categoryList) throws IOException;
	List<Electronics> getElectronicCategory() throws IOException, ClassNotFoundException;
	Category getCategoryByQuantity(int quantity);
	
}
