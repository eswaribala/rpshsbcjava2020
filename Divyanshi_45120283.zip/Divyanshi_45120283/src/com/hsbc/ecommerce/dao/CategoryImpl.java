package com.hsbc.ecommerce.dao;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

import com.hsbc.ecommerce.models.Apparel;
import com.hsbc.ecommerce.models.Category;
import com.hsbc.ecommerce.models.Electronics;
import com.hsbc.ecommerce.models.FoodItems;

public class CategoryImpl implements CategoryDao{

	private File file;
	private FileOutputStream fileOutputStream;
	private FileInputStream fileInputStream;
	private ObjectOutputStream objectOutputStream;
	private ObjectInputStream objectInputStream;
	
	public CategoryImpl(String fileName,int level) throws IOException
	{
		file=FileHelper.createFile(fileName,level);
	}
	@Override
	public boolean addCategory(List<Category> categoryList) throws IOException {
		// TODO Auto-generated method stub
		fileOutputStream=new FileOutputStream(file,true);
		objectOutputStream=new ObjectOutputStream(fileOutputStream);
		for(Category category : categoryList)
		{
			objectOutputStream.writeObject(category);
		}
		objectOutputStream.close();
		fileOutputStream.close();
		
		
		return true;
	}

	@Override
	public List<Category> getCategory() throws IOException, ClassNotFoundException {
		// TODO Auto-generated method stub
		fileInputStream=new FileInputStream(file);
		objectInputStream=new ObjectInputStream(fileInputStream);
		List<Category> categoryList=new ArrayList<Category>();
		Category category=null;		
		try
		{
			
			while((category=(Category) objectInputStream.readObject())!=null)
				categoryList.add(category);			
					
		}
		catch(EOFException exception)
		{
			
		}
		finally
		{
		objectInputStream.close();
		fileInputStream.close();
		}
		
		return categoryList ;
	}

	//foodItems
	@Override
	public boolean addFoodCategory(List<FoodItems> foodItemList) throws IOException {
		// TODO Auto-generated method stub
		fileOutputStream=new FileOutputStream(file,true);
		objectOutputStream=new ObjectOutputStream(fileOutputStream);
		for(FoodItems foodCategory : foodItemList)
		{
			objectOutputStream.writeObject(foodCategory);
		}
		objectOutputStream.close();
		fileOutputStream.close();
		
		
		return true;
	
	}

	@Override
	public List<FoodItems> getFoodCategory() throws IOException, ClassNotFoundException {
		// TODO Auto-generated method stub
		fileInputStream=new FileInputStream(file);
		objectInputStream=new ObjectInputStream(fileInputStream);
		List<FoodItems> foodItemsList=new ArrayList<FoodItems>();
		FoodItems foodItems=null;		
		try
		{
			
			while((foodItems=(FoodItems) objectInputStream.readObject())!=null)
				foodItemsList.add(foodItems);			
					
		}
		catch(EOFException exception)
		{
			
		}
		finally
		{
		objectInputStream.close();
		fileInputStream.close();
		}
		
		return foodItemsList;
	}

	@Override
	public boolean addApparelCategory(List<Apparel> apparelList) throws IOException {
		// TODO Auto-generated method stub
		fileOutputStream=new FileOutputStream(file,true);
		objectOutputStream=new ObjectOutputStream(fileOutputStream);
		for(Apparel appCategory : apparelList)
		{
			objectOutputStream.writeObject(appCategory);
		}
		objectOutputStream.close();
		fileOutputStream.close();
		
		
		return true;
	}

	@Override
	public List<Apparel> getApparelCategory() throws IOException, ClassNotFoundException {
		// TODO Auto-generated method stub
		fileInputStream=new FileInputStream(file);
		objectInputStream=new ObjectInputStream(fileInputStream);
		List<Apparel> apparelList=new ArrayList<Apparel>();
		Apparel apparel=null;		
		try
		{
			
			while((apparel=(Apparel) objectInputStream.readObject())!=null)
				apparelList.add(apparel);			
					
		}
		catch(EOFException exception)
		{
			
		}
		finally
		{
		objectInputStream.close();
		fileInputStream.close();
		}
		return apparelList;
	}

	@Override
	public boolean addElectronicsCategory(List<Electronics> electronicsList) throws IOException {
		// TODO Auto-generated method stub
		fileOutputStream=new FileOutputStream(file,true);
		objectOutputStream=new ObjectOutputStream(fileOutputStream);
		for(Electronics eCategory : electronicsList)
		{
			objectOutputStream.writeObject(eCategory);
		}
		objectOutputStream.close();
		fileOutputStream.close();
		
		
		return true;
	}

	@Override
	public List<Electronics> getElectronicCategory() throws IOException, ClassNotFoundException {
		// TODO Auto-generated method stub
		fileInputStream=new FileInputStream(file);
		objectInputStream=new ObjectInputStream(fileInputStream);
		List<Electronics> electronicsList=new ArrayList<Electronics>();
		Electronics electronics=null;		
		try
		{
			
			while((electronics=(Electronics) objectInputStream.readObject())!=null)
				electronicsList.add(electronics);			
					
		}
		catch(EOFException exception)
		{
			
		}
		finally
		{
		objectInputStream.close();
		fileInputStream.close();
		}
		return electronicsList;
	}

	@Override
	public Category getCategoryByQuantity(int quantity) {
		// TODO Auto-generated method stub
		Category category=null;
		return category;
	}

}
