package com.hsbc.ecommerce.bl;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import com.hsbc.ecommerce.exceptions.QuantityException;
import com.hsbc.ecommerce.exceptions.UnitPriceException;
import com.hsbc.ecommerce.models.Apparel;
import com.hsbc.ecommerce.models.Category;
import com.hsbc.ecommerce.models.Electronics;
import com.hsbc.ecommerce.models.FoodItems;

public interface CategoryBL {
	boolean addCategory(List<Category> categoryList) throws FileNotFoundException, IOException, QuantityException;
	List<Category> getCategory() throws FileNotFoundException, IOException, ClassNotFoundException, UnitPriceException;
	
	boolean addFoodCategory(List<FoodItems> categoryList) throws IOException, QuantityException;
	List<FoodItems> getFoodCategory() throws IOException, ClassNotFoundException, UnitPriceException;
	
	boolean addApparelCategory(List<Apparel> categoryList) throws FileNotFoundException, IOException, QuantityException;
	List<Apparel> getApparelCategory() throws IOException, ClassNotFoundException;
	
	boolean addElectronicsCategory(List<Electronics> categoryList) throws IOException, QuantityException;
	List<Electronics> getElectronicCategory() throws IOException, ClassNotFoundException;
	Category getCategoryByQuantity(int quantity);
}
