package com.hsbc.ecommerce.exceptions;

public class UnitPriceException extends Exception{
public UnitPriceException(String msg)
{
	super(msg);
}
}
