package com.hsbc.ecommerce.exceptions;

public class FileCreateException extends Exception{

	public FileCreateException(String message)
	{
		super(message);
	}
}
