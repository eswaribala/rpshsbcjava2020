package com.hsbc.ecommerce.exceptions;

public class QuantityException extends Exception {
public QuantityException(String msg)
{
	super(msg);
}
}
