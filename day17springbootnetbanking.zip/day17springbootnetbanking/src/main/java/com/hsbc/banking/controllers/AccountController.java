package com.hsbc.banking.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AccountController {
	
	@GetMapping("/accounts")
	public List<String> getAccounts()
	{
		List<String> accountList=new ArrayList<>();
		accountList.add("Demat");
		accountList.add("Savings");
		accountList.add("Recurring");
		accountList.add("Loan");
		return  accountList;
	}
	

}
