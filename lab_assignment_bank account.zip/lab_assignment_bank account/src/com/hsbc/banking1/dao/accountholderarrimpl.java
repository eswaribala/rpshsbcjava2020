package com.hsbc.banking1.dao;

import com.hsbc.banking2.model.bankholder;

public class accountholderarrimpl implements accountholderDao {
	private bankholder[] bankholderlist=new bankholder[5];
	private static int pos;
	private static double amount;
	
	@Override
	
	public boolean createaccount(bankholder p) {
		// TODO Auto-generated method stub
		
		bankholderlist[pos]=p;
		pos++;
		return true;
	}

	@Override
	public bankholder[] getallbankholderholder() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public bankholder getbankholder(long policyno) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean updatebankholder(bankholder p, long accno) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean delete(long accno) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void withdraw(float amt) {
		// TODO Auto-generated method stub
		
		
		amount=amount-amt;
	
		
		
	}

	@Override
	public void deposit(double amt) {
		// TODO Auto-generated method stub
		amount=amount+amt;
		
	}

	@Override
	public double getbalance() {
		// TODO Auto-generated method stub
		return amount;
	}

	@Override
	public void addMonthlyInt(double interest) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addHalfYrlyInt(double interest) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addAnnualInt(double interest) {
		// TODO Auto-generated method stub
		amount=amount+interest;
	}

	
}
