package com.hsbc.banking1.dao;

import com.hsbc.banking2.model.bankholder;

public interface accountholderDao {

	
	boolean createaccount(bankholder p);
	//Retrieve all
	bankholder[] getallbankholderholder();
	//Retrieve by id
	bankholder getbankholder(long policyno);
	//updating
	boolean updatebankholder(bankholder p,long accno);
	//delete policyholder by id
	boolean delete(long accno);
	
	public void withdraw(float amt);
	public void deposit(double amt);
	public double getbalance();
	public void addMonthlyInt(double interest);
	public void addHalfYrlyInt(double interest);
	public void addAnnualInt(double interest);
}
