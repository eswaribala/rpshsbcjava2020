package com.hsbc.banking1.bl;

import com.hsbc.banking2.model.bankholder;

public interface Account {

	boolean createaccount(bankholder p);
	//Retrieve all
	bankholder[] getallbankholderholder();
	//Retrieve by id
	bankholder getbankholder(long policyno);
	//updating
	boolean updatebankholder(bankholder p,long accno);
	//delete policyholder by id
	boolean delete(long accno);
}
