package com.hsbc.banking1.bl;

public interface interest {

	public final double  savingsInterest=6.0;
	public final double fixedaccInterest=5.0;
	public final double  personalloanI=12.0;
	public final double housingloanI=12.0;
	
	public double calculateInt();
}
