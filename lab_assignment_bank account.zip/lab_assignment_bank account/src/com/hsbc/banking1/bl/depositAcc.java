package com.hsbc.banking1.bl;

public interface depositAcc {

	public boolean withdraw(float a);
	public void deposit(double a);
	public double getbalance();
}
