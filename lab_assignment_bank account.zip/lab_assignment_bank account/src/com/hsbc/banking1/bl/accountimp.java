package com.hsbc.banking1.bl;

import java.util.Random;

import com.hsbc.banking1.dao.accountholderDao;
import com.hsbc.banking1.dao.accountholderarrimpl;
import com.hsbc.banking2.model.bankholder;

public class accountimp implements Account {
private static accountholderDao d1=new accountholderarrimpl();
	@Override
	public boolean createaccount(bankholder p) {
		// TODO Auto-generated method stub
		boolean status=false;
		p.setAccno(new Random().nextInt(1000));
		status=d1.createaccount(p);
		return status;
	}

	@Override
	public bankholder[] getallbankholderholder() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public bankholder getbankholder(long policyno) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean updatebankholder(bankholder p, long accno) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean delete(long accno) {
		// TODO Auto-generated method stub
		return false;
	}

	

}
