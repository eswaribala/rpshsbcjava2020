package com.hsbc.banking1.bl;

public interface creditInterest extends interest {

	public void addMonthlyInt(double interest);
	public void addHalfYrlyInt(double interest);
	public void addAnnualInt(double interest);
}
