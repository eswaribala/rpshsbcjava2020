package com.hsbc.banking1.bl;

import com.hsbc.banking1.dao.accountholderDao;
import com.hsbc.banking1.dao.accountholderarrimpl;

public class savingsaccount implements depositAcc,creditInterest {
	private static accountholderDao d1=new accountholderarrimpl();
	@Override
	public void addMonthlyInt(double interest) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addHalfYrlyInt(double interest) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addAnnualInt(double interest) {
		// TODO Auto-generated method stub
		d1.addAnnualInt(interest);
	}

	

	
	@Override
	public double getbalance() {
		// TODO Auto-generated method stub
		
		double bal=d1.getbalance();
		return bal;
	}

	@Override
	public boolean withdraw(float a) {
		// TODO Auto-generated method stub
		boolean status=false;
		if(d1.getbalance()>a)
		{
			
		///validations//
		d1.withdraw(a);
		status=true;
		
		}
		return status;
	}

	@Override
	public void deposit(double a) {
		// TODO Auto-generated method stub

		//double bal=d1.getbalance();
		
		d1.deposit(a);
	}

	@Override
	public double calculateInt() {
		// TODO Auto-generated method stub
		System.out.println(savingsInterest);
		double interestfor1year= (savingsInterest*1*d1.getbalance())/100;
		return interestfor1year;
	}

}
