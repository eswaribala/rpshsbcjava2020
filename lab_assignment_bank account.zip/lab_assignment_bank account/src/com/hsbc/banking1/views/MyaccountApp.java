package com.hsbc.banking1.views;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Scanner;

import com.hsbc.banking1.bl.Account;
import com.hsbc.banking1.bl.accountimp;
import com.hsbc.banking1.bl.creditInterest;
import com.hsbc.banking1.bl.depositAcc;
import com.hsbc.banking1.bl.savingsaccount;
import com.hsbc.banking2.model.bankholder;


public class MyaccountApp {

	
private static  Account a1=new accountimp();///why this is made static//
	private static depositAcc a2=new savingsaccount();
	private static creditInterest a3=new savingsaccount();

	private static void menu()
	{
		System.out.println("Menu");
		System.out.println("1.add policy holder");
		//System.out.println("2.update ");
		//System.out.println("3. delete");
		//System.out.println("4.read all policyholder");
	//	System.out.println("5. show holder by id");
		
		System.out.println("99. Exit");



		
	}
	
	private static void menu1()
	{
		System.out.println("Menu");
		System.out.println("1.deposit money");
		System.out.println("2. check balance ");
		System.out.println("3.withdraw money");
		System.out.println("4.interest on savings  account money for 1 year");
		System.out.println("5. show holder by id");
		
		System.out.println("99. Exit");



		
	}
	
	public static void operations(int choice)
	{
		Scanner s=new Scanner(System.in);	
		switch(choice)
		{
		
		
		case 1:
			
		    System.out.println("Enter amount to be deposited");
		    double amt=s.nextDouble();
		    s.nextLine();
			a2.deposit(amt);
			System.out.println("deposited");
			break;
	   		
		case 2:
			//check balance
			double bal=a2.getbalance();
			System.out.println("balance is"+bal);			
			break;
			
		case 3:
			System.out.println("enter amount you wish to withdraw");
		    boolean status;
			status=a2.withdraw(s.nextFloat());
			s.nextLine();
			if(status)
			{
				System.out.println("Amount withdrawn successfully");
			}
			
		case 4:
			
			double interestfor1year=a3.calculateInt();
			a3.addAnnualInt(interestfor1year);
			
		}
		
	
	
	}
	
	public static void choiceimpl(int option)
	{
		DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd-MM-yyyy");
		Scanner s=new Scanner(System.in);
		switch(option)
		{
		
		
		case 1:
			//add
			
			////Read data from user to add values
			bankholder p=new bankholder();
			System.out.println("ENter name");   //name
			p.setName(s.nextLine());
			
			System.out.println("Enter balance");
			p.setBalance(s.nextFloat());
			float bal=p.getBalance();
			a2.deposit(bal);
			s.nextLine();
			
			
		
			if( a1.createaccount(p))
				System.out.println("Record Added.....");
			else
				System.out.println("Error in input..., Record not added");
			
			
			break;
		case 2:
			
			System.out.println("Enter account no whose info has to be updated");
			long no=s.nextLong();
			boolean status;
			bankholder p1=new bankholder();
			System.out.println("ENter name");   //name
			p1.setName(s.nextLine());
			System.out.println("enter acc no");
			long accno=s.nextLong();
			status=a1.updatebankholder(p1, accno);
			if(status==true)
			{
				System.out.println("updated");
			}
			else
			{
				System.out.println("not updated");
			}
			
			//update  left
			break;
		case 3:
			//delete
			System.out.println("enter acc policy no whose info shd be deleted");
			boolean statuse;
			statuse=a1.delete(s.nextLong());
			System.out.println(statuse);
			
			break;
		case 4:
			for(bankholder o:a1.getallbankholderholder())
			{
				if(o!=null)
				{
				System.out.println(o.getAccno());
				System.out.println(o.getName());
				System.out.println(o.getBalance());
				System.out.println(o);
				}
			}
			//get all
			break;
		case 5:
			//get one
			Scanner o=new Scanner(System.in);
			System.out.println("Enter policyholder id");
			long num=o.nextLong();
			bankholder res=null;
			res=a1.getbankholder(num);
				if(res!=null)
				{
				System.out.println(res.getAccno());
				System.out.println(res.getName());
				System.out.println(res.getBalance());
				System.out.println(o);
				}
			
			break;
		
			
			
		
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
       
		
		int choice=0;
		Scanner s=new Scanner(System.in);
		do
		{
		     menu();
		
			System.out.println("do you want to continue?choose bet 1 -99 ");	
			choice=s.nextInt();
			s.nextLine();
			choiceimpl(choice);
			
		}while(choice!=99);
		
		do
		{
		   
		
			
			
			menu1();
			System.out.println("do you want to continue?choose bet 1 -99 ");
			choice=s.nextInt();
			s.nextLine();

            operations(choice);
		}while(choice!=99);
		
		
		
	}

}
