Dao Layer          CategoryDao.java                 for creating methods like addFoodItem() etc
                   CategoryDaoImpl.java             This file contains methods that write objects into file and retrieve from the file
	           FileHelper.java                  This file is for Creating Files

Business Layer     CategoryBL.java                  Interface which conatins methods 
	           CategoryBLImpl.java              implements CategoryBL and handle Exceptions and rethrow the Exceptions


Model Layer        Apparel.java			   This files contains the properties of Categories  like itemname etc.
                   FoodItem.java
 		   Electronics.java   

View Layer          EcommerceApp.java              Contains UI for the User

Exception Layer     FileCreationException          This file throws Exception if File is not Created Properly.