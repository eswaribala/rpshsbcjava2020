package com.hsbc.ecommerce.view;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.hsbc.ecommerce.bl.CategoryBL;
import com.hsbc.ecommerce.bl.CategoryBLImpl;
import com.hsbc.ecommerce.exceptions.FileCreationException;
import com.hsbc.ecommerce.model.*;


public class EcommerceApp {
	
	private static CategoryBL categoryBl;
	Apparel apparel;
	Electronics electronics;
	
	
	// Add function Created for add food items
	public static void addFooditem()
	{  FoodItems fooditems=null;
	List<FoodItems> foodItemList=new ArrayList<FoodItems>();
		Scanner scanner = new Scanner(System.in);
		int numFoodItems;
		try {
			categoryBl=new CategoryBLImpl("h",1);
		} catch (FileCreationException e) {
			
			System.out.println(e.getMessage());
		}
		// Aksing users to how many Items he want to add
		System.out.println("Enter How many FoodItems You want to add");
		numFoodItems=scanner.nextInt();
		for(int i=0;i<numFoodItems;i++)
		{   fooditems = new FoodItems();
			System.out.println("Enter Food item code");
            fooditems.setItemcode(scanner.nextInt());
            scanner.nextLine();
            System.out.println("Enter Food item name");
            fooditems.setItemname(scanner.nextLine());
            System.out.println("Enter Food item quantity");
            fooditems.setQuantity(scanner.nextInt());
			foodItemList.add(fooditems);
		}
		try {
			System.out.println(CategoryBL.addFoodItem(foodItemList));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
		
		
	}
	public static void addApparel()
	{  Apparel apparel=null;
		Scanner scanner = new Scanner(System.in);
		
		int numApparels;
		try {
			categoryBl=new CategoryBLImpl("h",2);
		} catch (FileCreationException e) {
			
			System.out.println(e.getMessage());
		}
		// Asking users to how many Items he want to add
		System.out.println("Enter How many FoodItems You want to add");
		numApparels=scanner.nextInt();
		for(int i=0;i<numApparels;i++)
		{   apparel = new Apparel();
			System.out.println("Enter Apparel item code");
			apparel.setItemcode(scanner.nextInt());
            scanner.nextLine();
            System.out.println("Enter Apparel name");
            apparel.setItemname(scanner.nextLine());
            System.out.println("Enter Apparel quantity");
            apparel.setQuantity(scanner.nextInt());
			
		}
		
	}
	public static void main(String[] args)
	{
		int choice;
		
		// Creating a User Menu
		System.out.println("Enter Your Choice");
		System.out.println("1. Add FoodItem");
		System.out.println("2. Add Apparel");
        System.out.println("3. View FoodItems");
        System.out.println("4. View Apparels");
		System.out.println("5. Exit");
		Scanner scanner = new Scanner(System.in);
		choice = scanner.nextInt();
		
		switch(choice)
		{
		  case 1: addFooditem();
		          break;
		  case 2 : addApparel();
		          break;
		  case 3: break;
		  case 4: break;
		  default: 
			  System.out.println("Please enter Correct Number");
		}

        

 
		
		
	}
}
