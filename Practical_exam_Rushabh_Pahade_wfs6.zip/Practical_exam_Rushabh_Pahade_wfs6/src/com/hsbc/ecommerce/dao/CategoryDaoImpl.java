package com.hsbc.ecommerce.dao;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.List;

import com.hsbc.ecommerce.model.Apparel;
import com.hsbc.ecommerce.model.Electronics;
import com.hsbc.ecommerce.model.FoodItems;


public class CategoryDaoImpl implements CategoryDao{

	private File file;
	private FileOutputStream fileOutputStream;
	private FileInputStream fileInputStream;
	private ObjectOutputStream objectOutputStream;
	private ObjectInputStream objectInputStream;
	
	public CategoryDaoImpl(String fileName,int level) throws IOException
	{
		file = FileHelper.createFile(fileName, level);
	}
	
	@Override
	public boolean addFoodItem(List<FoodItems> fooditemlist) throws IOException {
		// TODO Auto-generated method stub
		fileOutputStream=new FileOutputStream(file,true);
		objectOutputStream=new ObjectOutputStream(fileOutputStream);
		for(FoodItems fooditems : fooditemlist)
		{
			objectOutputStream.writeObject(fooditems);
		}
		objectOutputStream.close();
		fileOutputStream.close();
		
		
		return true;
		
	}

	@Override
	public boolean addApparel(List<Apparel> apparelslist) throws IOException {
		// TODO Auto-generated method stub
		fileOutputStream=new FileOutputStream(file,true);
		objectOutputStream=new ObjectOutputStream(fileOutputStream);
		for(Apparel apparel : apparelslist)
		{
			objectOutputStream.writeObject(apparel);
		}
		objectOutputStream.close();
		fileOutputStream.close();
		return true;
	}

	@Override
	public boolean addElectronics(List<Electronics> electronicslist) throws IOException {
		// TODO Auto-generated method stub
		fileOutputStream=new FileOutputStream(file,true);
		objectOutputStream=new ObjectOutputStream(fileOutputStream);
		for(Electronics electronics : electronicslist)
		{
			objectOutputStream.writeObject(electronics);
		}
		objectOutputStream.close();
		fileOutputStream.close();
		return true;
	}
	

}
