package com.hsbc.ecommerce.dao;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class FileHelper {
	
	private static File file;
	public static File createFile(String fileName,int level) throws IOException
	{
		
	

		
		if(level==1)
		{
		
		file=new File("FoodItem.txt");
		if(!file.exists())
			file.createNewFile();
		
		}
		else if(level==2)
		{
			file=new File("Apparel.txt");
			if(!file.exists())
				file.createNewFile();
			else
				file.delete();
		}
		else
		{
			file=new File("Electronics.txt");
			if(!file.exists())
				file.createNewFile();
			else
				file.delete();
		}
		
        return file; 	
		
		
	}

}
