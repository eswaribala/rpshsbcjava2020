package com.hsbc.ecommerce.dao;

import java.io.IOException;
//import java.io.IOException;
import java.util.List;

import com.hsbc.ecommerce.model.*;


public interface CategoryDao {
  
	boolean addFoodItem(List<FoodItems> fooditemslist) throws IOException;
	boolean addApparel(List<Apparel> apparelslist) throws IOException;
	boolean addElectronics(List<Electronics> electronicslist) throws IOException;
	

	
}
