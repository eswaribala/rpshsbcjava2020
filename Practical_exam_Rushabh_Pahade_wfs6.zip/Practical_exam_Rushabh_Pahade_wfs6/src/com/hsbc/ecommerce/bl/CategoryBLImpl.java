package com.hsbc.ecommerce.bl;

import java.io.IOException;
import java.util.List;

import com.hsbc.ecommerce.dao.CategoryDao;
import com.hsbc.ecommerce.dao.CategoryDaoImpl;
import com.hsbc.ecommerce.bl.*;

import com.hsbc.ecommerce.exceptions.FileCreationException;
import com.hsbc.ecommerce.model.Apparel;
import com.hsbc.ecommerce.model.Electronics;
import com.hsbc.ecommerce.model.FoodItems;

public class CategoryBLImpl implements CategoryBL{
private CategoryDao categoryDao;
	
	public CategoryBLImpl(String filename,int level) throws FileCreationException
	{
		try {
			categoryDao=new CategoryDaoImpl(filename,level);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			//re throwing
			throw new FileCreationException("Problem in creating the file, "
					+ "Check file Name and Location ");
		}
	}

	public boolean addFoodItem(List<FoodItems> fooditemslist) throws IOException {
		// TODO Auto-generated method stub
		return categoryDao.addFoodItem(fooditemslist);
	}

	@Override
	public boolean addApparel(List<Apparel> apparelslist) throws IOException {
		// TODO Auto-generated method stub
		return categoryDao.addApparel(apparelslist);
	}

	@Override
	public boolean addElectronics(List<Electronics> electronicslist) throws IOException {
		// TODO Auto-generated method stub
		return categoryDao.addElectronics(electronicslist);
	}
	

}
