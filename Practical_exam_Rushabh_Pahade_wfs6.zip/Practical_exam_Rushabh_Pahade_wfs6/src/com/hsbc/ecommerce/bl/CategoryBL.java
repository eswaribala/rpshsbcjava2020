//@author Rushabh Pahade.

package com.hsbc.ecommerce.bl;

import java.io.IOException;
import java.util.List;

import com.hsbc.ecommerce.model.Apparel;
import com.hsbc.ecommerce.model.Electronics;
import com.hsbc.ecommerce.model.FoodItems;

public interface CategoryBL {
	static boolean addFoodItem(List<FoodItems> fooditemslist) throws IOException {
		// TODO Auto-generated method stub
		return false;
	}
	static boolean addApparel(List<Apparel> apparelslist) throws IOException {
		// TODO Auto-generated method stub
		return false;
	}
	boolean addElectronics(List<Electronics> electronicslist) throws IOException;
	
}
