package com.hsbc.ecommerce.model;

import java.time.LocalDate;

public class Electronics {
 
	private int itemcode;
	private String itemname;
	private int unitprice;
	private int warranty;
	private int quantity;
	public int getItemcode() {
		return itemcode;
	}
	public void setItemcode(int itemcode) {
		this.itemcode = itemcode;
	}
	public String getItemname() {
		return itemname;
	}
	public void setItemname(String itemname) {
		this.itemname = itemname;
	}
	public int getUnitprice() {
		return unitprice;
	}
	public void setUnitprice(int unitprice) {
		this.unitprice = unitprice;
	}
	public int getWarranty() {
		return warranty;
	}
	public void setWarranty(int warranty) {
		this.warranty = warranty;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		return "Electronics [itemcode=" + itemcode + ", itemname=" + itemname + ", unitprice=" + unitprice
				+ ", warranty=" + warranty + ", quantity=" + quantity + "]";
	}
	
}
