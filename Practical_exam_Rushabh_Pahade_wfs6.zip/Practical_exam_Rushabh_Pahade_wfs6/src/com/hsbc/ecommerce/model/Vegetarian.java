package com.hsbc.ecommerce.model;

public enum Vegetarian {

	Yes, no
}
