package com.hsbc.ecommerce.model;

import java.time.LocalDate;

public class Apparel {
	private int itemcode;
	private String itemname;
	private int unitprice;
	private int size;
	private Material material;
	private int quantity;
	public int getItemcode() {
		return itemcode;
	}
	public void setItemcode(int itemcode) {
		this.itemcode = itemcode;
	}
	public String getItemname() {
		return itemname;
	}
	public void setItemname(String itemname) {
		this.itemname = itemname;
	}
	public int getUnitprice() {
		return unitprice;
	}
	public void setUnitprice(int unitprice) {
		this.unitprice = unitprice;
	}
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
	public Material getMaterial() {
		return material;
	}
	public void setMaterial(Material material) {
		this.material = material;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		return "Apparel [itemcode=" + itemcode + ", itemname=" + itemname + ", unitprice=" + unitprice + ", size="
				+ size + ", material=" + material + ", quantity=" + quantity + "]";
	}
	
}
