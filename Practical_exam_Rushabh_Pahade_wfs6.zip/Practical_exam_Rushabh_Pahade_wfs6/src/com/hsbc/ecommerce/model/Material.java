package com.hsbc.ecommerce.model;

public enum Material {
  cotton,woolen
}
