import {FooterMenu} from './models.footermenu';

export let footerMenuData:FooterMenu[]=[
  new FooterMenu('Regulatory Disclosures',''),
  new FooterMenu('Hyperlink Policy',''),
  new FooterMenu('Privacy Statement',''),
  new FooterMenu('Site Term',''),
  new FooterMenu('Site Map','')

]
