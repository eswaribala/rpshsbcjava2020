package com.hsbc.ecommerce.bl;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import com.hsbc.ecommerce.dao.CategoryDao;
import com.hsbc.ecommerce.dao.CategoryImpl;
import com.hsbc.ecommerce.exceptions.FileCreateException;
import com.hsbc.ecommerce.exceptions.QuantityException;
import com.hsbc.ecommerce.exceptions.UnitPriceException;
import com.hsbc.ecommerce.models.Apparel;
import com.hsbc.ecommerce.models.Category;
import com.hsbc.ecommerce.models.Electronics;
import com.hsbc.ecommerce.models.FoodItems;
import com.hsbc.insurance.exceptions.VehicleCreationException;
import com.hsbc.insurance.exceptions.VehicleRetrievalException;
import com.hsbc.insurance.models.Vehicle;

public class CategoryBLImpl implements CategoryBL {

	
private CategoryDao categoryDao;
	
	public CategoryBLImpl(String fileName,int level) throws FileCreateException
	{
		try {
			categoryDao=new CategoryImpl(fileName,level);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			//re throwing
			throw new FileCreateException("Problem in creating the file, "
					+ "Check file Name and Location ");
		}
	}
	
	
	@Override
	public boolean addCategory(List<Category> categoryList) throws FileNotFoundException, IOException, QuantityException {
		// TODO Auto-generated method stub
		boolean status=false;
		try {
			status=categoryDao.addCategory(categoryList);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			throw new QuantityException("Quantity should not be negative");
		} 
		return status;
	}

	@Override
	public List<Category> getCategory() throws FileNotFoundException, IOException, ClassNotFoundException, UnitPriceException {
		// TODO Auto-generated method stub
		List<Category> categoryList=null;
		try {
			categoryList=categoryDao.getCategory();
		} catch (IOException|ClassNotFoundException e) {
			// TODO Auto-generated catch block
			throw new UnitPriceException("Unit Price Missing");
		} 
		
		return categoryList;
	}

	@Override
	public boolean addFoodCategory(List<FoodItems> categoryFoodList) throws IOException, QuantityException {
		// TODO Auto-generated method stub
		boolean status=false;
		try {
			status=categoryDao.addFoodCategory(categoryFoodList);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			throw new QuantityException("Quantity should not be negative");
		} 
		return status;
	}

	@Override
	public List<FoodItems> getFoodCategory() throws IOException, ClassNotFoundException{
		// TODO Auto-generated method stub
		List<FoodItems> categoryList=null;
		try {
			categoryList=categoryDao.getFoodCategory();
		} catch (IOException|ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
		return categoryList;
	}

	@Override
	public boolean addApparelCategory(List<Apparel> categoryList) throws FileNotFoundException, IOException, QuantityException {
		// TODO Auto-generated method stub
		boolean status=false;
		try {
			status=categoryDao.addApparelCategory(categoryList);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			throw new QuantityException("Quantity should not be negative");
		} 
		return status;
	}

	@Override
	public List<Apparel> getApparelCategory() throws IOException, ClassNotFoundException {
		// TODO Auto-generated method stub
		List<Apparel> categoryList=null;
		try {
			categoryList=categoryDao.getApparelCategory();
		} catch (IOException|ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
		return categoryList;
	}

	@Override
	public boolean addElectronicsCategory(List<Electronics> categoryList) throws IOException, QuantityException {
		// TODO Auto-generated method stub
		boolean status=false;
		try {
			status=categoryDao.addElectronicsCategory(categoryList);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			throw new QuantityException("Quantity should not be negative");
		} 
		return status;
	}

	@Override
	public List<Electronics> getElectronicCategory() throws IOException, ClassNotFoundException {
		// TODO Auto-generated method stub
		List<Electronics> categoryList=null;
		try {
			categoryList=categoryDao.getElectronicCategory();
		} catch (IOException|ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
		return categoryList;
	}

	@Override
	public Category getCategoryByQuantity(int quantity) {
		// TODO Auto-generated method stub
		Category category=null;
		return category;
	}
	
}
