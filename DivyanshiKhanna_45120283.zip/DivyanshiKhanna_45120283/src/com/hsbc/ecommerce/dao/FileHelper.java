package com.hsbc.ecommerce.dao;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class FileHelper {
	
	private static File file;
	public static File createFile(String fileName,int level) throws IOException
	{
		
		DateTimeFormatter formatter=DateTimeFormatter
	             .ofPattern("dd-MM-yyyy");	

		//create file
		
		if(level==1)
		{
		
		file=new File("Food Items"+fileName);
		if(!file.exists())
			file.createNewFile();
		else
			file.delete();
		}
		else if(level==2)
		{
			file=new File("Apparel"+fileName);
			if(!file.exists())
				file.createNewFile();
			else
				file.delete();
		}
		else
		{
			file=new File("Electronics"+fileName);
			if(!file.exists())
				file.createNewFile();
			else
				file.delete();
		}
		
        return file; 	
		
		
	}

}
