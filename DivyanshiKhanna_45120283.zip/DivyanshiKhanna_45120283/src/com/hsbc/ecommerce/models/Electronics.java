package com.hsbc.ecommerce.models;

import java.io.Serializable;

public class Electronics extends Category implements Serializable{
	private byte electronicItemCode;
	private String electronicItemName;
	private int electronicUnitPrice;
	private byte warranty;
	private int quantitySold;
	public byte getElectronicItemCode() {
		return electronicItemCode;
	}
	public void setElectronicItemCode(byte electronicItemCode) {
		this.electronicItemCode = electronicItemCode;
	}
	public String getElectronicItemName() {
		return electronicItemName;
	}
	public void setElectronicItemName(String electronicItemName) {
		this.electronicItemName = electronicItemName;
	}
	public int getElectronicUnitPrice() {
		return electronicUnitPrice;
	}
	public void setElectronicUnitPrice(int electronicUnitPrice) {
		this.electronicUnitPrice = electronicUnitPrice;
	}
	public byte getWarranty() {
		return warranty;
	}
	public void setWarranty(byte warranty) {
		this.warranty = warranty;
	}
	public int getQuantitySold() {
		return quantitySold;
	}
	public void setQuantitySold(int quantitySold) {
		this.quantitySold = quantitySold;
	}
	
	
}
