package com.hsbc.ecommerce.models;

public enum Material {
COTTON,WOOLEN;
}
