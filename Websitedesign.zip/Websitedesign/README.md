# Websitedesign
Hsbc training for website deisgn using pure html and css
Ajax call, form creation and pure HTMl and css
