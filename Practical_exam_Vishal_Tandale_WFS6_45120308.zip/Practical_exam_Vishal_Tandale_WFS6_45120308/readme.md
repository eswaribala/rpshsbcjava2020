layer			file			description

data access layer	productDao.java
			productDaoImpl.java
			filehelper.java

business layer		productBL.java
			productBLImpl.java
			
utility layer		ProductApp.java

