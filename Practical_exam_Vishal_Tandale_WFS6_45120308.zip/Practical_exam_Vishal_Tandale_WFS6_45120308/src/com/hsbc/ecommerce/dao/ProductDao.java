package com.hsbc.ecommerce.dao;


import com.hsbc.ecommerce.models.Product;


/**
 * @author Vishal
 * purpose: interface for dao layer
 */
public interface ProductDao {

	boolean addProduct(Product product);
	Product getProduct();
	

}
