package com.hsbc.ecommerce.dao;



import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import com.hsbc.ecommerce.dao.FileHelper;
import com.hsbc.ecommerce.models.Product;

/**
 * @author Vishal
 * purpose: class for dao layer layer implementation
 */
public class ProductDaoImpl implements ProductDao{
	private File file;
	private DataInputStream dataInputStream;
	private DataOutputStream dataOutputStream;
	
		
	public ProductDaoImpl(String fileName) throws IOException {
		super();
		file=FileHelper.createFile(fileName);
		dataInputStream=new DataInputStream(new FileInputStream(file));
		dataOutputStream=new DataOutputStream(new FileOutputStream(file));
	}
	
	@Override
	public boolean addProduct(Product product) {
		return false;
	}


	

	@Override
	public Product getProduct() {
		
		return null;
	}
	
}
