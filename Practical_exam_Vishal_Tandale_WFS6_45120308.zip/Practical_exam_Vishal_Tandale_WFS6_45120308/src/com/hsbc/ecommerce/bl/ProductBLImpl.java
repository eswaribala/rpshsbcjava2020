package com.hsbc.ecommerce.bl;

import java.util.List;

import com.hsbc.ecommerce.models.Product;



/**
 * @author Vishal
 * purpose: business layer implementation
 */
public class ProductBLImpl implements ProductBL {

	@Override
	public boolean addProduct(Product product) {
		
		return false;
	}

	@Override
	public List<Product> getSortedProducts(String choice) {
		
		return null;
	}




}
