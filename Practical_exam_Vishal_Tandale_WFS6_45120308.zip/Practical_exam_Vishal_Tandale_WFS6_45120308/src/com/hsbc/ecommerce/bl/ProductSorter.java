package com.hsbc.ecommerce.bl;

import java.util.Comparator;

import com.hsbc.ecommerce.models.Product;

/**
 * @author Vishal
 * purpose: sorter class for products
 */
public class ProductSorter implements Comparator<Product> {

	@Override
	public int compare(Product o1, Product o2) {
		// TODO Auto-generated method stub
		if( o1.getQuantity() > o2.getQuantity()) {
			return 1;
		} else if( o2.getQuantity() < o2.getQuantity()) {
			return -1;
		} else {
			return 0;
		}
	}

}
