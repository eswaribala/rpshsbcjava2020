package com.hsbc.ecommerce.bl;

import java.util.List;
import com.hsbc.ecommerce.models.Product;



/**
 * @author Vishal
 * purpose: interface for business layer
 */
public interface ProductBL {
	boolean addProduct(Product product);
	List<Product> getSortedProducts(String choice);
	
	

}
