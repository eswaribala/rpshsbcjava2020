package com.hsbc.ecommerce.exceptions;



/**
 * @author Vishal
 * purpose: customised exception for product not found
 */
public class ProductNotFoundException extends Exception {
	
	public ProductNotFoundException(String message) {
		super(message);
	}
}
