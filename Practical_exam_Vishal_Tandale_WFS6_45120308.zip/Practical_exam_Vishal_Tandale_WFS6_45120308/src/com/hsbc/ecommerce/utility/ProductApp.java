package com.hsbc.ecommerce.utility;

import java.util.Scanner;

import com.hsbc.ecommerce.bl.ProductBL;
import com.hsbc.ecommerce.bl.ProductBLImpl;
import com.hsbc.ecommerce.models.Product;

/**
 * @author Vishal
 * purpose: utility class for product
 */
public class ProductApp {
	public static Scanner scanner;
	private static String choice;
	
	public static void main(String[] args) {
		System.out.println("Enter the category of the product that you want to see (eg. food_items, apparel, electronics");
		scanner = new Scanner(System.in);
		choice = scanner.nextLine();
		
		ProductBL productBL = new ProductBLImpl();
					
		for(Product product: productBL.getSortedProducts(choice)) {
			System.out.println(product);
		}

	}
}
