package com.hsbc.ecommerce.models;



/**
 * @author Vishal
 * purpose: model class for apparel category
 */
public class Apparel extends Product {
	private String size;
	private String matreial;
	private int quantity;
	
	
	
	
	/**
	 * @param itemCode
	 * @param itemName
	 * @param unitPrice
	 * @param quantity
	 * @param size
	 * @param matreial
	 * @param quantity2
	 */
	public Apparel(int itemCode, String itemName, int unitPrice, int quantity, String size, String matreial,
			int quantity2) {
		super(itemCode, itemName, unitPrice, quantity);
		this.size = size;
		this.matreial = matreial;
		quantity = quantity2;
	}
	//getter and setters
	public String getSize() {
		return size;
	}
	public void setSize(String size) {
		this.size = size;
	}
	public String getMatreial() {
		return matreial;
	}
	public void setMatreial(String matreial) {
		this.matreial = matreial;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		return "Apparel [itemCode=" + itemCode + ", itemName=" + itemName + ", unitPrice=" + unitPrice + ", size="
				+ size + ", matreial=" + matreial + ", quantity=" + quantity + "]";
	}

	
	
}
