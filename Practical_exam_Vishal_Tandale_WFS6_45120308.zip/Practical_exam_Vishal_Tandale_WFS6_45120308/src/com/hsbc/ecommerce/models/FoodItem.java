package com.hsbc.ecommerce.models;

import java.time.LocalDate;

public class FoodItem extends Product{
	//food class variables
	private LocalDate dateOfMfg;
	private LocalDate dateOfExp;
	private boolean isVegeterian;
	
	
	/**
	 * @param itemCode
	 * @param itemName
	 * @param unitPrice
	 * @param quantity
	 * @param dateOfMfg
	 * @param dateOfExp
	 * @param isVegeterian
	 */
	public FoodItem(int itemCode, String itemName, int unitPrice, int quantity, LocalDate dateOfMfg,
			LocalDate dateOfExp, boolean isVegeterian) {
		super(itemCode, itemName, unitPrice, quantity);
		this.dateOfMfg = dateOfMfg;
		this.dateOfExp = dateOfExp;
		this.isVegeterian = isVegeterian;
	}
	public LocalDate getDateOfMfg() {
		return dateOfMfg;
	}
	public void setDateOfMfg(LocalDate dateOfMfg) {
		this.dateOfMfg = dateOfMfg;
	}
	public LocalDate getDateOfExp() {
		return dateOfExp;
	}
	public void setDateOfExp(LocalDate dateOfExp) {
		this.dateOfExp = dateOfExp;
	}
	public boolean isVegeterian() {
		return isVegeterian;
	}
	public void setVegeterian(boolean isVegeterian) {
		this.isVegeterian = isVegeterian;
	}
	
	@Override
	public String toString() {
		return "FoodItem [itemCode=" + itemCode + ", itemName=" + itemName + ", unitPrice=" + unitPrice + ", dateOfMfg="
				+ dateOfMfg + ", dateOfExp=" + dateOfExp + ", isVegeterian=" + isVegeterian + "]";
	}
	
	
	
}
