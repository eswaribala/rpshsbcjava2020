package com.hsbc.ecommerce.models;

public class Electronics extends Product{
	//because is warrenty is within limit of short
	private short warrenty;
	
	
	
	
	/**
	 * @param itemCode
	 * @param itemName
	 * @param unitPrice
	 * @param quantity
	 * @param warrenty
	 */
	public Electronics(int itemCode, String itemName, int unitPrice, int quantity, short warrenty) {
		super(itemCode, itemName, unitPrice, quantity);
		this.warrenty = warrenty;
	}


	@Override
	public String toString() {
		return "Electronics [warrenty=" + warrenty + ", itemCode=" + itemCode + ", itemName=" + itemName
				+ ", unitPrice=" + unitPrice + ", quantity=" + quantity + "]";
	}


	//getter and setters
	public short getWarrenty() {
		return warrenty;
	}
	public void setWarrenty(short warrenty) {
		this.warrenty = warrenty;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	 
	
}
