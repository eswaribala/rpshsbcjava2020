package com.hsbc.banking.models;

import java.util.Date;

public class SilverCustomer extends Customer{

	public SilverCustomer(Date dob) {
		super(dob);
		// TODO Auto-generated constructor stub
	}

	@Override
	public float offer(String season) {
		// TODO Auto-generated method stub
		float offer=0.025f;
		if(season.equals("NewYear"))
			offer=0.5f;		
		return offer;
	}

}
