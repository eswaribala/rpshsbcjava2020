package com.hsbc.banking.models;

import java.util.Date;

public class GoldCustomer extends Customer{

	public GoldCustomer(Date dob) {
		super(dob);
		// TODO Auto-generated constructor stub
	}

	@Override
	public float offer(String season) {
		// TODO Auto-generated method stub
		float offer=0.05f;
		if(season.equals("NewYear"))
			offer=0.1f;		
		return offer;
	}

}
