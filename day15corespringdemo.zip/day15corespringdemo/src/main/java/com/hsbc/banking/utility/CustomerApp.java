package com.hsbc.banking.utility;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.hsbc.banking.models.Bank;
import com.hsbc.banking.models.Branch;
import com.hsbc.banking.models.Customer;

public class CustomerApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//how spring works with xml
		
		//Spring containers		
		Resource resource=new ClassPathResource("com/hsbc/banking/"
				+ "resources/customer-bean.xml");		
		BeanFactory beanFactory=new XmlBeanFactory(resource);		
		//IOC		
		Customer customer1=(Customer) beanFactory.getBean("platinumCustomer");
		System.out.println("Platinum Customer Offer"+customer1.offer("Diwali"));
       //customer2 is loosely coupled
		Customer customer2=(Customer) beanFactory.getBean("customer");
		System.out.println(customer2.getSsn()+","+customer2.getPersonName()+","+customer2.getDob().toLocaleString());
		System.out.println("Customer Offer"+customer2.offer("Diwali"));
		
		Customer customer3=(Customer) beanFactory.getBean("platinumCustomer");
		System.out.println("Platinum Customer Offer"+customer3.offer("Diwali"));
		System.out.println(customer1.hashCode());
		System.out.println(customer3.hashCode());
		
		Bank bank=(Bank) beanFactory.getBean("bank");
		System.out.println(bank.getBankName());
		for(Branch branch: bank.getBranchList())
		{
			System.out.println(branch.getBranchCode());
		}
		
	}

}
