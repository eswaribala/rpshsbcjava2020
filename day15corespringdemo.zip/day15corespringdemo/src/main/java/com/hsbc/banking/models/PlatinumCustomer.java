package com.hsbc.banking.models;

import java.util.Date;

public class PlatinumCustomer extends  Customer{

	public PlatinumCustomer(Date dob) {
		super(dob);
		// TODO Auto-generated constructor stub
	}

	@Override
	public float offer(String season) {
		// TODO Auto-generated method stub
		float offer=0.1f;
		if(season.equals("NewYear"))
			offer=0.2f;		
		return offer;
	}

}
