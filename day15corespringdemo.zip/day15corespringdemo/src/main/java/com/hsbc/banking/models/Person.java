package com.hsbc.banking.models;

import java.util.Date;

public class Person {

	private String ssn;
	private String personName;
	private Date dob;
	
	public Person(Date dob) {
		super();
		this.dob = dob;
	}
	public String getSsn() {
		return ssn;
	}
	public void setSsn(String ssn) {
		this.ssn = ssn;
	}
	public String getPersonName() {
		return personName;
	}
	public void setPersonName(String personName) {
		this.personName = personName;
	}
	public Date getDob() {
		return dob;
	}
	
	
}
