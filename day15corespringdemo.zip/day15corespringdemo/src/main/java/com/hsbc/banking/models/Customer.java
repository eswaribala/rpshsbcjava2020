package com.hsbc.banking.models;

import java.util.Date;

public abstract class Customer extends Person  {

	public Customer(Date dob) {
		super(dob);
		// TODO Auto-generated constructor stub
	}

	public abstract float offer(String season);
}
