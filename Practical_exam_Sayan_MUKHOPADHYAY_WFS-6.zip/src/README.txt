Layer		File								Description
							
model		Category.java,FoodItems.java,Apparel.java,Electronics.java	defines model classes
views		cateegoryApp.java						for end user purpose
bl		CategoryBL,.javaCategoryBLImpl.java				define business logic,processing and validation
dao		CategoryDao,CategoryImpl.java					data storage and retrieval
