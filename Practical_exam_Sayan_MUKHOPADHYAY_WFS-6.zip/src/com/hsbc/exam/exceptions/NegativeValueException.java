package com.hsbc.exam.exceptions;
/**
 * 
 * @author Sayan
 * @version 1.0
 * 
 *
 */
public class NegativeValueException extends Exception{
	
	public NegativeValueException(String message)
	{
		super(message);
	}

}
