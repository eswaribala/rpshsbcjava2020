package com.hsbc.exam.exceptions;
/**
 * 
 * @author Sayan
 * @version 1.0
 * 
 *
 */
public class InvalidSubCategoryException extends Exception{
	
	public InvalidSubCategoryException(String message)
	{
		super(message);
	}

}
