package com.hsbc.exam.exceptions;
/**
 * 
 * @author Sayan
 * @version 1.0
 * 
 *
 */
public class FileCreationException extends Exception{
	
	public FileCreationException(String message)
	{
		super(message);
	}

}
