package com.hsbc.exam.dao;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.hsbc.exam.models.Apparel;
import com.hsbc.exam.models.Electronics;
import com.hsbc.exam.models.FoodItems;
import com.hsbc.exam.dao.FileHelper;
import com.hsbc.exam.exceptions.InvalidSubCategoryException;

/**
 * 
 * @author Sayan
 * @version 1.0
 * 
 *
 */

public class CategoryImpl implements CategoryDao{
	
	private File file;
	private FileOutputStream fileOutputStream;
	private FileInputStream fileInputStream;
	private ObjectOutputStream objectOutputStream;
	private ObjectInputStream objectInputStream;
	
	public CategoryImpl(int subIndex) throws IOException, InvalidSubCategoryException
	{
		file=FileHelper.createFile(subIndex);
	}

	@Override
	public boolean addFoodItems(List<FoodItems> foodList) throws IOException {
		// TODO Auto-generated method stub
		fileOutputStream=new FileOutputStream(file,true);
		objectOutputStream=new ObjectOutputStream(fileOutputStream);
		for(FoodItems food : foodList)
		{
			objectOutputStream.writeObject(food);
		}
		objectOutputStream.close();
		fileOutputStream.close();
		
		
		return true;
	}

	@Override
	public List<FoodItems> getTopFoodItemsSold() throws ClassNotFoundException, IOException {
		// TODO Auto-generated method stub
		fileInputStream=new FileInputStream(file);
		objectInputStream=new ObjectInputStream(fileInputStream);
		List<FoodItems> foodList=new ArrayList<FoodItems>();
		List<FoodItems> topFoodList=new ArrayList<FoodItems>();
		FoodItems food=null;		
		try
		{
			
			while((food=(FoodItems) objectInputStream.readObject())!=null)
			 	foodList.add(food);			
					
		}
		catch(EOFException exception)
		{
			
		}
		finally
		{
		objectInputStream.close();
		fileInputStream.close();
		}
		
		Collections.sort(foodList,Collections.reverseOrder());
		int counter=0;
		for(FoodItems topFood:foodList)
		{
			topFoodList.add(topFood);
			if(counter==3)
				break;
		}
		return topFoodList;
	}

	@Override
	public List<Apparel> getTopApparelsSold() throws IOException, ClassNotFoundException {
		// TODO Auto-generated method stub
		fileInputStream=new FileInputStream(file);
		objectInputStream=new ObjectInputStream(fileInputStream);
		List<Apparel> apparelList=new ArrayList<Apparel>();
		List<Apparel> topApparelList=new ArrayList<Apparel>();
		Apparel apparel=null;		
		try
		{
			
			while((apparel=(Apparel) objectInputStream.readObject())!=null)
			 	apparelList.add(apparel);			
					
		}
		catch(EOFException exception)
		{
			
		}
		finally
		{
		objectInputStream.close();
		fileInputStream.close();
		}
		
		Collections.sort(apparelList,Collections.reverseOrder());
		int counter=0;
		for(Apparel topApparel:apparelList)
		{
			topApparelList.add(topApparel);
			if(counter==3)
				break;
		}
		return topApparelList;
	}

	@Override
	public List<Electronics> getTopElectronicsSold() throws IOException, ClassNotFoundException {
		// TODO Auto-generated method stub
		fileInputStream=new FileInputStream(file);
		objectInputStream=new ObjectInputStream(fileInputStream);
		List<Electronics> electronicsList=new ArrayList<Electronics>();
		List<Electronics> topElectronicsList=new ArrayList<Electronics>();
		Electronics electronic=null;		
		try
		{
			
			while((electronic=(Electronics) objectInputStream.readObject())!=null)
			 	electronicsList.add(electronic);			
					
		}
		catch(EOFException exception)
		{
			
		}
		finally
		{
		objectInputStream.close();
		fileInputStream.close();
		}
		
		Collections.sort(electronicsList,Collections.reverseOrder());
		int counter=0;
		for(Electronics topElectronic:electronicsList)
		{
			topElectronicsList.add(topElectronic);
			if(counter==3)
				break;
		}
		return topElectronicsList;
	}

	@Override
	public boolean addApparel(List<Apparel> apparelList) throws IOException {
		// TODO Auto-generated method stub
		fileOutputStream=new FileOutputStream(file,true);
		objectOutputStream=new ObjectOutputStream(fileOutputStream);
		for(Apparel apparel : apparelList)
		{
			objectOutputStream.writeObject(apparel);
		}
		objectOutputStream.close();
		fileOutputStream.close();
		
		
		return true;
	}

	@Override
	public boolean addElectronics(List<Electronics> electronicsList) throws IOException {
		// TODO Auto-generated method stub
		fileOutputStream=new FileOutputStream(file,true);
		objectOutputStream=new ObjectOutputStream(fileOutputStream);
		for(Electronics electronic : electronicsList)
		{
			objectOutputStream.writeObject(electronic);
		}
		objectOutputStream.close();
		fileOutputStream.close();
		
		
		return true;
	}

}
