package com.hsbc.exam.dao;

import java.util.Comparator;

import com.hsbc.exam.models.Electronics;
/**
 * 
 * @author Sayan
 * @version 1.0
 * 
 *
 */
public class SortElectronicsByQuantity implements Comparator<Electronics>{

	@Override
	public int compare(Electronics o1, Electronics o2) {
		// TODO Auto-generated method stub
		return Integer.valueOf(o1.getQuantity()).compareTo(Integer.valueOf(o2.getQuantity()));
	}
}
