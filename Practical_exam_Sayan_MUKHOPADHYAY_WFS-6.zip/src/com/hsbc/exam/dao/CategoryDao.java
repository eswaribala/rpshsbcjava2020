package com.hsbc.exam.dao;

import java.io.IOException;
import java.util.List;

import com.hsbc.exam.models.Apparel;
import com.hsbc.exam.models.Electronics;
import com.hsbc.exam.models.FoodItems;

/**
 * 
 * @author Sayan
 * @version 1.0
 * 
 *
 */

public interface CategoryDao {
	
	boolean addFoodItems(List<FoodItems> foodList) throws IOException;
	boolean addApparel(List<Apparel> apparelList) throws IOException;
	boolean addElectronics(List<Electronics> electronicsList) throws IOException;
	List<FoodItems> getTopFoodItemsSold() throws ClassNotFoundException, IOException;
	List<Apparel> getTopApparelsSold() throws ClassNotFoundException, IOException;
	List<Electronics> getTopElectronicsSold() throws ClassNotFoundException, IOException;

}
