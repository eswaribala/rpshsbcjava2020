package com.hsbc.exam.dao;

import java.io.File;
import java.io.IOException;
import java.util.ResourceBundle;

import com.hsbc.exam.exceptions.InvalidSubCategoryException;


/**
 * 
 * @author Sayan
 * @version 1.0
 * 
 *
 */
public class FileHelper {
	
	private static File file;
	private static ResourceBundle resourceBundle;
	
	//subIndex to create seperate files based on subcategory object
	public static File createFile(int subIndex) throws IOException, InvalidSubCategoryException
	{
		resourceBundle=ResourceBundle.getBundle("com/hsbc/exam/"
				+ "resources/exam");	
		
		if(subIndex==1)
		{
		file=new File(resourceBundle.getString("fileFood"));
		if(!file.exists())
			file.createNewFile();
		}
		else if(subIndex==2)
		{
			file=new File(resourceBundle.getString("fileApparel"));
			if(!file.exists())
				file.createNewFile();
		}
		else if(subIndex==3)
		{
			file=new File(resourceBundle.getString("fileElectronics"));
			if(!file.exists())
				file.createNewFile();
		}
		else throw new InvalidSubCategoryException("Check Sub Category Index.......");
		
		
        return file; 	
		
		
	}

}
