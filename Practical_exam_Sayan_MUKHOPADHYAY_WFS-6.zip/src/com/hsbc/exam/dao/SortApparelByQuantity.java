package com.hsbc.exam.dao;

import java.util.Comparator;

import com.hsbc.exam.models.Apparel;
/**
 * 
 * @author Sayan
 * @version 1.0
 * 
 *
 */
public class SortApparelByQuantity implements Comparator<Apparel>{

	@Override
	public int compare(Apparel o1, Apparel o2) {
		// TODO Auto-generated method stub
		return Integer.valueOf(o1.getQuantity()).compareTo(Integer.valueOf(o2.getQuantity()));
	}
}
