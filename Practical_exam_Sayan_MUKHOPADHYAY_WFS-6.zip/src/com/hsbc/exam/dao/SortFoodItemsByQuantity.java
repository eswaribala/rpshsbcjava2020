package com.hsbc.exam.dao;

import java.util.Comparator;

import com.hsbc.exam.models.FoodItems;
/**
 * 
 * @author Sayan
 * @version 1.0
 * 
 *
 */
public class SortFoodItemsByQuantity implements Comparator<FoodItems>{

	@Override
	public int compare(FoodItems o1, FoodItems o2) {
		// TODO Auto-generated method stub
		return Integer.valueOf(o1.getQuantity()).compareTo(Integer.valueOf(o2.getQuantity()));
	}

}
