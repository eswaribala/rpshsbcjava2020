package com.hsbc.exam.bl;

import java.io.IOException;

/**
 * 
 * @author Sayan
 * @version 1.0
 * 
 *
 */
import java.util.List;

import com.hsbc.exam.exceptions.NegativeValueException;
import com.hsbc.exam.models.Apparel;
import com.hsbc.exam.models.Electronics;
import com.hsbc.exam.models.FoodItems;

public interface CategoryBL {
	
	boolean addFoodItems(List<FoodItems> foodList) throws IOException, NegativeValueException;
	boolean addApparel(List<Apparel> apparelList) throws IOException,NegativeValueException;
	boolean addElectronics(List<Electronics> electronicsList) throws IOException,NegativeValueException;
	List<FoodItems> getTopFoodItemsSold() throws ClassNotFoundException, IOException;
	List<Apparel> getTopApparelsSold() throws ClassNotFoundException, IOException;
	List<Electronics> getTopElectronicsSold() throws ClassNotFoundException, IOException;

}
