package com.hsbc.exam.bl;

import java.io.IOException;
import java.util.List;
import java.util.regex.Pattern;

import com.hsbc.exam.models.Apparel;
import com.hsbc.exam.models.Electronics;
import com.hsbc.exam.models.FoodItems;
import com.hsbc.exam.dao.CategoryDao;
import com.hsbc.exam.dao.CategoryImpl;
import com.hsbc.exam.exceptions.FileCreationException;
import com.hsbc.exam.exceptions.InvalidSubCategoryException;
import com.hsbc.exam.exceptions.NegativeValueException;

/**
 * 
 * @author Sayan
 * @version 1.0
 * 
 *
 */

public class CategoryBLImpl implements CategoryBL{
	
private CategoryDao categoryDao;
	
	public  CategoryBLImpl(int subIndex) throws FileCreationException
	{
				try {
					categoryDao=new CategoryImpl(subIndex);
			} catch (IOException|InvalidSubCategoryException e) {
				// TODO Auto-generated catch block
				//rethrow
				throw new FileCreationException("Not able to create the file, change the location, Check Permission");				
			}		
	}
//validations	
	private boolean validatePriceAndQuantity(int value)
	{
		return (value>0);
	}

	@Override
	public boolean addFoodItems(List<FoodItems> foodList) throws IOException, NegativeValueException {
		// TODO Auto-generated method stub
		FoodItems foodObj=new FoodItems();
		for(FoodItems food:foodList)
		{
			if(!validatePriceAndQuantity(food.getQuantity())&&validatePriceAndQuantity(food.getUnitPrice()))
				throw new NegativeValueException("Price and Quantity cannot be Negative.......");
		}
				return categoryDao.addFoodItems(foodList); 
	}

	@Override
	public boolean addApparel(List<Apparel> apparelList) throws IOException, NegativeValueException {
		// TODO Auto-generated method stub
		Apparel apparelObj=new Apparel();
		for(Apparel apparel:apparelList)
		{
			if(!validatePriceAndQuantity(apparel.getQuantity())&&validatePriceAndQuantity(apparel.getUnitPrice()))
				throw new NegativeValueException("Price and Quantity cannot be Negative.......");
		}
		return categoryDao.addApparel(apparelList);
	}

	@Override
	public boolean addElectronics(List<Electronics> electronicsList) throws IOException, NegativeValueException {
		// TODO Auto-generated method stub
		Electronics electronicObj=new Electronics();
		for(Electronics electronic:electronicsList)
		{
			if(!validatePriceAndQuantity(electronic.getQuantity())&&validatePriceAndQuantity(electronic.getUnitPrice()))
				throw new NegativeValueException("Price and Quantity cannot be Negative.......");
		}
		return categoryDao.addElectronics(electronicsList);
	}

	@Override
	public List<FoodItems> getTopFoodItemsSold() throws ClassNotFoundException, IOException {
		// TODO Auto-generated method stub
		return categoryDao.getTopFoodItemsSold();
	}

	@Override
	public List<Apparel> getTopApparelsSold() throws ClassNotFoundException, IOException {
		// TODO Auto-generated method stub
		return categoryDao.getTopApparelsSold();
	}

	@Override
	public List<Electronics> getTopElectronicsSold() throws ClassNotFoundException, IOException {
		// TODO Auto-generated method stub
		return categoryDao.getTopElectronicsSold();
	}

}
