package com.hsbc.exam.models;

import java.io.Serializable;
/**
 * 
 * @author Sayan
 * @version 1.0
 * 
 *
 */
public final class Apparel extends Category implements Serializable{
	
	private byte size;
	Material material;
	public byte getSize() {
		return size;
	}
	public void setSize(byte size) {
		this.size = size;
	}
	public Material getMaterial() {
		return material;
	}
	public void setMaterial(Material material) {
		this.material = material;
	}
	@Override
	public String toString() {
		return super.toString()+"Apparel [size=" + size + ", material=" + material + "]";
	}

}
