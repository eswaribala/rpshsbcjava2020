package com.hsbc.exam.models;

import java.io.Serializable;
/**
 * 
 * @author Sayan
 * @version 1.0
 * 
 *
 */
public enum Vegetarian implements Serializable{
	
	YES,NO

}
