package com.hsbc.exam.models;

import java.io.Serializable;
/**
 * 
 * @author Sayan
 * @version 1.0
 * 
 *
 */
public final class Electronics extends Category implements Serializable{
	
	private byte months;

	@Override
	public String toString() {
		return super.toString()+"Electronics [months=" + months + "]";
	}

	public byte getMonths() {
		return months;
	}

	public void setMonths(byte months) {
		this.months = months;
	}

}
