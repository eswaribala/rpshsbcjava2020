package com.hsbc.exam.models;

import java.io.Serializable;
import java.time.LocalDate;
/**
 * 
 * @author Sayan
 * @version 1.0
 * 
 *
 */
public final class FoodItems extends Category implements Serializable{
	
	private LocalDate dom;
	private LocalDate doe;
	private Vegetarian veg;
	public LocalDate getDom() {
		return dom;
	}
	public void setDom(LocalDate dom) {
		this.dom = dom;
	}
	public LocalDate getDoe() {
		return doe;
	}
	public void setDoe(LocalDate doe) {
		this.doe = doe;
	}
	public Vegetarian getVeg() {
		return veg;
	}
	public void setVeg(Vegetarian veg) {
		this.veg = veg;
	}
	@Override
	public String toString() {
		return super.toString()+"FoodItems [dom=" + dom + ", doe=" + doe + ", veg=" + veg + "]";
	}
	

}
