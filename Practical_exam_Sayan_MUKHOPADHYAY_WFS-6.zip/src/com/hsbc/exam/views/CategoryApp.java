package com.hsbc.exam.views;
/**
 * 
 * @author Sayan
 * @version 1.0
 * 
 *
 */
public class CategoryApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
