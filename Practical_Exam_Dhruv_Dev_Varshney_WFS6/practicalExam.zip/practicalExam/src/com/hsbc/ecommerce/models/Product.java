package com.hsbc.ecommerce.models;

import java.io.Serializable;

//Creating a Product class 
public class Product implements Serializable{
	//create variable for product code and product name
	private int itemCode;
	private String itemName;
	private Category category;
	//generate getters and setters for above two variable
	public int getItemCode() {
		return itemCode;
	}
	public void setItemCode(int itemCode) {
		this.itemCode = itemCode;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	
	
	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}
	//generate toString method for displaying the output
	@Override
	public String toString() {
		return "Product [itemCode=" + itemCode + ", itemName=" + itemName + ", category=" + category + "]";
	}
		
	

}
