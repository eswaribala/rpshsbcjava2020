package com.hsbc.ecommerce.models;
//created a enum for user to select category of product
public enum Category {
	FoodItems, Apparel, Electronics

}
