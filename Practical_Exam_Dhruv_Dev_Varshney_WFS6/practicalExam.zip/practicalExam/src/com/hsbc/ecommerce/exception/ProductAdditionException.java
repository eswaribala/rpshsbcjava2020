package com.hsbc.ecommerce.exception;

public class ProductAdditionException extends Exception{
	
	public ProductAdditionException (String message)
	{
		super(message);
	}

}
