package com.hsbc.ecommerce.exception;

public class ProductRetrievalException {
	public  ProductRetrievalException (String message)
	{
		super();
	}

	public void printStackTrace() {
		// TODO Auto-generated method stub
		
	}

}
