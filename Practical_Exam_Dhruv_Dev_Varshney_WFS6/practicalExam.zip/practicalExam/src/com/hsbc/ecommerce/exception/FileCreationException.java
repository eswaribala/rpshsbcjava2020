package com.hsbc.ecommerce.exception;

//create a custom exception it will be thrown when file creation error.

public class FileCreationException extends Exception{
	public FileCreationException(String Message) {
	super(Message);
	}
}
