package com.hsbc.ecommerce.dao;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import com.hsbc.ecommerce.models.Product;
//created a data axis layer for adding and retrieving products
public interface ProductDao {
	boolean addProduct(List<Product> productList) throws FileNotFoundException, IOException;
	List<Product> getAllProducts() throws IOException, ClassNotFoundException;
	}
