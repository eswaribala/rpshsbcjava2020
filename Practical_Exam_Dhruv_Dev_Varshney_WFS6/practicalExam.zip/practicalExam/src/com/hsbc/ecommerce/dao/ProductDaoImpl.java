package com.hsbc.ecommerce.dao;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

import com.hsbc.ecommerce.models.Product;

public class ProductDaoImpl implements ProductDao{
	
	//create a file
	private File file;
	private FileOutputStream fileOutputStream;
	private FileInputStream fileInputStream;
	private ObjectOutputStream objectOutputStream;
	private ObjectInputStream objectInputStream;
	
	//method that creates a file if no file exist
	public ProductDaoImpl() throws IOException
	{
		file=FileHelper.createFile();
	}

	//Method to add product
	@Override
	public boolean addProduct(List<Product> productList) throws IOException {
		// TODO Auto-generated method stub
		fileOutputStream=new FileOutputStream(file,true);
		objectOutputStream=new ObjectOutputStream(fileOutputStream);
		for(Product product: productList)
		{
			objectOutputStream.writeObject(product);
		}
		objectOutputStream.close();
		fileOutputStream.close();
		return true;
	}

	//Method to get list of all products
	@Override
	public List<Product> getAllProducts() throws IOException, ClassNotFoundException {
		// TODO Auto-generated method stub
		fileInputStream=new FileInputStream(file);
		objectInputStream=new ObjectInputStream(fileInputStream);
		List<Product> productList = new ArrayList<Product>();
		Product product=null;
		try
		{
			
			while((product=(Product) objectInputStream.readObject())!=null)
			 	productList.add(product);			
					
		}
		catch(EOFException exception)
		{
			
		}
		finally
		{
		objectInputStream.close();
		fileInputStream.close();
		}
		
		return productList;
	}
	}
	
