package com.hsbc.ecommerce.bl;

import java.util.List;

import com.hsbc.ecommerce.exception.ProductAdditionException;
import com.hsbc.ecommerce.models.Product;
//create a business layer for adding product and get all products
public interface ProductBL{
	boolean addProduct(List<Product> productList) throws ProductAdditionException;
	List<Product> getAllProducts();

}
