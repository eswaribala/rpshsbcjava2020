package com.hsbc.ecommerce.bl;

import java.io.IOException;
import java.util.List;

import com.hsbc.ecommerce.dao.ProductDaoImpl;
import com.hsbc.ecommerce.exception.FileCreationException;
import com.hsbc.ecommerce.exception.ProductAdditionException;
import com.hsbc.ecommerce.exception.ProductRetrievalException;
import com.hsbc.ecommerce.models.Product;

public class ProductBLImpl implements ProductBL {
	private ProductBL productDao;
	//
	
	public  ProductBLImpl() throws FileCreationException
	{
		try {
				productDao=(ProductBL) new ProductDaoImpl();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				//rethrow an exception
				throw new FileCreationException("Not able to create the "
						+ "file, change the location, Check Permission");				
			}		
	}

	@Override
	public boolean addProduct(List<Product> productList) throws ProductAdditionException {
		// TODO Auto-generated method stub
		boolean status=false;
		status=productDao.addProduct(productList); 
		return status;
	}

	@Override
	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
		List<Product> vehicleList=null;
		try {
			List<Product> productList = productDao.getAllProducts();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			throw new ProductRetrievalException("Product Object "
					+ "Not found in the file or file Corrupted");
		} 
		
		return vehicleList;
	}

}
