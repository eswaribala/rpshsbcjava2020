package com.hsbc.ecommerce.views;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.hsbc.ecommerce.bl.ProductBL;
import com.hsbc.ecommerce.bl.ProductBLImpl;
import com.hsbc.ecommerce.exception.FileCreationException;
import com.hsbc.ecommerce.exception.ProductRetrievalException;
import com.hsbc.ecommerce.models.Category;
import com.hsbc.ecommerce.models.Product;
//productAPP class
public class ProductApp {
	private static ProductBL productBL;
	//static block for product
	static
	{
		try {
			productBL=new ProductBLImpl();
		} catch (FileCreationException e) {
			//Business specific Exception
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
	}
	//Method for adding product into the cart
	private static void addProduct()
	{
		//Using list to take input from user
		ArrayList<Product> vehicleList=new ArrayList<Product>();
		Scanner sc = new Scanner(System.in);
		Product product = new Product();
		System.out.println("Welcome to EveryDay GoodProducts Pvt. Ltd.");
		System.out.println("Enter Category(Food Itmes,Apparel,Electronics)");
		String category=sc.nextLine();	
		product.setCategory(Category.valueOf(category));
		if(product.getCategory()==FoodItems)
		{
			System.out.println("Enter ItemCode:");
			int itemCode=sc.nextInt();
			product.setItemCode(itemCode);
			System.out.println("Enter ItemName:");
			String ItemName=sc.nextLine();
			product.setItemName(ItemName);
		}
		
		//method for asking all products after adding all products
		private static void getAllProducts()
		{
			List<Product> productList=null;
			try {
				
				productList=productBL.getAllProducts();
				for(Product product: productList)
				{
					System.out.println(product);
				}
				
			} catch (ProductRetrievalException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		//Main method
		public static void main(String[] args) {
			// TODO Auto-generated method stub
	        addProduct();   
			getAllProducts();
	}
		
	}

}
