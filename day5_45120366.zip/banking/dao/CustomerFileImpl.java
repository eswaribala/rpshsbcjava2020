package com.hsbc.banking.dao;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.LineNumberReader;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import com.hsbc.banking.exceptions.DOBException;
import com.hsbc.banking.models.Customer;

public class CustomerFileImpl implements CustomerDao{
	
	private File file;
	private FileWriter fileWriter;
	private BufferedWriter bufferedWriter;
	private FileReader fileReader;
	private LineNumberReader lineNumberReader;
	public CustomerFileImpl(String dirPath,String fileName) throws IOException
	{
		file=FileHelper.createFile(dirPath, fileName);
		fileWriter=new FileWriter(file,true);
		bufferedWriter=new BufferedWriter(fileWriter);
		fileReader=new FileReader(file);
	}

	@Override
	public boolean addCustomer(Customer customer) throws DOBException,IOException{
		// TODO Auto-generated method stub
		boolean status=true;
		
		if(customer.getDob().isAfter(LocalDate.now()))
		{
			status=false;
			throw new DOBException("DOB cannot be greater than today...");
		}
		else
		{
			bufferedWriter.append(String.valueOf(customer.getCustomerId()));
			bufferedWriter.append(",");
			bufferedWriter.append(customer.getName());
			bufferedWriter.append(",");
			bufferedWriter.append(String.valueOf(customer.getDob()));
			bufferedWriter.append(",");
			bufferedWriter.newLine();
			bufferedWriter.close();
			
		}
		return status;
	}

	@Override
	public int getNoOFRows() throws IOException {
		// TODO Auto-generated method stub
		int count=0;
		String line=null;
		lineNumberReader=new LineNumberReader(fileReader);
		while((line=lineNumberReader.readLine())!=null)
			count++;
		//lineNumberReader.close();
		return count;
	}

	@Override
	public Customer[] getAllCustomers() throws IOException{
		// TODO Auto-generated method stub
		Customer[] customerList=new Customer[getNoOFRows()];
		int pos=0;
		Customer customer=new Customer();
		String line=null;
		String[] customerData;
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		lineNumberReader=new LineNumberReader(fileReader);
		while((line=lineNumberReader.readLine())!=null)
		{
			customerData=line.split(",");
			customer.setCustomerId(Long.parseLong(customerData[0]));
			customer.setName(customerData[1]);
			customer.setDob(LocalDate.parse(customerData[2],formatter));
			customerList[pos]=customer;
			pos++;
			
		}
		lineNumberReader.close();
		return customerList;
	}

}
