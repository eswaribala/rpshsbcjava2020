package com.hsbc.banking.models;

import org.springframework.stereotype.Component;

@Component
public class FileReport implements Report {

	@Override
	public void writeMessage(String message) {
		// TODO Auto-generated method stub
		System.out.println(message+"Written to File");
	}

}
