package com.hsbc.banking.models;

import org.springframework.stereotype.Component;

@Component
public interface Report {
	
	void writeMessage(String message);

}
