package com.hsbc.banking.models;

import java.time.LocalDate;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanClassLoaderAware;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.ResourceLoaderAware;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Component;
@Component //creates the bean
public class Transaction  implements BeanNameAware,BeanClassLoaderAware,
BeanFactoryAware,ResourceLoaderAware,ApplicationContextAware{

	private long transactionId;
	private long amount;
	private LocalDate dot;
	private boolean status;
	@Autowired
	private Account account;
	@Autowired
	private Report report;	
	
	public long getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(long transactionId) {
		this.transactionId = transactionId;
	}
	public long getAmount() {
		return amount;
	}
	public void setAmount(long amount) {
		this.amount = amount;
	}
	public LocalDate getDot() {
		return dot;
	}
	public void setDot(LocalDate dot) {
		this.dot = dot;
	}
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	public Account getAccount() {
		return account;
	}
	public void setAccount(Account account) {
		this.account = account;
	}
	public Report getReport() {
		return report;
	}
	public void setReport(Report report) {
		this.report = report;
	}
	@Override
	public void setBeanName(String name) {
		System.out.println("Identified Bean Name="+name);
		
	}
	@Override
	public void setBeanClassLoader(ClassLoader classLoader) {
		// TODO Auto-generated method stub
		System.out.println(classLoader.getClass().getName());
	}
	@Override
	public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
		// TODO Auto-generated method stub
		System.out.println("Check?="+beanFactory.containsBean("transaction"));
	}
	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		// TODO Auto-generated method stub
		System.out.println(applicationContext.getApplicationName());
	}
	@Override
	public void setResourceLoader(ResourceLoader resourceLoader) {
		// TODO Auto-generated method stub
		System.out.println(resourceLoader.getClass().getSimpleName());
	}
	
	@PostConstruct
	public void afterBeanCreation()
	{
		System.out.println("Invoked after bean construction");
	}
	
	@PreDestroy
	public void beforeDestoryBean()
	{
		System.out.println("Invoked before bean destroyed");
	}
	
	
}
