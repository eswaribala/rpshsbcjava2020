package com.hsbc.banking.models;

public class Customer {
	private long customerId;
	private String name;
	private String address;
	public Customer(long customerId, String name, String address) {
		super();
		this.customerId = customerId;
		this.name = name;
		this.address = address;
	}
	public long getCustomerId() {
		return customerId;
	}
	public String getName() {
		return name;
	}
	public String getAddress() {
		return address;
	}
	

}
