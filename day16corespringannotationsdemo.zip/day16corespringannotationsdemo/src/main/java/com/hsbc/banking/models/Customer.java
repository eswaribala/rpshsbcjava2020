package com.hsbc.banking.models;

import org.springframework.stereotype.Component;

@Component("customer1")
public class Customer {
	private long customerId;
	private String name;
	private String address;
	
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Customer(long customerId, String name, String address) {
		super();
		this.customerId = customerId;
		this.name = name;
		this.address = address;
	}
	public long getCustomerId() {
		return customerId;
	}
	public String getName() {
		return name;
	}
	public String getAddress() {
		return address;
	}
	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	

}
