package com.hsbc.banking.models;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component
@Primary
public class AttachmentReport implements Report{

	@Override
	public void writeMessage(String message) {
		// TODO Auto-generated method stub
		System.out.println(message+"Attached to mail");
	}

}
