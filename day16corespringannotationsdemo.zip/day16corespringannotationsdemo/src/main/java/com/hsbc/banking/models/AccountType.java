package com.hsbc.banking.models;

public enum AccountType {
SAVINGS,LOAN,DEMAT,RECURRING
}
