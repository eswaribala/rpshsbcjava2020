package com.hsbc.banking.models;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;

@Configuration
public class DbConfiguration {
	
	
   @Bean(name="ds")
   @Lazy
	public DataSource getDataSource()
	{
	
		return new DataSource();
	}
	
	
	
}
