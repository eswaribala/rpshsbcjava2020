package com.hsbc.banking.utility;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import com.hsbc.banking.models.Account;
import com.hsbc.banking.models.AccountType;
import com.hsbc.banking.models.Customer;
import com.hsbc.banking.models.DataSource;
import com.hsbc.banking.models.DbConfiguration;
import com.hsbc.banking.models.OracleDbConfiguration;
import com.hsbc.banking.models.Transaction;
//@Component
public class TransactionApp {
    //@Autowired
    //@Qualifier(value="ds")
	//private DataSource dataSource;
	 public static void main(String[] args)
	 {		 
		 AbstractApplicationContext ctx=new ClassPathXmlApplicationContext("com/hsbc/banking"
		 		+ "/resources/transaction-bean.xml");
		 
		 Customer customer=(Customer) ctx.getBean("customer1");
		 customer.setCustomerId(24584788);
		 Account account=(Account) ctx.getBean("account");
		 account.setAccountNo(23887);
		 account.setAccountType(AccountType.SAVINGS);
		 System.out.println("Customer Id="+account.getCustomer1().getCustomerId());
		 //System.out.println("Customer Id="+account.getCustomer2().getCustomerId());
		 Transaction transaction=(Transaction) ctx.getBean("transaction");
		 System.out.println("Account No"+transaction.getAccount().getAccountNo()
				 +","+transaction.getAccount().getAccountType());	
		transaction.getReport().writeMessage("Log");		
		
		ctx.registerShutdownHook();
		
		
		 //method1
		//DataSource dataSource=(DataSource) ctx.getBean("ds");
		//method2
		 //TransactionApp transactionApp=(TransactionApp) ctx.getBean("transactionApp");
		//System.out.println(transactionApp.dataSource.getDriver());
		//method3		 
		 //DbConfiguration dbConfiguration=(DbConfiguration) ctx.getBean("dbConfiguration");
		// DataSource dataSource=dbConfiguration.getDataSource();
		// System.out.println(dataSource.getDriver());
		 //method4		 
		 ApplicationContext applicationContext=new 
				 AnnotationConfigApplicationContext(OracleDbConfiguration.class);		 
		 DataSource dataSource=(DataSource) applicationContext.getBean("ds");
		 System.out.println(dataSource.getDriver());
		 
		 
		 
		 
	 }
}
