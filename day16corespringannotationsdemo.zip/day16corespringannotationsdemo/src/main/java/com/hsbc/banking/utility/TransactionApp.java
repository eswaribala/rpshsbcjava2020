package com.hsbc.banking.utility;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.hsbc.banking.models.Account;
import com.hsbc.banking.models.Customer;
import com.hsbc.banking.models.Transaction;

public class TransactionApp {

	 public static void main(String[] args)
	 {
		 
		 ApplicationContext ctx=new ClassPathXmlApplicationContext("com/hsbc/banking"
		 		+ "/resources/transaction-bean.xml");
		 
		 //Customer customer=(Customer) ctx.getBean("customer1");
		 Account account=(Account) ctx.getBean("account");
		 System.out.println("Customer Id="+account.getCustomer1().getCustomerId());
		 System.out.println("Customer Id="+account.getCustomer2().getCustomerId());
		 Transaction transaction=(Transaction) ctx.getBean("transaction");
		 System.out.println("Account No"+transaction.getAccount().getAccountNo()
				 +","+transaction.getAccount().getAccountType());
		 
	 }
}
