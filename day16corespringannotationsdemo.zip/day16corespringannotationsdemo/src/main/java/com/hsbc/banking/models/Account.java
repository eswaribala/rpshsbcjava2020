package com.hsbc.banking.models;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class Account {

	private long accountNo;
	private AccountType accountType;
	private long balance;
	@Autowired(required=false) //not mandatory
	@Qualifier(value = "customer1")
	private Customer customer1;
	@Autowired(required=false)
	@Qualifier(value = "customer2")
	private Customer customer2;
	public long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}
	public AccountType getAccountType() {
		return accountType;
	}
	public void setAccountType(AccountType accountType) {
		this.accountType = accountType;
	}
	public long getBalance() {
		return balance;
	}
	public void setBalance(long balance) {
		this.balance = balance;
	}
	public Customer getCustomer1() {
		return customer1;
	}
	public void setCustomer1(Customer customer1) {
		this.customer1 = customer1;
	}
	public Customer getCustomer2() {
		return customer2;
	}
	public void setCustomer2(Customer customer2) {
		this.customer2 = customer2;
	}
	
	
}
