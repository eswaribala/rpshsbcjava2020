package com.hsbc.banking.models;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@Import(DbConfiguration.class)
public class OracleDbConfiguration {

}
