package com.hsbc.retail.models;

import java.time.LocalDate;

public class FoodItem {
	private int itemcode;
	private String itemName;
	private int price;
	private LocalDate dom;
	private LocalDate doexpiry;
	
	
	
	@Override
	public String toString() {
		return "FoodItem [itemcode=" + itemcode + ", itemName=" + itemName + ", price=" + price + ", dom=" + dom
				+ ", doexpiry=" + doexpiry + ", Vegetarian=" + Vegetarian + ", quantity=" + quantity + "]";
	}
	public int getItemcode() {
		return itemcode;
	}
	public void setItemcode(int itemcode) {
		this.itemcode = itemcode;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public LocalDate getDom() {
		return dom;
	}
	public void setDom(LocalDate dom) {
		this.dom = dom;
	}
	public LocalDate getDoexpiry() {
		return doexpiry;
	}
	public void setDoexpiry(LocalDate doexpiry) {
		this.doexpiry = doexpiry;
	}
	public boolean isVegetarian() {
		return Vegetarian;
	}
	public void setVegetarian(boolean vegetarian) {
		Vegetarian = vegetarian;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	private boolean Vegetarian ;
	private int quantity;
	
	

}
