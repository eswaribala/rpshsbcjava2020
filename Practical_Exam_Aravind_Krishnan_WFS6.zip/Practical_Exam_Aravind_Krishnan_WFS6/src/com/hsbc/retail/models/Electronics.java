package com.hsbc.retail.models;

public class Electronics {
	private int itemcode;
	private String itemName;
	private int price;
	private int warrantyInMonths;
	private int quantity;
	public int getItemcode() {
		return itemcode;
	}
	public void setItemcode(int itemcode) {
		this.itemcode = itemcode;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	@Override
	public String toString() {
		return "Electronics [itemcode=" + itemcode + ", itemName=" + itemName + ", price=" + price
				+ ", warrantyInMonths=" + warrantyInMonths + ", quantity=" + quantity + "]";
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getWarrantyInMonths() {
		return warrantyInMonths;
	}
	public void setWarrantyInMonths(int warrantyInMonths) {
		this.warrantyInMonths = warrantyInMonths;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
}
