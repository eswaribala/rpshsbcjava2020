package com.hsbc.retail.models;

public class Apparel {
	private int itemcode;
	private String itemName;
	private int price;
	private int size;
	private Material material;
	private int quantity;
	@Override
	public String toString() {
		return "Apparel [itemcode=" + itemcode + ", itemName=" + itemName + ", price=" + price + ", size=" + size
				+ ", material=" + material + ", quantity=" + quantity + "]";
	}
	public int getItemcode() {
		return itemcode;
	}
	public void setItemcode(int itemcode) {
		this.itemcode = itemcode;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
	public Material getMaterial() {
		return material;
	}
	public void setMaterial(Material material) {
		this.material = material;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	

}
