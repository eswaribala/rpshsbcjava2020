package com.hsbc.retail.models;

public enum Material {
COTTON,WOOLEN
}
