package com.hsbc.retail.models;

import java.util.Comparator;

public class SortTopSold implements Comparator<FoodItem> {

	@Override
	public int compare(FoodItem o1, FoodItem o2) {
		// TODO Auto-generated method stub
		return o1.getQuantity()-o2.getQuantity();
	}

}
