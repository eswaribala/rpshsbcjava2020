package com.hsbc.retail.views;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import com.hsbc.retail.bl.FoodItemBl;
import com.hsbc.retail.bl.FoodItemBlImpl;
import com.hsbc.retail.exception.CategroryException;
import com.hsbc.retail.exception.FileCreationException;
import com.hsbc.retail.models.FoodItem;
import com.hsbc.retail.models.SortTopSold;



public class RetailApp {
	
	static FoodItemBl foodItembl;
	
	static Scanner scanner = new Scanner(System.in);
	
	
	static {
		try {
			foodItembl = new FoodItemBlImpl();
		} catch (FileCreationException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
	}
	
	
	public static void addFoodItem() {
		ArrayList<FoodItem> foodItemList = new ArrayList<FoodItem>();
		foodItemList.ensureCapacity(10);
		FoodItem foodItem = null;
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		//getting input values from the user
		for(int i=0;i<5;i++) {
			foodItem= new FoodItem();
			System.out.println("Enter item code");
			int itemcode = scanner.nextInt();
			foodItem.setItemcode(itemcode);
			System.out.println("Enter item name");
			String itemName = scanner.nextLine();
			foodItem.setItemName(itemName);
			scanner.nextLine();
			
			System.out.println("Enter price per unit");
			int price = scanner.nextInt();
			foodItem.setPrice(price);
			System.out.println("Enter dateof manufacture");
			String dom = scanner.next();
			foodItem.setDom(LocalDate.parse(dom, formatter));
			scanner.nextLine();
			System.out.println("Enter date of expiry");
			String doexpiry = scanner.next();
			foodItem.setDoexpiry(LocalDate.parse(doexpiry, formatter));
			scanner.nextLine();
			System.out.println("Enter vegetarian");
			boolean vegetarian = scanner.nextBoolean();
			foodItem.setVegetarian(vegetarian);
			System.out.println("Enter quantity");
			int quantity = scanner.nextInt();
			foodItem.setQuantity(quantity);
			foodItemList.add(foodItem);
				
		}
		
		
			try {
				foodItembl.addfoodItems(foodItemList);
			} catch (CategroryException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			} catch (FileCreationException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}
		
		
		
	}    
	
	
	public static void retrieveFoodItem() throws ClassNotFoundException, IOException, CategroryException, FileCreationException {
		List<FoodItem> foodItemListList = foodItembl.getTopThree();
		
		
			//before sorting
			try {
				for(FoodItem foodItem: foodItembl.getTopThree()) {
					System.out.println(foodItem);
				}
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			} catch (CategroryException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			} catch (FileCreationException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}
			System.out.println("After sorting....");
			Collections.sort(foodItemListList,new SortTopSold());
			try {
				//here we could sort last three from the array  list
				for(FoodItem foodItem: foodItembl.getTopThree()) {
					System.out.println(foodItem);
				}
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			} catch (CategroryException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			} catch (FileCreationException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}
		
		
	}
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//get elements
		addFoodItem();
		//retireve all the list
		//sort
		
		//using switch case ask user on what category he/she has to store the detail
		//and call respective layer methods to solve the problem.
		
	}

}
