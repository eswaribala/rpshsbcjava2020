package com.hsbc.retail.bl;

import java.io.IOException;
import java.util.List;

import com.hsbc.retail.exception.CategroryException;
import com.hsbc.retail.exception.FileCreationException;
import com.hsbc.retail.models.FoodItem;

public interface FoodItemBl {
	
boolean addfoodItems(List<FoodItem> foodItemList) throws CategroryException, FileCreationException;
	List<FoodItem> getTopThree() throws IOException, ClassNotFoundException, CategroryException, FileCreationException;

}
