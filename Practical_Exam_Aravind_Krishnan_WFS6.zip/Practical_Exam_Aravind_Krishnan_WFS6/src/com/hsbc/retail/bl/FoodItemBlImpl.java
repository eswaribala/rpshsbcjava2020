package com.hsbc.retail.bl;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import com.hsbc.retail.dao.FoodItemDaoimpl;
import com.hsbc.retail.dao.Fooditemdao;
import com.hsbc.retail.exception.CategroryException;
import com.hsbc.retail.exception.FileCreationException;
import com.hsbc.retail.models.FoodItem;

public class FoodItemBlImpl implements FoodItemBl{
	
	private Fooditemdao foodItemDao;
	
	
	public FoodItemBlImpl() throws FileCreationException {
		try {
			foodItemDao = new FoodItemDaoimpl();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			throw new FileCreationException("Not able to create file");
		}
	}
	@Override
	public boolean addfoodItems(List<FoodItem> foodItemList) throws  CategroryException, FileCreationException {
		// TODO Auto-generated method stub
		boolean status = false;
		try {
			status =  foodItemDao.addfoodItems(foodItemList);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			throw new CategroryException("Not able to store it in file");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			throw new FileCreationException("Not able to create file");
		}
		
		return status;
	}
	
	
	
	
	
	@Override
	public List<FoodItem> getTopThree() throws CategroryException, FileCreationException {
		// TODO Auto-generated method stub
		List<FoodItem> foodItemList = null;
		try {
			foodItemList =foodItemDao.getTopThree();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			throw new CategroryException("Not able to store it in file");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			throw new FileCreationException("Not able to create file");
		}
		
		
		return foodItemList;
	}

}
