package com.hsbc.retail.dao;

import java.io.File;
import java.io.IOException;
import java.util.ResourceBundle;

public class FileHelper {
	private static File file;
	private static ResourceBundle resourcebundle;
	public static File createFile() throws IOException
	{
		//create file
		resourcebundle = ResourceBundle.getBundle("com/hsbc/retial/resources/report");
		
		file=new File(resourcebundle.getString("filename"));
		if(!file.exists())
			file.createNewFile();	
		
        return file; 	

	}
}