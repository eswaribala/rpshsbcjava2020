package com.hsbc.retail.dao;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

import com.hsbc.retail.models.FoodItem;


public class FoodItemDaoimpl implements Fooditemdao
{
	
	private File file;
	//reading and writing byte stream
	private FileOutputStream fileOutputStream;
	private FileInputStream fileInputStream;
	
	// wrapper class to convert into objects
	//write
	private ObjectOutputStream objOutputStream;
	//read
	private ObjectInputStream objInputStream;
	
	
	public FoodItemDaoimpl() throws IOException {
		file = FileHelper.createFile();
		
		
	}


	@Override
	public boolean addfoodItems(List<FoodItem> foodItemList) throws IOException {
		// TODO Auto-generated method stub
		fileOutputStream = new FileOutputStream(file,true); // true helps u too append
		objOutputStream = new ObjectOutputStream(fileOutputStream);
		
		for(FoodItem foodItem: foodItemList) {
				//write object 
				objOutputStream.writeObject(foodItem);
	
			}
			objOutputStream.close();
			fileOutputStream.close();

		return true;
	}

	@Override
	public List<FoodItem> getTopThree() throws IOException, ClassNotFoundException {
		// TODO Auto-generated method stub
		fileInputStream = new FileInputStream(file);
		objInputStream = new ObjectInputStream(fileInputStream);
		
		List<FoodItem> foodItemList= new ArrayList<FoodItem>();
		FoodItem foodItem= null;
		try {
			
					while((foodItem = (FoodItem)objInputStream.readObject())!=null) {
						foodItemList.add(foodItem);					}
				}
				catch(EOFException e) {
					e.getMessage();
				}
				finally {
					objInputStream.close();
					fileInputStream.close();
				}
				
		return foodItemList;
	}

}
