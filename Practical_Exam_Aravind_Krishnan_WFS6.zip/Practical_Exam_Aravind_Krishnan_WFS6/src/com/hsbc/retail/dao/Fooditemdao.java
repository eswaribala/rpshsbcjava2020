package com.hsbc.retail.dao;

import java.io.IOException;
import java.util.List;

import com.hsbc.retail.models.FoodItem;

public interface Fooditemdao {
	boolean addfoodItems(List<FoodItem> foodItemList) throws IOException;
	
	List<FoodItem> getTopThree() throws IOException, ClassNotFoundException;
	
}
