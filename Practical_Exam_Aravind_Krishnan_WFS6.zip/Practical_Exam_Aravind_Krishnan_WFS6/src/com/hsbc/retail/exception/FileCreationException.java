package com.hsbc.retail.exception;

public class FileCreationException extends Exception{
	public FileCreationException(String message) {
		super(message);
	}
}
