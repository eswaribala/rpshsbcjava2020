package com.hsbc.retail.exception;

public class CategroryException extends Exception{
	
	public CategroryException(String message) {
		super(message);
	}

}
