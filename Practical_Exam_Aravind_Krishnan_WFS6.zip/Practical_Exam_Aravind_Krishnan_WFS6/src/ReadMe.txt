1.Entity Layer()              retails.views               Contains detail on how to retrieve and input the data
2. Exception layer            retails.exception           contains customized exception
3.Dao layer                   retails.dao                  contains interface and implementation file for the procedure on how to implement.
3. Business Layer              retails.bl                  contains interface and implementation layer for all the methods and rethrow the custom exceptions here.to display to view layer
4.property file              retails.resource              So that we need to keep passing the parameter every layer. 
Model Layer                     retails.models             this layer declares all the property or attribute of the class .