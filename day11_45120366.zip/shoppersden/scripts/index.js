//event callback
window.addEventListener('load',function()
{
    
    let myAccount=document.querySelector("nav > ul > li:nth-child(3) > a");
    myAccount.addEventListener('click',function()
    {
        countryAjaxFunction();
        document.querySelector("#content div").style.display="block";
    })
    document.querySelector("#regForm").addEventListener('submit',function()
    {
        alert("Form submitted....");
    })
    let count=document.querySelector("aside").childElementCount;
    let content=document.querySelector("#content");
    for(let i=1;i<=count;i++)
    {
        document.querySelector("aside > button:nth-child("+i+")").addEventListener('click',function()
        {
            if(i==1)
            {
                //alert(this.firstChild.nodeValue);
                while(content.hasChildNodes())
                    content.removeChild(content.firstChild);
                bookAjaxFunction();
            }
            else if(i==2)
            {
                //alert(this.firstChild.nodeValue);
                while(content.hasChildNodes())
                    content.removeChild(content.firstChild);
                giftFunction();
            }
            else if(i==3)
            {
                //alert(this.firstChild.nodeValue);
                while(content.hasChildNodes())
                    content.removeChild(content.firstChild);
                clothingFunction();
            }
            else
            {
                //alert(this.firstChild.nodeValue);
                while(content.hasChildNodes())
                    content.removeChild(content.firstChild);
                sportFunction();
            }
        })
    }
})

     function bookAjaxFunction(){ 
        var ajaxRequest; 
        try{ 
     ajaxRequest = new XMLHttpRequest(); 
        } catch (e){
         try{ 
         ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP3.0"); }
          catch (e){alert("Your browser broke!"); 				return false; 
          } 
      } 

     ajaxRequest.onreadystatechange = function(){ 
     if(ajaxRequest.readyState == 4 && ajaxRequest.status == 200){ 
         let table=document.createElement('table');
         let tr=document.createElement('tr');  
         //convert json text to json object 
        let response=JSON.parse(ajaxRequest.responseText);
        //response json array
        //console.log(response);
        //console.log(response.items);
        //read object by object
        //arrow function
        let count=0;
        response.items.forEach(obj=>{
            console.log(obj.volumeInfo.imageLinks.thumbnail);
            if(count<4)
            {
                td=document.createElement('td');
                img=new Image();
                img.src=obj.volumeInfo.imageLinks.thumbnail;
                img.width=100;
                img.height=100;
                td.appendChild(img);
                tr.appendChild(td);
                count++;
            }
            else
            {
                table.appendChild(tr);
                tr=document.createElement('tr');
                count=0;      
            }
         })
         table.appendChild(tr);
         let content=document.getElementById("content");
         content.appendChild(table);
        }
     } 
 
     ajaxRequest.open("GET", "https://www.googleapis.com/books/v1/volumes?q=corejava", true); 
     ajaxRequest.send(null); 
 }

 function countryAjaxFunction(){ 
    var ajaxRequest; 
    try{ 
 ajaxRequest = new XMLHttpRequest(); 
    } catch (e){
     try{ 
     ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP3.0"); }
      catch (e){alert("Your browser broke!"); 				return false; 
      } 
  } 

 ajaxRequest.onreadystatechange = function(){ 
 if(ajaxRequest.readyState == 4 && ajaxRequest.status == 200){ 
     let table=document.createElement('table');
     let tr=document.createElement('tr');  
     //convert json text to json object 
    let response=JSON.parse(ajaxRequest.responseText);
    let dataList=document.querySelector("#countryList");
    //response json array
    //console.log(response);
    //console.log(response.items);
    //read object by object
    //arrow function
    response.forEach(obj=>{
        console.log(obj.name);
        option=document.createElement("option");
        text=document.createTextNode(obj.name);
        option.appendChild(text);
        dataList.appendChild(option);
     })
    }
 } 

 ajaxRequest.open("GET", "https://restcountries.eu/rest/v2/all", true); 
 ajaxRequest.send(null); 
}

function giftFunction(){ 
    
     let table=document.createElement('table');
     let tr=document.createElement('tr');  
     let count=0;
            for(i=1;i<9;i++)
            {
                if(count<4)
                {
                    td=document.createElement('td');
                    img=new Image();
                    img.src="../resources/images/gifts"+i+".jpg"
                    img.width=100;
                    img.height=100;
                    td.appendChild(img);
                    tr.appendChild(td);
                    count++;
                }
                else
                {
                    table.appendChild(tr);
                    tr=document.createElement('tr');
                    count=0;      
                }
            }

     table.appendChild(tr);
     let content=document.getElementById("content");
     content.appendChild(table);

}

function clothingFunction(){ 
    
    let table=document.createElement('table');
    let tr=document.createElement('tr');  
    let count=0;
           for(i=1;i<9;i++)
           {
               if(count<4)
                {
                    td=document.createElement('td');
                    img=new Image();
                    img.src="../resources/images/clothings"+i+".jpg"
                    img.width=100;
                    img.height=100;
                    td.appendChild(img);
                    tr.appendChild(td);
                    count++;
                }
                else
                {
                    table.appendChild(tr);
                    tr=document.createElement('tr');
                    count=0;      
                }
           }

    table.appendChild(tr);
    let content=document.getElementById("content");
    content.appendChild(table);

}

function sportFunction(){ 
    
    let table=document.createElement('table');
    let tr=document.createElement('tr');  
    let count=0;
           for(i=1;i<9;i++)
           {
               if(count<4)
                {
                    td=document.createElement('td');
                    img=new Image();
                    img.src="../resources/images/sports"+i+".jpg"
                    img.width=100;
                    img.height=100;
                    td.appendChild(img);
                    tr.appendChild(td);
                    count++;
                }
                else
                {
                    table.appendChild(tr);
                    tr=document.createElement('tr');
                    count=0;      
                }
           }

    table.appendChild(tr);
    let content=document.getElementById("content");
    content.appendChild(table);

}