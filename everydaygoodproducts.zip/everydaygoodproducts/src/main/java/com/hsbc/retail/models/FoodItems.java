package com.hsbc.retail.models;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;
@Entity
@Table(name="FoodItems")
public class FoodItems extends Product{
	
	 @Column(name="DOM")
	 @DateTimeFormat(iso = ISO.DATE)
	 private LocalDate dateOfManufacturing;
	 @Column(name="DOE")
	 @DateTimeFormat(iso = ISO.DATE)
	 private LocalDate dateOfExpiry;
	 @Enumerated(EnumType.STRING)
	 @Column(name="Vegeterian_Type")
	 private VegeterianType vegeterian;  

	public LocalDate getDateOfManufacturing() {
		return dateOfManufacturing;
	}
	public void setDateOfManufacturing(LocalDate dateOfManufacturing) {
		this.dateOfManufacturing = dateOfManufacturing;
	}
	public LocalDate getDateOfExpiry() {
		return dateOfExpiry;
	}
	public void setDateOfExpiry(LocalDate dateOfExpiry) {
		this.dateOfExpiry = dateOfExpiry;
	}
	
	public VegeterianType getVegeterian() {
		return vegeterian;
	}

	
	
	public void setVegeterian(VegeterianType vegeterian) {
		this.vegeterian = vegeterian;
	}

   

}
