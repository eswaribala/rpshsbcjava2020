package com.hsbc.retail.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

@Entity
@Table(name="Product")
@Inheritance(strategy=InheritanceType.JOINED)
public class Product {
	@Id
	@Column(name="Item_Code")
	protected long itemCode;
	@Column(name="Item_Name",nullable = false,length = 50)
	protected String name;
	@Column(name="Unit_Price")
	protected int unitPrice;
	@Column(name="Qty")
	protected int qty;
	

	public Product() {
		// TODO Auto-generated constructor stub
	}

	public long getItemCode() {
		return itemCode;
	}

	public String getName() {
		return name;
	}

	public int getUnitPrice() {
		return unitPrice;
	}

	public int getQty() {
		return qty;
	}

	
	public void setItemCode(long itemCode) {
		this.itemCode = itemCode;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setUnitPrice(int unitPrice) {
		this.unitPrice = unitPrice;
	}

	public void setQty(int qty) {
		this.qty = qty;
	}

	
	

}
