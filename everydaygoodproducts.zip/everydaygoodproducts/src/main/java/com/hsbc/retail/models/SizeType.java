package com.hsbc.retail.models;

public enum SizeType {

	Large,Medium,Small
}
