package com.hsbc.retail.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;
@Entity
@Table(name="Apparel")
public class Apparel extends Product{
	
	@Enumerated(EnumType.STRING)
	@Column(name="SizeType")
	private SizeType size;
	@Enumerated(EnumType.STRING)
	@Column(name="MaterialType")
	private MaterialType materialType;	
	
	
	public void setSize(SizeType size) {
		this.size = size;
	}

	public void setMaterialType(MaterialType materialType) {
		this.materialType = materialType;
	}

	public SizeType getSize() {
		return size;
	}

	public MaterialType getMaterialType() {
		return materialType;
	}

	
	
	
}
