package com.hsbc.retail.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.hsbc.retail.models.Apparel;
import com.hsbc.retail.models.Electronics;
import com.hsbc.retail.models.FoodItems;
import com.hsbc.retail.models.Product;
import com.hsbc.retail.services.ProductService;

@RestController
public class ProductController {
    @Autowired
	private ProductService productService;
	@CrossOrigin("*")
    @PostMapping("/fooditems")
	public @ResponseBody FoodItems addFoodItems(@RequestBody FoodItems foodItems)
	{
		return this.productService.addFoodItem(foodItems);
	}
	
	@CrossOrigin("*")
	@PostMapping("/electronics")
	public @ResponseBody Electronics addElectronics(@RequestBody Electronics electronics)
	{
		return this.productService.addElectronics(electronics);
	}
	
	@CrossOrigin("*")
	@PostMapping("/apparels")
	public @ResponseBody Apparel addApparels(@RequestBody Apparel apparel)
	{
		return this.productService.addApparel(apparel);
	}
	
	@CrossOrigin("*")
	@GetMapping("/products")
	List<Product> getAllProducts()
	{
		return this.productService.getAllProducts();
		
	}
	
	@CrossOrigin("*")
	@GetMapping("/fooditems")
	String getAllFoodItems()
	{
		return this.productService.getAllFoodItems();
		
	}
	@CrossOrigin("*")
	@GetMapping("/electronics")
	String getAllElectronics()
	{
		return this.productService.getAllElectronics();
		
	}
	
	@CrossOrigin("*")
	@GetMapping("/apparels")
	String getAllApparels()
	{
		return this.productService.getAllApparels();
		
	}
	
	
}
