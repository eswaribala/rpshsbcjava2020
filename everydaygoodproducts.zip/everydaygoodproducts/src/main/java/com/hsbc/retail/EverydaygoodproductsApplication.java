package com.hsbc.retail;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EverydaygoodproductsApplication {

	public static void main(String[] args) {
		SpringApplication.run(EverydaygoodproductsApplication.class, args);
	}

}
