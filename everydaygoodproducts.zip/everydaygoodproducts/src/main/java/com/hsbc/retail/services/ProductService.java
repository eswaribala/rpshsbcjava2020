package com.hsbc.retail.services;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.bohnman.squiggly.Squiggly;
import com.github.bohnman.squiggly.util.SquigglyUtils;
import com.hsbc.retail.models.Apparel;
import com.hsbc.retail.models.Electronics;
import com.hsbc.retail.models.FoodItems;
import com.hsbc.retail.models.Product;
import com.hsbc.retail.repositories.ProductRepository;

@Service
public class ProductService {
    @Autowired 
	private ProductRepository productRepo;
      
    public Product addProduct(Product product)
    {
    	return this.productRepo.save(product);
    }
    
    public FoodItems addFoodItem(FoodItems foodItems)
    {
    	return this.productRepo.save(foodItems);
    }
    
    public Electronics addElectronics(Electronics electronics)
    {
    	return this.productRepo.save(electronics);
    }
    
    public Apparel addApparel(Apparel apparel)
    {
    	return this.productRepo.save(apparel);
    }
    
    public List<Product> getAllProducts()
    {
    	return productRepo.findAll();
    }
    
    public String getAllFoodItems()
    {       
    	List<FoodItems> foodItemsList=new ArrayList<FoodItems>();
    	FoodItems foodItems=null;
    	for(Product product : productRepo.findAll())
    	{
    		if(product instanceof FoodItems)
    		{
    		 foodItems=(FoodItems) product;
    		 foodItemsList.add(foodItems);
    		}
    	}
    //descending order	
     List<FoodItems> filteredList= foodItemsList.stream()
    		 .sorted(Comparator.comparingInt(FoodItems::getQty).reversed())
      .limit(3)      
      .collect(Collectors.toList());     
    
        String fields="itemCode,name,qty,unitPrice,vegeterian";
		ObjectMapper mapper = Squiggly.init(new ObjectMapper(), fields);  
		return SquigglyUtils.stringify(mapper, filteredList);
        
    }
    public String getAllElectronics()
    {       
    	List<Electronics> electronicsList=new ArrayList<Electronics>();
    	Electronics electronics=null;
    	for(Product product : productRepo.findAll())
    	{
    		if(product instanceof Electronics)
    		{
    			electronics=(Electronics) product;
    			electronicsList.add(electronics);
    		}
    	}
    //descending order	
     List<Electronics> filteredList= electronicsList.stream()
    		 .sorted(Comparator.comparingInt(Electronics::getQty).reversed())
      .limit(3)      
      .collect(Collectors.toList());     
    
        String fields="itemCode,name,qty,warranty";
		ObjectMapper mapper = Squiggly.init(new ObjectMapper(), fields);  
		return SquigglyUtils.stringify(mapper, filteredList);
        
    }
    public String getAllApparels()
    {       
    	List<Apparel> apparelList=new ArrayList<Apparel>();
    	Apparel apparel=null;
    	for(Product product : productRepo.findAll())
    	{
    		if(product instanceof Apparel)
    		{
    			apparel=(Apparel) product;
    			apparelList.add(apparel);
    		}
    	}
    //descending order	
     List<Apparel> filteredList= apparelList.stream()
    		 .sorted(Comparator.comparingInt(Apparel::getQty).reversed())
      .limit(3)      
      .collect(Collectors.toList());     
    
        String fields="itemCode,name,qty,size,materialType";
		ObjectMapper mapper = Squiggly.init(new ObjectMapper(), fields);  
		return SquigglyUtils.stringify(mapper, filteredList);
        
    }
}
