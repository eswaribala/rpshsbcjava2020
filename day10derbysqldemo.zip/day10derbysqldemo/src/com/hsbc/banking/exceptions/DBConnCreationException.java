package com.hsbc.banking.exceptions;

public class DBConnCreationException extends Exception{

	public  DBConnCreationException(String message)
	{
		super(message);
	}
}
