package com.hsbc.banking.exceptions;

public class DBQueryExecutionException extends Exception{

	public  DBQueryExecutionException(String message)
	{
		super(message);
	}
}
