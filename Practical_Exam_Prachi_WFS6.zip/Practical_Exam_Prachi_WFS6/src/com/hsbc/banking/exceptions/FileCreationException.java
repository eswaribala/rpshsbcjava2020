/*
 * 
 * @Author : Prachi Kanakdande
 */

package com.hsbc.banking.exceptions;

public class FileCreationException {

	public FileCreationException(String message)
	{
		super();
	}
}
