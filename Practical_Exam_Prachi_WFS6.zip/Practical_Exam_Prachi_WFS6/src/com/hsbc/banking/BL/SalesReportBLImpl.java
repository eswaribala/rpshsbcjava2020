/*
 * 
 * @Author : Prachi Kanakdande
 */

package com.hsbc.banking.BL;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import com.hsbc.banking.dao.SalesReportDao;
import com.hsbc.banking.dao.SalesReportDaoImpl;

import com.hsbc.banking.models.Apparel;
import com.hsbc.banking.models.Categories;
import com.hsbc.banking.models.Electronics;
import com.hsbc.banking.models.FoodItems;


public class SalesReportBLImpl implements SalesReportBL {

	private SalesReportDao salesReportDao;
	
	public  SalesReportBLImpl() throws IOException {

			salesReportDao=new SalesReportDaoImpl();
				
	}
	
	
	//Following methods are used to validate the IO operations
	
	
	@Override
	public boolean addCategory(List<Categories> categoryList) {
		// TODO Auto-generated method stub
		try {
			return salesReportDao.addCategory(categoryList);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return true;
	}

	@Override
	public boolean addFoodItems(List<FoodItems> foodItemsList) {
		// TODO Auto-generated method stub
		try {
			return salesReportDao.addFoodItems(foodItemsList);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		};
		return false;
	}

	@Override
	public boolean addApparels(List<Apparel> apparelsList) {
		// TODO Auto-generated method stub
		try {
			return salesReportDao.addApparels(apparelsList);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public boolean addElectronicsProducts(List<Electronics> electronicsList) {
		// TODO Auto-generated method stub
		try {
			return salesReportDao.addElectronicsProducts(electronicsList);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public List<FoodItems> getTopThreeFoodItems() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Apparel> getTopThreeApparels() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Electronics> getTopThreeElectronicsProducts() {
		// TODO Auto-generated method stub
		return null;
	}

}
