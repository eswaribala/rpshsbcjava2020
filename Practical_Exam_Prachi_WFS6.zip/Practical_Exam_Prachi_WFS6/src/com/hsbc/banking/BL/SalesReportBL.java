/*
 * 
 * @Author : Prachi Kanakdande
 */

package com.hsbc.banking.BL;

import java.util.List;

import com.hsbc.banking.models.Apparel;
import com.hsbc.banking.models.Categories;
import com.hsbc.banking.models.Electronics;
import com.hsbc.banking.models.FoodItems;

public interface SalesReportBL {

	boolean addCategory(List<Categories> categoryList);
	boolean addFoodItems(List<FoodItems> foodItemsList);
	boolean addApparels(List<Apparel> apparelsList);
	boolean addElectronicsProducts(List<Electronics> electronicsList);
	
	List<FoodItems> getTopThreeFoodItems();
	List<Apparel> getTopThreeApparels();
	List<Electronics> getTopThreeElectronicsProducts();
}
