/*
 * 
 * @Author : Prachi Kanakdande
 */

package com.hsbc.banking.dao;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import com.hsbc.banking.models.Apparel;
import com.hsbc.banking.models.Categories;
import com.hsbc.banking.models.Electronics;
import com.hsbc.banking.models.FoodItems;

/*SalesReportDao interface contains methods to take the category wise input and show
 * the top three products in each category.
 * These methods are implemented in SalesReportDaoImpl class
 */

public interface SalesReportDao {
	
	boolean addCategory(List<Categories> categoryList) throws IOException;
	boolean addFoodItems(List<FoodItems> foodItemsList) throws FileNotFoundException, IOException;
	boolean addApparels(List<Apparel> apparelsList) throws FileNotFoundException, IOException;
	boolean addElectronicsProducts(List<Electronics> electronicsList) throws FileNotFoundException, IOException;
	
	List<FoodItems> getTopThreeFoodItems();
	List<Apparel> getTopThreeApparels();
	List<Electronics> getTopThreeElectronicsProducts();
	
	
}
