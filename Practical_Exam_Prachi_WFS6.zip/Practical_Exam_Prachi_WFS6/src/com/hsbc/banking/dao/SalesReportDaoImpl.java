/*
 * 
 * @Author : Prachi Kanakdande
 */

package com.hsbc.banking.dao;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.List;

import com.hsbc.banking.models.Apparel;
import com.hsbc.banking.models.Categories;
import com.hsbc.banking.models.Electronics;
import com.hsbc.banking.models.FoodItems;


public class SalesReportDaoImpl implements SalesReportDao{

	private File file;
	private FileOutputStream fileOutputStream;
	private FileInputStream fileInputStream;
	private ObjectOutputStream objectOutputStream;
	private ObjectInputStream objectInputStream;
	
	public SalesReportDaoImpl() throws IOException
	{
		file=FileHelper.createFile(null, 0);     
	}
	

	
	/*
	 * addCategory(List<Categories> categoryList) this method is used to store 
	 * all the common entities (i.e. Item code ,name ,unit price and quantity) 
	 * for FoodItems, Apparels and electronics products in file.
	 */
	@Override
	public boolean addCategory(List<Categories> categoryList) throws IOException {
		// TODO Auto-generated method stub
	
		fileOutputStream=new FileOutputStream(file,true);
		objectOutputStream=new ObjectOutputStream(fileOutputStream);
		for(Categories category : categoryList)
		{
			objectOutputStream.writeObject(category);
		}
		objectOutputStream.close();
		fileOutputStream.close();
		
		
		return true;
		
		
	}

	@Override
	public boolean addFoodItems(List<FoodItems> foodItemsList) throws IOException {
		// TODO Auto-generated method stub
		
		fileOutputStream=new FileOutputStream(file,true);
		objectOutputStream=new ObjectOutputStream(fileOutputStream);
		for(FoodItems foodItem : foodItemsList)
		{
			objectOutputStream.writeObject(foodItem);
		}
		objectOutputStream.close();
		fileOutputStream.close();
		
		
		return true;
		
	}

	@Override
	public boolean addApparels(List<Apparel> apparelsList) throws IOException {
		// TODO Auto-generated method stub
	
		fileOutputStream=new FileOutputStream(file,true);
		objectOutputStream=new ObjectOutputStream(fileOutputStream);
		for(Apparel apparel : apparelsList)
		{
			objectOutputStream.writeObject(apparel);
		}
		objectOutputStream.close();
		fileOutputStream.close();
		

		return true;
	
	}

	@Override
	public boolean addElectronicsProducts(List<Electronics> electronicsList) throws IOException {
		// TODO Auto-generated method stub
		fileOutputStream=new FileOutputStream(file,true);
		objectOutputStream=new ObjectOutputStream(fileOutputStream);
		for(Electronics electronics : electronicsList)
		{
			objectOutputStream.writeObject(electronics);
		}
		objectOutputStream.close();
		fileOutputStream.close();
		
		
		return true;
	}

	@Override
	public List<FoodItems> getTopThreeFoodItems() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Apparel> getTopThreeApparels() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Electronics> getTopThreeElectronicsProducts() {
		// TODO Auto-generated method stub
		return null;
	}

}
