/*
 * 
 * @Author : Prachi Kanakdande
 */

package com.hsbc.banking.models;

public class Electronics extends Categories{

	private int warranty;

	//Generate getters and setters for the above entity

	public int getWarranty() {
		return warranty;
	}

	
	public void setWarranty(int warranty) {
		this.warranty = warranty;
	}


	

	
	
	
}
