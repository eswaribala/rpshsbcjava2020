/*
 * 
 * @Author : Prachi Kanakdande
 */

package com.hsbc.banking.models;

import java.time.LocalDate;



public class FoodItems extends Categories{

	   private LocalDate dateOfManufacturing; 
	   private LocalDate dateOfExpiry;
	   
	 //Enum class Vegiterian is created to take Vegiterian input as YES/NO
	   private Vegiterian isVegeterian;
	   
	 
	 //Getters and Setters method are created for the above fields 
	public LocalDate getDateOfManufacturing() {
		return dateOfManufacturing;
	}
	public void setDateOfManufacturing(LocalDate dateOfManufacturing) {
		this.dateOfManufacturing = dateOfManufacturing;
	}
	public LocalDate getDateOfExpiry() {
		return dateOfExpiry;
	}
	public void setDateOfExpiry(LocalDate dateOfExpiry) {
		this.dateOfExpiry = dateOfExpiry;
	}
	public Vegiterian getIsVegeterian() {
		return isVegeterian;
	}
	public void setIsVegeterian(Vegiterian isVegeterian) {
		this.isVegeterian = isVegeterian;
	}
	
   
	   
	   
}
