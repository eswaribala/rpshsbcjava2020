/*
 * 
 * @Author : Prachi Kanakdande
 */

package com.hsbc.banking.models;

import java.io.Serializable; //to insert the contents in file serially

public class Categories implements Serializable {
		
	protected long itemCode;  
	protected String name;
	protected int unitPrice;
	protected int quantity;
	
	//Getters and Setters method are created for the above fields 
	
	public long getItemCode() {
		return itemCode;
	}
	public void setItemCode(long itemCode) {
		this.itemCode = itemCode;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getUnitPrice() {
		return unitPrice;
	}
	public void setUnitPrice(int unitPrice) {
		this.unitPrice = unitPrice;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	

}
