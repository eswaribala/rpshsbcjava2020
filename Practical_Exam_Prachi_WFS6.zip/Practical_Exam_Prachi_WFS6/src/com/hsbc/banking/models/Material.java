/*
 * 
 * @Author : Prachi Kanakdande
 */

package com.hsbc.banking.models;

//Enum class Material is created to take Material of Apparel as COTTON or WOOLEN

public enum Material {
COTTON,WOOLEN
}
