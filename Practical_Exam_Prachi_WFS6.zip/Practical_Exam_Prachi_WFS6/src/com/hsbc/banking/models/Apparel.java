/*
 * 
 * @Author : Prachi Kanakdande
 */

package com.hsbc.banking.models;

public class Apparel extends Categories {
	
	//Enum class Size is created to take size input as SMALL,MEDIUM,LARGE
	private Size size; 
	//Enum class Size is created to take size input as SMALL,MEDIUM,LARGE
	private Material materialType;
	
	//Getters and Setters method are created for the above fields 
	
	public Size getSize() {
		return size;
	}
	public void setSize(Size size) {
		this.size = size;
	}
	public Material getMaterialType() {
		return materialType;
	}
	public void setMaterialType(Material materialType) {
		this.materialType = materialType;
	}
	
	
	

}
