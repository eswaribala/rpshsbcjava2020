/*
 * 
 * @Author : Prachi Kanakdande
 */

package com.hsbc.banking.models;

//Enum class Vegiterian is created to confirm the customer as Vegiterian or non-Vegiterian (yes/no)
public enum Vegiterian {
YES,NO
}
