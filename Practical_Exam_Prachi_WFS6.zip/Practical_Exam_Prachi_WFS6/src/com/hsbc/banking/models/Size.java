/*
 * 
 * @Author : Prachi Kanakdande
 */

package com.hsbc.banking.models;

//Enum class Material is created to take Size of Apparel as SMALL,MEDIUM or LARGE

public enum Size {
SMALL,MEDIUM,LARGE
}
