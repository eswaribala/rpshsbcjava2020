Layer             File             Description
Model		Apparel		To represent  the Category and different items within
		Category
		Electronics
		FoodItem

Data Access	CategoryDao	Representation and implementation of all required functions
		CategoryImpl

Business Layer	CategoryBL	Representation and implementation of all required functions
		CategoryBLImpl

Views		SalesApp	Interaction with the user

Exceptions	FileCreateException  	To create custom FileCreateException