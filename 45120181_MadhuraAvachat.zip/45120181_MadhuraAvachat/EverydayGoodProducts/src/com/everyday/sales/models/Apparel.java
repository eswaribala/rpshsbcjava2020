/**
 * Author: Madhura Satish Avachat
 * 
 * Purpose: To represent Apparel Category, extends Category class
 * 
 */


package com.everyday.sales.models;

import java.io.Serializable;

public class Apparel extends Category implements Serializable{

	private  int itemCode = 0;
	private String itemName = "";
	private long unitPrice = 0;
	private int quantity = 0;
	private float size;
	private String material;
	public float getSize() {
		return size;
	}
	public void setSize(float size) {
		this.size = size;
	}
	public String getMaterial() {
		return material;
	}
	public void setMaterial(String material) {
		this.material = material;
	}
	
	public int getItemCode() {
		
		return this.itemCode;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public long getUnitPrice() {
		return unitPrice;
	}
	public void setUnitPrice(long unitPrice) {
		this.unitPrice = unitPrice;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public void setItemCode(int itemCode) {
		this.itemCode = itemCode;
	}
	
	
}
