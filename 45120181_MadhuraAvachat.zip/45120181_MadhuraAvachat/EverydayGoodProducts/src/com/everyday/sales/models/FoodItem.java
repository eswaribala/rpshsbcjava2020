/**
 * Author: Madhura Satish Avachat
 * 
 * Purpose: To represent Food Items Category, extends Category class
 * 
 */
package com.everyday.sales.models;

import java.io.Serializable;
import java.time.LocalDate;

public class FoodItem extends Category implements Serializable{

	private LocalDate dateOfManufacture;
	private LocalDate dateOfExpiry;
	private boolean isVeg;
	private  int itemCode = 0;
	private String itemName = "";
	private long unitPrice = 0;
	private int quantity = 0;
	
	public LocalDate getDateOfManufacture() {
		return dateOfManufacture;
	}
	public void setDateOfManufacture(LocalDate dateOfManufacture) {
		this.dateOfManufacture = dateOfManufacture;
	}
	public LocalDate getDateOfExpiry() {
		return dateOfExpiry;
	}
	public void setDateOfExpiry(LocalDate dateOfExpiry) {
		this.dateOfExpiry = dateOfExpiry;
	}
	public boolean isVeg() {
		return isVeg;
	}
	public void setVeg(boolean isVeg) {
		this.isVeg = isVeg;
	}
	public int getItemCode() {
		return itemCode;
	}
	public void setItemCode(int itemCode) {
		this.itemCode = itemCode;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public long getUnitPrice() {
		return unitPrice;
	}
	public void setUnitPrice(long unitPrice) {
		this.unitPrice = unitPrice;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	
	
	
}
