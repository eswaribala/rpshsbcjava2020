/**
 * Author: Madhura Satish Avachat
 * 
 * Purpose: To represent Electronics Category, extends Category class
 * 
 */
package com.everyday.sales.models;

import java.io.Serializable;

public class Electronics extends Category implements Serializable{
	private  int itemCode = 0;
	private String itemName = "";
	private long unitPrice = 0;
	private int quantity = 0;
	private int warranty;
	public int getItemCode() {
		return itemCode;
	}
	public void setItemCode(int itemCode) {
		this.itemCode = itemCode;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public long getUnitPrice() {
		return unitPrice;
	}
	public void setUnitPrice(long unitPrice) {
		this.unitPrice = unitPrice;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public int getWarranty() {
		return warranty;
	}
	public void setWarranty(int warranty) {
		this.warranty = warranty;
	}
	
	
}
