package com.everyday.sales.exceptions;

public class FileCreateException extends Exception{

	public FileCreateException(String message)
	{
		super(message);
	}
}
