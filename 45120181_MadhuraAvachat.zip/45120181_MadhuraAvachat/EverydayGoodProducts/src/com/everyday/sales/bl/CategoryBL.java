/**
 * Author: Madhura Satish Avachat
 * 
 * Purpose: Interface representation of all the functions in Business Layer
 * 
 */

package com.everyday.sales.bl;

import java.io.IOException;

import com.everyday.sales.models.Apparel;
import com.everyday.sales.models.Category;
import com.everyday.sales.models.Electronics;
import com.everyday.sales.models.FoodItem;

public interface CategoryBL {
	boolean addCategory(Category[] categories) throws IOException;
	Category[] getAllCategories() throws ClassNotFoundException, IOException;
	
	boolean addApparel(Apparel[] apparels) throws IOException;
	Apparel[] getTopApparels() throws ClassNotFoundException, IOException;
	
	boolean addFoodItem(FoodItem[] foodItems) throws IOException;
	FoodItem[] getTopFoodItem() throws ClassNotFoundException, IOException;

	boolean addElectronics(Electronics[] electronics) throws IOException;
	Electronics[] getTopElectronics() throws ClassNotFoundException, IOException;
}
