package com.everyday.sales.bl;

import java.io.IOException;
import java.util.Arrays;
import java.util.Comparator;

import com.everyday.sales.models.Apparel;
import com.everyday.sales.models.Category;
import com.everyday.sales.models.Electronics;
import com.everyday.sales.models.FoodItem;
import com.everyday.sales.dao.CategoryDao;

public class CategoryBLImpl implements CategoryBL{

	private CategoryDao categoryDao;

	@Override
	public boolean addCategory(Category[] categories) throws IOException {
		// TODO Auto-generated method stub
		return categoryDao.addCategory(categories);

	}

	@Override
	public Category[] getAllCategories() throws ClassNotFoundException, IOException {
		// TODO Auto-generated method stub
		return categoryDao.getAllCategories();
	}

	@Override
	public boolean addApparel(Apparel[] apparels) throws IOException {
		// TODO Auto-generated method stub
		return categoryDao.addApparel(apparels);
	}

	@Override
	public Apparel[] getTopApparels() throws ClassNotFoundException, IOException {
		// TODO Auto-generated method stub
		Apparel[] apparelArray = categoryDao.getTopApparels();
	  
		
		return null;
	}

	@Override
	public boolean addFoodItem(FoodItem[] foodItems) throws IOException {
		// TODO Auto-generated method stub
		return categoryDao.addFoodItem(foodItems);
	}

	@Override
	public FoodItem[] getTopFoodItem() throws ClassNotFoundException, IOException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean addElectronics(Electronics[] electronics) throws IOException {
		// TODO Auto-generated method stub
		return categoryDao.addElectronics(electronics);
	}

	@Override
	public Electronics[] getTopElectronics() throws ClassNotFoundException, IOException {
		// TODO Auto-generated method stub
		return null;
	}

}
