/**
 * Author: Madhura Satish Avachat
 * 
 * Purpose: App inorder to implements all the created methods
 * 
 */
package com.everyday.sales.views;

import java.io.IOException;
import java.util.Random;

import com.everyday.sales.bl.CategoryBL;
import com.everyday.sales.bl.CategoryBLImpl;
import com.everyday.sales.exceptions.FileCreateException;
import com.everyday.sales.models.Category;

public class SalesApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
	}

}
