Entity layer/model layer :


It contains Categories class which is extended by FoodItems,Electronics and Apparel classes.

Categories class contain the entities common to FoodItems,Electronics and Apparel classes like itemcode,itemname,unit price and quantity.

FoodItems,Electronics and Apparel classes contain their category specific entities.


Dao Layer :
1.Contains FileHelper class to create the file
2.Contains the interface SalesReportDao which is implemented by SalesReportDaoImpl class.It contains the method to get the categorywise input and showing top 3 categories.


BL Layer :

Contains the interface SalesReportBL which is implemented by SalesReportBLImpl class.It contains the method to validate categorywise input and showing top 3 categories.


Exception Layer :

Contains classes to handle the exceptions