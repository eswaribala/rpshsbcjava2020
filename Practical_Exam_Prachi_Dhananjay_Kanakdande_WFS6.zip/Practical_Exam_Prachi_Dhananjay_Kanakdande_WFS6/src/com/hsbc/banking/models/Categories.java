package com.hsbc.banking.models;

public class Categories {

}
