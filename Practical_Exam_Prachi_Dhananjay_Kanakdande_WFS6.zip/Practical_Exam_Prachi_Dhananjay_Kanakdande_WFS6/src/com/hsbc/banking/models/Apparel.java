package com.hsbc.banking.models;

public class Apparel {

}
