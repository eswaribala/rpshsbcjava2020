package com.hsbc.banking.exceptions;

public class FileCreationException {

}
