package com.hsbc.banking.dao;

public interface SalesReportDao {

}
