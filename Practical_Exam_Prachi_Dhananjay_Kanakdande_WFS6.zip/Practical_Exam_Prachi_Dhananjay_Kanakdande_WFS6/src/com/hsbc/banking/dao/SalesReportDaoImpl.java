package com.hsbc.banking.dao;

public class SalesReportDaoImpl {

}
