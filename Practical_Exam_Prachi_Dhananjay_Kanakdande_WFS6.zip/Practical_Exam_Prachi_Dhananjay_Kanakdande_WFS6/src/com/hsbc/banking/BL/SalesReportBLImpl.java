package com.hsbc.banking.BL;

public class SalesReportBLImpl {

}
