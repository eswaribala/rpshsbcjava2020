package com.hsbc.banking.BL;

public interface SalesReportBL {

}
