package com.hsbc.worker.views;

import java.util.Scanner;

import com.hsbc.workers.dailywageworker;
import com.hsbc.workers.salariedworker;
import com.hsbc.workers.worker;

public class workerApp {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
   
		worker w1;
		w1=new dailywageworker(); //daily wage worker
		Scanner s=new Scanner(System.in);
		System.out.println("enter name of worker");
		w1.setName(s.nextLine());
		System.out.println("enter number of hrs worked");
		int hrs=s.nextInt();
		s.nextLine();
		w1.calculatepay(hrs); 
		//w1.toString();
		System.out.println(w1.toString());
		
		w1=new salariedworker();//  salaried worker
		System.out.println("enter name of worker");
		w1.setName(s.nextLine());
		System.out.println("enter number of hrs worked");
		
		w1.calculatepay(s.nextInt()); 
		//w1.toString();
		System.out.println(w1);
		
	}

}
