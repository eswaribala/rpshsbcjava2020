package com.hsbc.workers;

import java.util.Scanner;

public class salariedworker extends worker{


	private float salaryrate;
    private double pay;
    Scanner s=new Scanner(System.in);
	@Override
	public void calculatepay(int hrs) {
		// TODO Auto-generated method stub
		System.out.println("Enter salaryrate per hr");
		salaryrate=s.nextFloat();
		s.nextLine();
		pay=salaryrate*40;
		//System.out.println("The weekly pay is"+pay);
	}
	@Override
	public String toString() {
		return "name"+super.toString()+"salariedworker details [salaryrate=" + salaryrate + ", pay=" + pay + ", s=" + s + "]";
	}
	
	
}
