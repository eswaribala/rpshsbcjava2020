package com.hsbc.workers;

import java.util.Scanner;

public class dailywageworker extends worker{
   
	private double salaryrate;
    private double pay;
    Scanner s=new Scanner(System.in);
	@Override
	public void calculatepay(int hrs) {
		// TODO Auto-generated method stub
		System.out.println("Enter salaryrate per hr");
		salaryrate=s.nextLong();
		s.nextLine();
		System.out.println("Enter number of days worked in a week");
		int days=s.nextInt();
		pay=salaryrate*days*hrs;
		//System.out.println("The weekly pay is"+pay);
	}
	@Override
	public String toString() {
		return "name"+super.toString()+ "salary details daily wage worker [salaryrate=" + salaryrate + ", pay=" + pay + ", s=" + s + "]";
	}

	
	

}
