package com.hsbc.workers;

public abstract class worker {
	
	private String name;
	public abstract void calculatepay(int hrs);
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "worker [name=" + name + "]";
	}
	
	

}
