package com.hsbc.banking.utility;

public class Java7FeaturesDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//binary number
		int mask=0b1010101010010;
		System.out.println(mask);
		//underscore allowed
		long creditCardNumber=1234_5678_9012_3456L;
		System.out.println(creditCardNumber);
		

	}

}
