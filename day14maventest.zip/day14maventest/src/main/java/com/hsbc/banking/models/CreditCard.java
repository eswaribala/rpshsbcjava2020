package com.hsbc.banking.models;

import java.time.LocalDate;
import java.util.Random;

public class CreditCard {
	
	private long cardNo;
	private LocalDate expiryDate;
	public long getCardNo() {
		return cardNo;
	}
	public void setCardNo(long cardNo) {
		this.cardNo = cardNo;
	}
	public LocalDate getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(LocalDate expiryDate) {
		this.expiryDate = expiryDate;
	}
	
	public CreditCard getData()
	{
		CreditCard creditCard=new CreditCard();
		creditCard.setCardNo(1234567890123456L+new Random().nextInt(1000));
		creditCard.setExpiryDate(LocalDate.of(2000+new Random().nextInt(25)+1, 
				new Random().nextInt(10)+1, new Random().nextInt(27)+1));
		return creditCard;
	}

}
