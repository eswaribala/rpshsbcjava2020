package com.hsbc.banking.utility;

import java.util.Random;

import com.hsbc.banking.interfaces.OTPGenerator;

public class OTPApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//4 digit otp
		//instantiation
		OTPGenerator otpGenerator=()->{
			return 1000+new Random().nextInt(999);
		};
		
		//invoke
		System.out.println(otpGenerator.getOTP());
		
	}

}
