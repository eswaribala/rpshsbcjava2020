package com.hsbc.banking.utility;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Random;
import java.util.function.BiFunction;
import java.util.function.BinaryOperator;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

import com.hsbc.banking.interfaces.OTPGenerator;
import com.hsbc.banking.interfaces.TriFunction;
import com.hsbc.banking.models.CreditCard;
import com.hsbc.banking.models.Product;

public class BuiltInFunctionalInterfaceDemo {
	
	private static List<Product> getAllProducts()
	{
		List<Product> productList=new ArrayList<>();
	
		Product product=null;
		for(int i=0;i<100;i++)
		{
			product=new Product();
			product.setName("Product"+i);
			product.setDop(LocalDate.of(2000+new Random().nextInt(19)+1, 
					new Random().nextInt(10)+1, new Random().nextInt(27)+1));
			productList.add(product);
		}
        return productList;		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//generate otp for the given seed
		//saving time to create functional interface
		//in built functional interface
		//instantiation
		Function<Integer,Integer> genOTP=(val)->{
			return new Random().nextInt(val);
		};		
		//invoke
		System.out.println(genOTP.apply(3000));		
		//find given dop before or after current date
		Function<LocalDate,Boolean> testDOP=(dop)->{			
			return dop.isAfter(LocalDate.now());
		};
		//invoke
		if(testDOP.apply(LocalDate.of(2000+new Random().nextInt(25)+1, 
				new Random().nextInt(10)+1, new Random().nextInt(27)+1)))
			System.out.println("Invalid DOP");
		else
			System.out.println("Valid DOP");
		
		
		//Take two strings and concatenate
		
		BiFunction<String,String,String> concatMessage=(s1,s2)->{
			return s1+" "+s2;
		};
		System.out.println(concatMessage.apply("HSBC","Technology"));
		
		//		
		TriFunction<Integer,Integer,Integer,Float> avgFunction=(t1,t2,t3)->{
			return (t1+t2+t3)/3.0F;
		};
		
		System.out.println(avgFunction.apply(new Random().nextInt(1000),
				new Random().nextInt(1000),new Random().nextInt(1000)));
		
		
		//consumer 		
		Consumer<List<Product>> consumer=(productList)->{
			
			for(Product product : productList)
			{
				if(product.getDop().isBefore(LocalDate.of(2010, 1, 1)))
					System.out.println(product.getName()+","+product.getDop().toString());
			}
		
		};		
		//invoke
		consumer.accept(getAllProducts());
		
		//supplier takes nothing and returns the result
		//to create the object
		//credit card validate card no and expiry date		
		Supplier<CreditCard> supplier=CreditCard::new;
		//validate card no
		Function<CreditCard,LocalDate> cardValidator=(obj)->{
			
			if(String.valueOf(obj.getCardNo()).length()==16)
				return obj.getExpiryDate();
			else
				return null;
		};		
		//validate expiry date
		Function<LocalDate,Boolean> expDateValidator=(expDate)->{
			if(expDate.isAfter(LocalDate.now()))
				return true;
			else
				return false;
		};		
		//chain of operations
		if(cardValidator.andThen(expDateValidator).apply(supplier.get().getData()))
			System.out.println("CC is valid");
		else
			System.out.println("CC is invalid");
		
		
		//another example for supplier
		Supplier otpSupplier=()->{
			return new Random().nextLong();
		};
		System.out.println(otpSupplier.get());
		
		//third way
		Supplier otp=OTPGenerator::getOTPData;
		System.out.println(otp.get());
		
		//predicate always return boolean
		Predicate<LocalDate> testDate=(dop)->{
			if(dop.isAfter(LocalDate.now()))
				return true;
			else
				return false;
		};
		
		//test predicate
		System.out.println(testDate.test(LocalDate.of(2000+new Random().nextInt(19)+1, 
					new Random().nextInt(10)+1, new Random().nextInt(27)+1)));
		
		//Binary Operator
		
		CreditCard cc1=new CreditCard();
		cc1.setCardNo(1234567890123456L+new Random().nextInt(1000));
		cc1.setExpiryDate(LocalDate.of(2000+new Random().nextInt(25)+1, 
				new Random().nextInt(10)+1, new Random().nextInt(27)+1));
		
		
		CreditCard cc2=new CreditCard();
		cc2.setCardNo(1234567890123456L+new Random().nextInt(1000));
		cc2.setExpiryDate(LocalDate.of(2000+new Random().nextInt(25)+1, 
				new Random().nextInt(10)+1, new Random().nextInt(27)+1));
		Comparator<CreditCard> comparator = (c1, c2) -> {
			int result=0;
			if(c1.getCardNo()>c2.getCardNo())
					result=1;
			if(c1.getCardNo()<c2.getCardNo())
					result= -1;
			if(c1.getCardNo()==c2.getCardNo())
					result= 0;		
			return result;
		};
		
		BinaryOperator<CreditCard> compareCards=BinaryOperator.maxBy(comparator);
		
		System.out.println(compareCards.apply(cc1,cc1).getCardNo());
		
		
		
	}

}
