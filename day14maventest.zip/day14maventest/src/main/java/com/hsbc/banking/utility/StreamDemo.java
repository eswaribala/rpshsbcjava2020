package com.hsbc.banking.utility;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

import com.hsbc.banking.models.Product;

public class StreamDemo {

	private static List<Product> getAllProducts()
	{
		List<Product> productList=new ArrayList<>();
	
		Product product=null;
		for(int i=0;i<100;i++)
		{
			product=new Product();
			product.setName("Product"+i);
			product.setDop(LocalDate.of(2000+new Random().nextInt(19)+1, 
					new Random().nextInt(10)+1, new Random().nextInt(27)+1));
			productList.add(product);
		}
        return productList;		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         //stream
		System.out.println(getAllProducts().stream()
				.filter(p->p.getDop().getYear()>2010)				
				.count());
			
		getAllProducts().stream()
		.filter(p->p.getDop().getYear()>2010)
		.sorted((p1,p2)->{
			return p1.getDop().compareTo(p2.getDop());
		})
		.map(p->p.getName())		
		.forEach(System.out::println);
		
		List<Product> filteredList=getAllProducts().stream()
		.filter(p->p.getDop().getYear()>2010)
		.collect(Collectors.toList());
				
		getAllProducts().stream()
		.filter(p->p.getDop().getYear()>2010)
		.limit(5).forEach(System.out::println);
		
		
		
		
		
	}

}
