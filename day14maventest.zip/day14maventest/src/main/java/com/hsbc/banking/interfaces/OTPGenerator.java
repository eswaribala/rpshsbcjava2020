package com.hsbc.banking.interfaces;

import java.util.Random;

@FunctionalInterface
public interface OTPGenerator {

	int getOTP();
	
	static int getOTPData()
	{
		return new Random().nextInt();
	}
}
