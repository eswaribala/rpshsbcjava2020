package com.hsbc.sports;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day18springbootsportsuiapplnApplicationTests {

	@Test
	void contextLoads() {
	}

}
