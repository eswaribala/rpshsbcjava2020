package com.hsbc.sports.models;


/**
 * @author Balasubramaniam
 *
 */
//DTO
public class Winner {
	
	private int tennisId;

	private String tournamentId;

	private String location;

	private String date;

	private int matchNo;

	private String winnerName;	
	
	public int getTennisId() {
		return tennisId;
	}
	public void setTennisId(int tennisId) {
		this.tennisId = tennisId;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public int getMatchNo() {
		return matchNo;
	}
	public void setMatchNo(int matchNo) {
		this.matchNo = matchNo;
	}
	public String getWinnerName() {
		return winnerName;
	}
	public void setWinnerName(String winnerName) {
		this.winnerName = winnerName;
	}
	public String getTournamentId() {
		return tournamentId;
	}
	public void setTournamentId(String tournamentId) {
		this.tournamentId = tournamentId;
	}
	

}
