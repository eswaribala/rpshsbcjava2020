package com.hsbc.sports.controllers;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import com.hsbc.sports.models.Winner;

@Controller
public class WinnerMVCController {
	@Autowired
	private RestTemplate restTemplate;
	//read it from application.properties
	@Value("${serviceUrl}")
	private String serviceUrl;
	
	
	@GetMapping("/")
	public String home(Model model)
	{
		//inter service communication
		ResponseEntity<Winner[]> responseEntity=restTemplate.exchange(serviceUrl, HttpMethod.GET, 
				null,Winner[].class);
		Winner[] winners=responseEntity.getBody();
		List<Winner> winnerList=Arrays.asList(winners);
		//for(Winner winner: winnerList)
			//System.out.println(winner.getWinnerName());
		model.addAttribute("winnerList", winnerList);		
		return "index";
	}
	
	@GetMapping("/loadWinnerForm")
	public String loadWinnerForm(Model model)
	{
		model.addAttribute("winner", new Winner());
		return "addWinner";
	}
	
	@GetMapping("/loadWinnerSearchForm")
	public String loadWinnerSearchForm()
	{
		
		return "searchWinner";
	}

	@PostMapping("/winners")
	public String addWinner(@ModelAttribute("winner") Winner winner) 
	{
		//System.out.println("Winner Name"+winner.getWinnerName());	
		
		  HttpHeaders headers = new HttpHeaders();
		  headers.setContentType(MediaType.APPLICATION_JSON); 
		  HttpEntity<Winner> request = new HttpEntity<>(winner,headers); 
		  ResponseEntity<?> serviceResponse=restTemplate. postForEntity(serviceUrl,request,
		  Winner.class);
		 
	
		return "redirect:/";

	}
	
	@PostMapping("/searchWinners")
	public String addWinner(@RequestParam("winnerName") String winnerName, Model  model) 
	{
		System.out.println("Winner Name"+winnerName);			
		//interservice communication 
		ResponseEntity<Winner[]> responseEntity=restTemplate.exchange(serviceUrl+"/"+winnerName, 
				HttpMethod.GET, 
				null,Winner[].class);
		Winner[] winners=responseEntity.getBody();
		List<Winner> winnerList=Arrays.asList(winners);
		//for(Winner winner: winnerList)
			//System.out.println(winner.getWinnerName());
		model.addAttribute("winnerList", winnerList);	
		
		return "showWinnerDataByName";

	}
	
	
}
