package com.hsbc.sports.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hsbc.sports.models.Winner;
import com.hsbc.sports.repositories.WinnerRepository;

@Service
public class WinnerService {
	@Autowired
	private WinnerRepository winnerRepo;
	
	//insert query	
	public Winner addWinner(Winner winner)
	{
		
		return winnerRepo.save(winner);
	}
	
	
	//select all
	
	public List<Winner> getAllWinners()
	{
		return winnerRepo.findAll();
	}
	
	//select by player name
	//non primary key
	public List<Winner> getPlayerByName(String playerName)
	{
		return winnerRepo.findByPlayerName(playerName);
	}
	

}
