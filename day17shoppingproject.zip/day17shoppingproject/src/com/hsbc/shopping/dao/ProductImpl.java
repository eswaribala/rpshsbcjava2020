package com.hsbc.shopping.dao;

import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.hsbc.shopping.models.Product;
@Repository
public class ProductImpl implements ProductDao{

	@Autowired
	private JdbcTemplate jdbcTemplate;
	private boolean status;
	
	@Override
	public boolean addProduct(Product product) {
		// TODO Auto-generated method stub
	  int result=jdbcTemplate.update("insert into ADMIN.PRODUCT(NAME,UNITPRICE,DOP) values "
	  		+ "(?,?,?)",
				product.getName(),product.getUnitPrice(),Date.valueOf(product.getDop())
				);
		
	  if(result>0)
		status=true;
	  return status;
	}

	@Override
	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
		return jdbcTemplate.query("select * from ADMIN.PRODUCT", 
				new BeanPropertyRowMapper<Product>(Product.class));
	}

}
