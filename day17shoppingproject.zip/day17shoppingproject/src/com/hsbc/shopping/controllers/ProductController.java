package com.hsbc.shopping.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.hsbc.shopping.models.Product;
import com.hsbc.shopping.services.ProductService;
import com.hsbc.shopping.validators.ProductValidator;


@Controller
public class ProductController {
	@Autowired
	private ProductValidator validator; 
	@Autowired
	private ProductService productService;	
	
	@GetMapping("/")
	public ModelAndView home()
	{
		return new ModelAndView("home","product",new Product());
	}	
	
	@PostMapping("/addProduct")
	public ModelAndView saveProduct(@ModelAttribute("product") 
	@Validated Product product, BindingResult result, Model model)
	{
	  ModelAndView modelAndView=null;
	  if(product!=null)
	  	System.out.println(product.getDop());	
	  validator.validate(product, result);
		if(result.hasErrors())
			modelAndView=new ModelAndView("home","product",new Product());
		else
		{
			
		  if(productService.addProduct(product))	
			modelAndView=new ModelAndView("viewProduct","productList",
	         			productService.findAllProducts());		
		}	
			
		return modelAndView;
	}

}
