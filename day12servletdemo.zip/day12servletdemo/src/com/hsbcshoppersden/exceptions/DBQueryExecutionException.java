package com.hsbcshoppersden.exceptions;

public class DBQueryExecutionException extends Exception{

	public  DBQueryExecutionException(String message)
	{
		super(message);
	}
}
