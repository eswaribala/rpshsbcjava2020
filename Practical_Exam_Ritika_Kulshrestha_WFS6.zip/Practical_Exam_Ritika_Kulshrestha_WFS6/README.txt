Data Access Layer (DAO) -- 
1. categoryDao.java  interface it contains methods what to do like add    category
2  categoryImpl.java  class implements interface methods 
3. fileHelper class has method that creates a new file

Business Layer
1 categoryBL interface that contains methods on which the logic has to be    made.
2. categoryBLImpl classs contains methods implementation
3. categorySorter.java  class sorts the category on the basis of Quantity

models layer
1. category class which has Apparel,FoodItems,Electronics classese as    sub-class
2. subcategory has subcategories of food,electronics,apparels.
3. two Enums Vegetarian and Material

