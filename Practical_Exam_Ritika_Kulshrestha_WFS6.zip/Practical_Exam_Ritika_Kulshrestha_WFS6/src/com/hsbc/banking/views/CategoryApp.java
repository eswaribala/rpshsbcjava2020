package com.hsbc.banking.views;

import java.io.IOException;
import java.util.Random;

import com.hsbc.banking.business.CategoryBL;
import com.hsbc.banking.business.CategoryBLImpl;
import com.hsbc.banking.exceptions.FileCreateException;
import com.hsbc.banking.models.Category;

public class CategoryApp {

	private static CategoryBL categoryBL;
	static
	{
		categoryBL=new CategoryBLImpl("Category.txt",1);
	}
	
	
	private static void addCategories()
	{
	
		Category[] categories =new Category[100];
		for(int i=0;i<categories.length;i++)
		{
		  categories[i]=new Category(int,String);
		  categories[i].setCategoryId(new Random().nextInt(100000));
		  categories[i].setName("Garments"+i);
		 
		}
		try {
			categoryBL.addCategory(categories);
			
		  } catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
