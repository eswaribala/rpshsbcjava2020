//Author -- Ritika Kulshrestha
//Purpose -- business layer interface



package com.hsbc.banking.business;

import java.io.IOException;

import com.hsbc.banking.exceptions.ItemAlreadyExistException;
import com.hsbc.banking.models.Category;

public interface CategoryBL {

	boolean addCategory(Category[] categories) throws IOException, ItemAlreadyExistException ;
	Category[] getAllCategories() throws ClassNotFoundException, IOException;
	
}
