//Author -- Ritika Kulshrestha
//Purpose -- business layer mathod implementation
package com.hsbc.banking.business;

import java.io.IOException;

import com.hsbc.banking.dao.CategoryDao;
import com.hsbc.banking.models.Category;

import com.hsbc.banking.dao.CategoryImpl;
import com.hsbc.banking.exceptions.FileCreateException;
import com.hsbc.banking.exceptions.ItemAlreadyExistException;

public class CategoryBLImpl implements CategoryBL{
	
	private CategoryDao categoryDao;
	
	public CategoryBLImpl(String fileName,int level)
	{
		try {
			categoryDao=new CategoryImpl(fileName,level);
		} catch (FileCreateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public boolean addCategory(Category[] categories) throws IOException, ItemAlreadyExistException {
		// TODO Auto-generated method stub
		boolean status=false;
		try {
			status=categoryDao.addCategory(categories);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			throw new ItemAlreadyExistException("Not able to store it in "
					+ "Already Exists here!!");
		} 
		return status;
	}

	@Override
	public Category[] getAllCategories() throws ClassNotFoundException, IOException {
		// TODO Auto-generated method stub
		return categoryDao.getAllCategories();
	}

	
	
	
}
