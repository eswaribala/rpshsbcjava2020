package com.hsbc.banking.business;

import java.util.Comparator;

import com.hsbc.banking.models.Category;

public class CategorySorter implements Comparator<Category>{


	@Override
	//public int compare(Category o1, Category o2) {
		// TODO Auto-generated method stub
		//return o1.getQuantity().compareTo(o2.getQuantity());
	}
}
