//Author -- Ritika Kulshrestha
//Purpose --  subclass of category class

package com.hsbc.banking.models;

import java.time.LocalDate;

public class FoodItems extends Category{

	public FoodItems(int id, String name) {
		super(id, name);
		// TODO Auto-generated constructor stub
	}
	
	private String itemCode;
	private String itemname;
	private double unitPrice;
	private LocalDate dateOfManufacture;
	private LocalDate dateOfExpiry;
	private Vegetarian type;
	private int quantity;
	public String getItemCode() {
		return itemCode;
	}
	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}
	public String getItemname() {
		return itemname;
	}
	public void setItemname(String itemname) {
		this.itemname = itemname;
	}
	public double getUnitPrice() {
		return unitPrice;
	}
	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}
	public LocalDate getDateOfManufacture() {
		return dateOfManufacture;
	}
	public void setDateOfManufacture(LocalDate dateOfManufacture) {
		this.dateOfManufacture = dateOfManufacture;
	}
	public LocalDate getDateOfExpiry() {
		return dateOfExpiry;
	}
	public void setDateOfExpiry(LocalDate dateOfExpiry) {
		this.dateOfExpiry = dateOfExpiry;
	}
	public Vegetarian getType() {
		return type;
	}
	public void setType(Vegetarian type) {
		this.type = type;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	
	
	
	@Override
	public String toString() {
		return "FoodItems [itemCode=" + itemCode + ", itemname=" + itemname + ", unitPrice=" + unitPrice
				+ ", dateOfManufacture=" + dateOfManufacture + ", dateOfExpiry=" + dateOfExpiry + ", type=" + type
				+ ", quantity=" + quantity + "]";
	}
	
	
	
	
	
	
	
	
	
}
