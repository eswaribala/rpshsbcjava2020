package com.hsbc.banking.models;

public enum Vegetarian {

	YES,NO;
}
