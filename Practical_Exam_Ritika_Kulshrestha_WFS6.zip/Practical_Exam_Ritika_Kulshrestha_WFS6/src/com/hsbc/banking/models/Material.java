package com.hsbc.banking.models;

public enum Material {

	COTTON,WOOLEN;
}
