//Author -- Ritika Kulshrestha
//Purpose --  subclass of category class

package com.hsbc.banking.models;

import java.time.LocalDate;

public class Electronics extends Category{

	public Electronics(int id, String name) {
		super(id, name);
		// TODO Auto-generated constructor stub
	}

	private String itemCode;
	private String itemname;
	private double unitPrice;
	private int warranty;
	private int quantity;
	
	public String getItemCode() {
		return itemCode;
	}

	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}



	public String getItemname() {
		return itemname;
	}

	public void setItemname(String itemname) {
		this.itemname = itemname;
	}


	public double getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}

	public int getWarranty() {
		return warranty;
	}

	public void setWarranty(int warranty) {
		this.warranty = warranty;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	@Override
	public String toString() {
		return "Electronics [itemCode=" + itemCode + ", itemname=" + itemname + ", unitPrice=" + unitPrice
				+ ", warranty=" + warranty + ", quantity=" + quantity + "]";
	}
	
	
	
	
}
