//Author -- Ritika Kulshrestha
//Purpose --  subclass of categpry class

package com.hsbc.banking.models;

import java.time.LocalDate;

public class Apparel extends Category{

	public Apparel(int id, String name) {
		super(id,name);
		// TODO Auto-generated constructor stub
	}
	private String itemCode;
	private String itemname;
	private double unitPrice;
	private int size;
	private Material materialType;
	private int quantity;
	public String getItemCode() {
		return itemCode;
	}
	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}
	public String getItemname() {
		return itemname;
	}
	public void setItemname(String itemname) {
		this.itemname = itemname;
	}
	public double getUnitPrice() {
		return unitPrice;
	}
	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
	public Material getMaterialType() {
		return materialType;
	}
	public void setMaterialType(Material materialType) {
		this.materialType = materialType;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	
	
	@Override
	public String toString() {
		return "Apparel [itemCode=" + itemCode + ", itemname=" + itemname + ", unitPrice=" + unitPrice + ", size="
				+ size + ", materialType=" + materialType + ", quantity=" + quantity + "]";
	}
	
	
	
	
	
}
