package com.hsbc.banking.exceptions;

public class FileCreateException extends Exception{

	public FileCreateException(String message)
	{
		super(message);
	}
}
