package com.hsbc.banking.exceptions;

public class ItemAlreadyExistException extends Exception{

	public ItemAlreadyExistException(String message)
	{
		super(message);
	}
	
}
