//Author -- Ritika Kulshrestha
//Purpose -- data access layer method implementation

package com.hsbc.banking.dao;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.StreamCorruptedException;
import com.hsbc.banking.exceptions.FileCreateException;
import com.hsbc.banking.models.Category;
import com.hsbc.banking.dao.FileHelper;

public class CategoryImpl implements CategoryDao{

	//for file handling
	private File file;
	private FileOutputStream fileOutputStream;
	private FileInputStream fileInputStream;
	private ObjectOutputStream objectOutputStream;
	private ObjectInputStream objectInputStream;
	
	public CategoryImpl(String fileName,int level) throws FileCreateException
	{
		try {
			file=FileHelper.createFile(fileName,level);
		} catch (IOException e) {
			// Re-Throwing File Creation Exception
			throw new FileCreateException("Problem with File creation Please Check !!");
		}
	}
	
	@Override
	public boolean addCategory(Category[] categories) throws IOException {
		// TODO Auto-generated method stub
		boolean status=false;
		fileOutputStream=new FileOutputStream(file,true);// writes in append mode		
		objectOutputStream=new ObjectOutputStream(fileOutputStream);
		for(int i=0;i<categories.length;i++)	
		   objectOutputStream.writeObject(categories[i]);
		objectOutputStream.close();
		fileOutputStream.close();
		status=true;
		
		return status;
	
	}
	
	
	public int getObjectCount() throws IOException, ClassNotFoundException 
	{
		fileInputStream=new FileInputStream(file);	
		objectInputStream=new ObjectInputStream(fileInputStream);
		//Category category=null;
		int count=0;
		try
		{
		while(objectInputStream.readObject()!=null)
		{
			count++;
		}
		}
		catch(EOFException exception)
		{
			System.out.println(exception.getMessage());
		}
		catch(StreamCorruptedException exception)
		{
			System.out.println(exception.getMessage());
		}
		finally
		{
			objectInputStream.close();
			fileInputStream.close();
		}
		
		return count;
	}
	
	
	@Override
	public Category[] getAllCategories() throws ClassNotFoundException, IOException {
		
		int count=getObjectCount();
		Category[] categories=new Category[count];	
		int pos = 0;
		Category category = null;
		fileInputStream=new FileInputStream(file);	
		objectInputStream=new ObjectInputStream(fileInputStream);
		try {
			while ((category = (Category) objectInputStream.readObject()) != null) {
				categories[pos] = category;
				pos++;
				
			}
		} catch (EOFException exception) 
		{
			System.out.println(exception.getMessage());
		} 
		catch(StreamCorruptedException exception)
		{
			System.out.println(exception.getMessage());
		}
		finally
		{
			objectInputStream.close();
			fileInputStream.close();
		}
		return categories;
		
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
}
