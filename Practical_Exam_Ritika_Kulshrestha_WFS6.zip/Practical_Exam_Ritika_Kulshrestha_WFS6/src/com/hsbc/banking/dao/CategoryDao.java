//Author -- Ritika Kulshrestha
//Purpose -- data access layer interface

package com.hsbc.banking.dao;

import java.io.IOException;

import com.hsbc.banking.models.Category;

public interface CategoryDao {
	// adding categories
	boolean addCategory(Category[] categories) throws IOException ;
	Category[] getAllCategories() throws ClassNotFoundException, IOException;
	
	//adding Subcategories
}
