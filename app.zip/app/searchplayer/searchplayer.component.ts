import { Component, OnInit } from '@angular/core';
import { PlayerService } from '../services/player.service';
import { SearchPlayer } from '../models/models.searchplayer';

@Component({
  selector: 'app-searchplayer',
  templateUrl: './searchplayer.component.html',
  styleUrls: ['./searchplayer.component.css']
})
export class SearchplayerComponent implements OnInit {

  private searchplayer:SearchPlayer = new SearchPlayer('')
  private path:string="../../assests"
  private extension:string=".jpg"
  private playerdata:any
  constructor(private playerservice:PlayerService) {
    
    // this.playerservice.getPlayerByName(this.searchplayer.playerName)


   }

  ngOnInit() {
  }
  search(){
    this.playerservice.getPlayerByName(this.searchplayer.playerName).subscribe(res=>{
      console.log(res)
      this.playerdata=res

    })
  }

}
