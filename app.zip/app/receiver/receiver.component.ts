import { Component, OnInit,Input } from '@angular/core';

@Component({
  selector: 'app-receiver',
  templateUrl: './receiver.component.html',
  styleUrls: ['./receiver.component.css']
})
export class ReceiverComponent implements OnInit {
  //below is the one which  gets the value from sender.html
  @Input("name")
  private playername:string
  constructor() { }

  ngOnInit() {
  }

}
