import { Component, OnInit, Input } from '@angular/core';
import { PlayerService } from '../services/player.service';
import { Playertable } from '../models/models.viewplayer';


const tableSource:Playertable []=[
  {
    "tennisId": "3456",
    "tournamnetId": "2019-M020",
    "location": "Brisbane",
    "date": "20181231",
    "matchNo": 300,
    "winnerName": "Kei Nishikori"
  },
  {
    "tennisId": "1",
    "tournamnetId": "234",
    "location": "banglore",
    "date": "24072019",
    "matchNo": 9,
    "winnerName": "vishnu"
  },
  {
    "tennisId": "2",
    "tournamnetId": "2019-M020",
    "location": "Brisbane",
    "date": "20181231",
    "matchNo": 299,
    "winnerName": "Daniil Medvedev"
  },
  {
    "tennisId": "3",
    "tournamnetId": "2019-M020",
    "location": "Brisbane",
    "date": "20181231",
    "matchNo": 298,
    "winnerName": "Kei Nishikori"
  },
  {
    "tennisId": "4",
    "tournamnetId": "2019-M020",
    "location": "Brisbane",
    "date": "20181231",
    "matchNo": 297,
    "winnerName": "Jo-Wilfried Tsonga"
  },
  {
    "tennisId": "5",
    "tournamnetId": "2019-M020",
    "location": "Brisbane",
    "date": "20181231",
    "matchNo": 296,
    "winnerName": "Daniil Medvedev"
  },
  {
    "tennisId": "6",
    "tournamnetId": "2019-M020",
    "location": "Brisbane",
    "date": "20181231",
    "matchNo": 295,
    "winnerName": "Jeremy Chardy"
  },
  {
    "tennisId": "7",
    "tournamnetId": "2019-M020",
    "location": "Brisbane",
    "date": "20181231",
    "matchNo": 294,
    "winnerName": "Kei Nishikori"
  },
  {
    "tennisId": "8",
    "tournamnetId": "2019-M020",
    "location": "Brisbane",
    "date": "20181231",
    "matchNo": 293,
    "winnerName": "Jo-Wilfried Tsonga"
  },
  {
    "tennisId": "9",
    "tournamnetId": "2019-M020",
    "location": "Brisbane",
    "date": "20181231",
    "matchNo": 292,
    "winnerName": "Alex De Minaur"
  },
  {
    "tennisId": "10",
    "tournamnetId": "2019-M020",
    "location": "Brisbane",
    "date": "20181231",
    "matchNo": 291,
    "winnerName": "Daniil Medvedev"
  },
  {
    "tennisId": "11",
    "tournamnetId": "2019-M020",
    "location": "Brisbane",
    "date": "20181231",
    "matchNo": 290,
    "winnerName": "Milos Raonic"
  },
  {
    "tennisId": "12",
    "tournamnetId": "23",
    "location": "nanganallur",
    "date": "28091997",
    "matchNo": 3,
    "winnerName": "aravind"
  },
  {
    "tennisId": "13",
    "tournamnetId": "2019-M020",
    "location": "Brisbane",
    "date": "20181231",
    "matchNo": 288,
    "winnerName": "Yasutaka Uchiyama"
  },
  {
    "tennisId": "14",
    "tournamnetId": "2019-M020",
    "location": "Brisbane",
    "date": "20181231",
    "matchNo": 287,
    "winnerName": "Grigor Dimitrov"
  },
  {
    "tennisId": "15",
    "tournamnetId": "2019-M020",
    "location": "Brisbane",
    "date": "20181231",
    "matchNo": 286,
    "winnerName": "Kei Nishikori"
  },
  {
    "tennisId": "16",
    "tournamnetId": "2019-M020",
    "location": "Brisbane",
    "date": "20181231",
    "matchNo": 284,
    "winnerName": "Jo-Wilfried Tsonga"
  },
  {
    "tennisId": "17",
    "tournamnetId": "2019-M020",
    "location": "Brisbane",
    "date": "20181231",
    "matchNo": 283,
    "winnerName": "Jordan Thompson"
  },
  {
    "tennisId": "18",
    "tournamnetId": "2019-M020",
    "location": "Brisbane",
    "date": "20181231",
    "matchNo": 282,
    "winnerName": "Alex De Minaur"
  },
  {
    "tennisId": "19",
    "tournamnetId": "2019-M020",
    "location": "Brisbane",
    "date": "20181231",
    "matchNo": 280,
    "winnerName": "Andy Murray"
  },
  {
    "tennisId": "20",
    "tournamnetId": "2019-M020",
    "location": "Brisbane",
    "date": "20181231",
    "matchNo": 279,
    "winnerName": "Miomir Kecmanovic"
  },
  {
    "tennisId": "21",
    "tournamnetId": "2019-M020",
    "location": "Brisbane",
    "date": "20181231",
    "matchNo": 278,
    "winnerName": "Milos Raonic"
  },
  {
    "tennisId": "22",
    "tournamnetId": "2019-M020",
    "location": "Brisbane",
    "date": "20181231",
    "matchNo": 277,
    "winnerName": "Nick Kyrgios"
  },
  {
    "tennisId": "23",
    "tournamnetId": "2019-M020",
    "location": "Brisbane",
    "date": "20181231",
    "matchNo": 276,
    "winnerName": "Jeremy Chardy"
  },
  {
    "tennisId": "24",
    "tournamnetId": "2019-M020",
    "location": "Brisbane",
    "date": "20181231",
    "matchNo": 275,
    "winnerName": "Yasutaka Uchiyama"
  },
  {
    "tennisId": "25",
    "tournamnetId": "2019-M020",
    "location": "Brisbane",
    "date": "20181231",
    "matchNo": 273,
    "winnerName": "Grigor Dimitrov"
  },
  {
    "tennisId": "26",
    "tournamnetId": "2019-M020",
    "location": "Brisbane",
    "date": "20181231",
    "matchNo": 272,
    "winnerName": "John Millman"
  },
  {
    "tennisId": "27",
    "tournamnetId": "2019-M020",
    "location": "Brisbane",
    "date": "20181231",
    "matchNo": 271,
    "winnerName": "Denis Kudla"
  },
  {
    "tennisId": "28",
    "tournamnetId": "2019-0451",
    "location": "Doha",
    "date": "20181231",
    "matchNo": 300,
    "winnerName": "Roberto Bautista Agut"
  },
  {
    "tennisId": "29",
    "tournamnetId": "2019-0451",
    "location": "Doha",
    "date": "20181231",
    "matchNo": 299,
    "winnerName": "Roberto Bautista Agut"
  },
  {
    "tennisId": "30",
    "tournamnetId": "2019-0451",
    "location": "Doha",
    "date": "20181231",
    "matchNo": 298,
    "winnerName": "Tomas Berdych"
  },
  {
    "tennisId": "31",
    "tournamnetId": "2019-0451",
    "location": "Doha",
    "date": "20181231",
    "matchNo": 297,
    "winnerName": "Novak Djokovic"
  },
  {
    "tennisId": "32",
    "tournamnetId": "2019-0451",
    "location": "Doha",
    "date": "20181231",
    "matchNo": 296,
    "winnerName": "Roberto Bautista Agut"
  },
  {
    "tennisId": "33",
    "tournamnetId": "2019-0451",
    "location": "Doha",
    "date": "20181231",
    "matchNo": 295,
    "winnerName": "Marco Cecchinato"
  },
  {
    "tennisId": "34",
    "tournamnetId": "2019-0451",
    "location": "Doha",
    "date": "20181231",
    "matchNo": 294,
    "winnerName": "Tomas Berdych"
  },
  {
    "tennisId": "35",
    "tournamnetId": "2019-0451",
    "location": "Doha",
    "date": "20181231",
    "matchNo": 293,
    "winnerName": "Novak Djokovic"
  },
  {
    "tennisId": "36",
    "tournamnetId": "2019-0451",
    "location": "Doha",
    "date": "20181231",
    "matchNo": 292,
    "winnerName": "Nikoloz Basilashvili"
  },
  {
    "tennisId": "37",
    "tournamnetId": "2019-0451",
    "location": "Doha",
    "date": "20181231",
    "matchNo": 291,
    "winnerName": "Stan Wawrinka"
  },
  {
    "tennisId": "38",
    "tournamnetId": "2019-0451",
    "location": "Doha",
    "date": "20181231",
    "matchNo": 290,
    "winnerName": "Roberto Bautista Agut"
  },
  {
    "tennisId": "39",
    "tournamnetId": "2019-0451",
    "location": "Doha",
    "date": "20181231",
    "matchNo": 289,
    "winnerName": "Dusan Lajovic"
  },
  {
    "tennisId": "40",
    "tournamnetId": "2019-0451",
    "location": "Doha",
    "date": "20181231",
    "matchNo": 288,
    "winnerName": "Marco Cecchinato"
  },
  {
    "tennisId": "41",
    "tournamnetId": "2019-0451",
    "location": "Doha",
    "date": "20181231",
    "matchNo": 287,
    "winnerName": "Tomas Berdych"
  }]

@Component({
  selector: 'app-sender',
  templateUrl: './sender.component.html',
  styleUrls: ['./sender.component.css']
})
export class SenderComponent implements OnInit {
  private selectedText:any
  
  private playerdata
  constructor(private playerService:PlayerService) { }

  ngOnInit() {
    // this.playerService.getAllPlayers().subscribe(item=>{
    //   this.playerdata = item
    // })
    
   this.playerdata = tableSource
  }

  selectedPlayer(){
    
  }
  changeCase(selectedText){
    // console.log(selectedText.toUpperCase())
   this.selectedText = selectedText.toUpperCase()
   
  }
}
