import { Component, OnInit, Output } from '@angular/core';
import { EventEmitter } from '@angular/core';

@Component({
  selector: 'app-translator',
  templateUrl: './translator.component.html',
  styleUrls: ['./translator.component.css']
})
export class TranslatorComponent implements OnInit {


  @Output("translateEvent")
  private translateText = new EventEmitter();
  constructor() { }

  ngOnInit() {
  }


  convert($event){
    this.translateText.emit()
  }
}
