import {TennisMenu} from "./models.tennismenu";



export let tennismenudata:TennisMenu[] = [
new TennisMenu('Add Player','pi pi-external-link','Addplayer'),
new TennisMenu('View Player','','ViewPlayers'),
new TennisMenu('Search Player','','Searchplayer'),
new TennisMenu('Capitalize player','','CapitalizePlayer')
]