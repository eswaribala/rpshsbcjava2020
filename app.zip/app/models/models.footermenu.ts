export class FooterMenu {
    private _label: string
    public get label(): string {
        return this._label
    }
    // public set label(value: string) {
    //     this._label = value
    // }
    private _icon: string
    public get icon(): string {
        return this._icon
    }
    // public set icon(value: string) {
    //     this._icon = value
    // }

    constructor(label:string,icon:string){
        this._label = label
        this._icon=icon
    }
    


}