import {SearchplayerComponent} from '../searchplayer/searchplayer.component'

export class SearchPlayer{
    private _playerName: string
    public get playerName(): string {
        return this._playerName
    }
    public set playerName(value: string) {
        this._playerName = value
    }
    
    
   
    constructor(playerName:string){
        this._playerName = playerName

    }
}