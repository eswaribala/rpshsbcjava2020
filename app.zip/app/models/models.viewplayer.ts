export class Playertable {
    tennisId: string;
    tournamnetId: string;
    location: string;
    date: string;
    matchNo:number;
    winnerName:string
  }