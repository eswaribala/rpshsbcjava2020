import { FooterMenu } from "./models.footermenu";


export let footermenudata:FooterMenu[] = [
new FooterMenu('Regulatory disclosure','pi pi-external-link'),
new FooterMenu('Hyperlink','')
]