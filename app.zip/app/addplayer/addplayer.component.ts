import { Component, OnInit } from "@angular/core";
import {
  FormControl,
  FormBuilder,
  Validators,
  FormGroup,
} from "@angular/forms";
import { PlayerService } from '../services/player.service';

@Component({
  selector: "app-addplayer",
  templateUrl: "./addplayer.component.html",
  styleUrls: ["./addplayer.component.css"],
})
export class AddplayerComponent implements OnInit {
  private tennisId: FormControl;
  private tournamentId: FormControl;
  private location: FormControl;
  private matchdate: FormControl;
  private matchNo: FormControl;
  private winnername: FormControl;
  private playerGroup: FormGroup;

  //playerservice is being injected in the constructor
  constructor(private formBuilder: FormBuilder,private playerService:PlayerService) {
    this.tennisId = new FormControl("", [
      Validators.required,
      Validators.min(1),
    ]);

    this.tournamentId = new FormControl("", [
      Validators.required,
      Validators.pattern("[A-Za-z0-9]"),
    ]);
    this.location = new FormControl("", [
      Validators.required,
      Validators.pattern("[A-z]{5,50}"),
    ]);
    this.matchdate = new FormControl("", [Validators.required]);
    this.matchNo = new FormControl("", [
      Validators.required,
      Validators.min(1),
    ]);
    this.winnername = new FormControl("", [
      Validators.required,
      Validators.pattern("[A-Za-z]{3,50}"),
    ]);
    this.playerGroup = formBuilder.group({
      tennisId: this.tennisId,
      tournamentId: this.tournamentId,
      location: this.location,
      matchdate: this.matchdate,
      matchNo: this.matchNo,
      winnerName: this.winnername,
    });
  }

  ngOnInit() {}

  addPlayer(){
    let splitdate = this.matchdate.value.split("-").join("")
    console.log(splitdate)
    console.log(this.playerGroup.value)
    this.playerService.addPlayer(this.playerGroup.value).subscribe(res=>{
      console.log(res)

    },err=>{console.log("error occured")}
    )

  }
}
