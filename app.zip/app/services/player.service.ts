import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Observable, EMPTY, throwError } from 'rxjs';
import {catchError} from 'rxjs/operators'

const httpOptions = {
  headers:new HttpHeaders({
    'Content-Type':'application/json'
  })
}


@Injectable({
  providedIn: 'root'
})
export class PlayerService {

  constructor(private httpClient:HttpClient) { }

  addPlayer(player:any):Observable<any>{
    return this.httpClient.post('http://localhost:7070/winners',player,httpOptions)
    .pipe(catchError(err =>{
      if((err.status>400)&&(err.status<500)){
        return EMPTY;
      }
      else{
        return throwError(err)
      }
    }))
  }

  getAllPlayers():Observable<any>{
    return this.httpClient.get('src/assets/atp_matches_2019.csv',{responseType: 'text'})
  }

  getPlayerByName(playerName:string):Observable<any>{
    return this.httpClient.get('http://localhost:7070/winners'+playerName)
  }



}
