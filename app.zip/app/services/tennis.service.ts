import { Injectable } from '@angular/core';
import {tennismenudata} from '../models/models.tennismenudata'

@Injectable({
  providedIn: 'root'
})
export class TennisService {

  constructor() { }
  getTennisdata():any
{
  return tennismenudata
}
}
