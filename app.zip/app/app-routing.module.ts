import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {AddplayerComponent} from './addplayer/addplayer.component'
import {ViewplayerComponent} from './viewplayer/viewplayer.component'
import {SearchplayerComponent} from './searchplayer/searchplayer.component'
import {SenderComponent} from './sender/sender.component'


const routes: Routes = [
  {
    path:'Addplayer',
    component:AddplayerComponent
  },
  {
    path:'Searchplayer',
    component:SearchplayerComponent
  },
  {
    path:'ViewPlayers',
    component:ViewplayerComponent
  },
  {
    path:'CapitalizePlayer',
    component:SenderComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
